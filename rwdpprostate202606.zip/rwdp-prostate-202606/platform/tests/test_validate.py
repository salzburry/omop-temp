"""Tests for the config/codelist validator. Run: python tests/test_validate.py (or pytest).

Pure Python (no Spark): exercises problems()/check() on the real config and on deliberately
broken copies (unfilled placeholder, duplicate code, misplaced catch-all).
"""
import copy
import json
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent   # _framework/ (the shared engine lives here)
sys.path.insert(0, str(FRAMEWORK))

from engine.config import load_config   # noqa: E402
from engine.config import product_config  # noqa: E402
from engine import validate                      # noqa: E402

CONFIG = product_config(FRAMEWORK.parent / "products", "prostate")   # reference tumor
GOOD = {"run.refresh": "2026q1", "run.source_schema": "rwd", "run.output_schema": "out"}


def test_real_config_lints_clean():
    # Lint mode (placeholders allowed) on the shipped config must be clean.
    assert validate.problems(load_config(CONFIG), strict=False) == []


def test_every_versioned_pack_lints_clean():
    # CI lints EVERY spec-version pack (incl. superseded like prostate 202603) via the same glob. A
    # validator change a historical pack can't satisfy must fail HERE, not only in CI — this guards the
    # regression where the bmi_formula->bmi_method migration once broke 202603's lint.
    products = FRAMEWORK.parent / "products"
    packs = sorted(products.glob("oncology/*/*/config/data_product.yaml"))
    assert packs, "no versioned packs found"
    failures = {str(p.relative_to(products)).replace("/config/data_product.yaml", ""): probs
                for p in packs if (probs := validate.problems(load_config(str(p)), strict=False))}
    assert not failures, f"versioned packs failing lint: {failures}"


def test_filled_config_passes_strict():
    cfg = load_config(CONFIG, overrides=GOOD)
    assert validate.problems(cfg, strict=True) == []
    validate.check(cfg)            # must not raise


def test_placeholder_fails_strict():
    cfg = load_config(CONFIG)      # run.* still REPLACE_ME
    probs = validate.problems(cfg, strict=True)
    assert any("REPLACE_ME" in p for p in probs)


def test_prod_placeholder_substring_fails_strict():
    # A non-exact prod placeholder (REPLACE_ME_prod_source) must STILL fail strict validation.
    cfg = load_config(CONFIG, overrides={**GOOD, "run.source_schema": "REPLACE_ME_prod_source"})
    assert any("REPLACE_ME_prod_source" in p and "source_schema" in p
               for p in validate.problems(cfg, strict=True))
    # lint mode (placeholders allowed) must NOT flag it
    assert not any("source_schema" in p for p in validate.problems(cfg, strict=False))
    try:
        validate.check(cfg)
    except RuntimeError as e:
        assert "REPLACE_ME" in str(e)
    else:
        raise AssertionError("check() should have raised on REPLACE_ME")


def _cfg_with_codelist(cats):
    """Build a Config whose treatment_categories codelist is replaced in-memory."""
    cfg = load_config(CONFIG, overrides=GOOD)
    cl = copy.deepcopy(cfg.codelist("treatment_categories"))
    cl["categories"] = cats
    cfg._codelists["treatment_categories"] = cl   # override the cached codelist
    return cfg


def test_missing_required_source_detected():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.sources.pop("mortality")                # a REQUIRED-core source
    probs = validate.problems(cfg)
    assert any("missing required mapping 'mortality'" in p for p in probs)


def test_optional_source_not_required():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.sources.pop("alphabet")                 # optional (prostate-only) — must NOT be flagged
    assert validate.problems(cfg) == []


def test_index_source_must_be_declared():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.index_dates["advanced_diagnosis_date"]["source"] = "not_a_source"
    assert any("index source 'not_a_source'" in p for p in validate.problems(cfg))


def test_linesetting_required_only_with_line_setting():
    cfg = load_config(CONFIG, overrides=GOOD)                       # prostate: lot.line_setting mCRPC
    assert "linesetting" in validate.required_columns(cfg)["lot"]
    cfg.raw.pop("lot", None)                                        # clear the GLOBAL setting...
    for c in cfg.cohorts:
        c.pop("line_setting", None)                                # ...AND every cohort's (heme-like: none)
    assert "linesetting" not in validate.required_columns(cfg)["lot"]


def test_lot_line_number_validation():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.raw.setdefault("lot", {})["line_number"] = "bogus"
    assert any("lot.line_number 'bogus'" in p for p in validate.problems(cfg))


def test_cohort_maintenance_must_be_bool():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.cohorts[1]["maintenance"] = "yes"                            # not a bool
    assert any("maintenance must be true/false" in p for p in validate.problems(cfg))


def test_maintenance_cohort_requires_flag_column():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.cohorts[1]["maintenance"] = True                            # a cohort now filters on the flag
    assert "ismaintenancetherapy" in validate.required_columns(cfg)["lot"]
    cfg2 = load_config(CONFIG, overrides=GOOD)                       # no maintenance cohort (prostate)
    assert "ismaintenancetherapy" not in validate.required_columns(cfg2)["lot"]


def test_oc_config_lints_clean():
    OC = product_config(FRAMEWORK.parent / "products", "oc")   # maintenance cohorts + linenumber model
    assert validate.problems(load_config(OC), strict=False) == []


def test_ec_config_lints_clean():
    EC = product_config(FRAMEWORK.parent / "products", "endometrial")  # source_union + maintenance
    assert validate.problems(load_config(EC), strict=False) == []


def test_min_avail_date_required_columns():
    # EVERY configured min_avail_date column is preflighted on its (declared) source — no silent skip.
    OC = product_config(FRAMEWORK.parent / "products", "oc")
    oc = load_config(OC)
    req = validate.required_columns(oc)
    assert "episodedate" in req.get("drug_episode", [])
    assert "visitdate" in req.get("visit", [])
    assert "testdate" in req.get("lab", [])                      # lab date column required, not skipped
    assert "diagnosisdate" in req.get(oc.index_source, [])       # base column
    EC = product_config(FRAMEWORK.parent / "products", "endometrial")
    ec = load_config(EC)
    assert "advanceddiagnosisdate" in validate.required_columns(ec).get(ec.index_source, [])


def test_passthrough_required_columns():
    # passthrough columns + flag source columns are preflighted on the index source.
    pc = load_config(CONFIG)                                       # prostate gleason/PSA pass-through
    assert "gleasonscore" in validate.required_columns(pc).get(pc.index_source, [])
    EC = product_config(FRAMEWORK.parent / "products", "endometrial")
    ec = load_config(EC)                                           # EC radiation pass-through + flag
    ecreq = validate.required_columns(ec).get(ec.index_source, [])
    assert "radiationtype" in ecreq and "radiationtherapydate" in ecreq


def test_preflight_report_confirms_present_and_flags_missing():
    # preflight_report() is the readable schema-validation form of preflight(): per source table, which
    # required columns are present in the (fixture) delivered schema. Config-driven — columns come from
    # required_columns(), tables from sources: — so it validates exactly what the build reads.
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    fqn_cols, drop = {}, None
    for name in cfg.sources:
        cols = list(req.get(name, ["patientid"]))
        for fqn in cfg.source_fqns(name):
            fqn_cols[fqn] = cols
            if drop is None and cols:
                drop = (name, fqn, cols[0])
    assert drop, "no required columns found"
    # every configured column present -> ok
    assert validate.preflight_report(cfg, lambda fqn: list(fqn_cols[fqn]))["ok"]
    # drop one required column -> flagged as missing, report not ok, surfaced in the markdown
    tname, tfqn, tcol = drop
    bad = validate.preflight_report(cfg, lambda fqn: [c for c in fqn_cols[fqn] if not (fqn == tfqn and c == tcol)])
    assert not bad["ok"]
    assert tcol in bad["sources"][tname]["tables"][0]["missing"]
    md = validate.preflight_report_md(bad)
    assert tcol in md and "❌" in md
    # an unreadable table (wrong stem) is flagged, not swallowed
    unreadable = validate.preflight_report(cfg, lambda fqn: (_ for _ in ()).throw(RuntimeError("no such table")))
    assert not unreadable["ok"]
    assert any(not t["readable"] for s in unreadable["sources"].values() for t in s["tables"])


def test_preflight_report_records_optional_columns_and_observed_types():
    # Optional configured columns (conmed drugname/episodedate; PSA-diagnosis passthroughs) are REPORTED
    # present/absent — never fatal — so the evidence shows EVERY configured column, not only hard-required
    # ones. A dict reader (name->type) captures observed types.
    cfg = load_config(CONFIG, overrides=GOOD)
    opt = validate.optional_columns(cfg)
    # PSA-at-diagnosis passthroughs are `optional: true` — genuinely feed-dependent, never fatal. They must
    # be reported (present/absent) so a schema-evidence run shows every configured column.
    assert "enhanced" in opt and "psainitialdiagnosis" in opt["enhanced"], \
        "optional:true passthrough columns must be reported as optional"
    req = validate.required_columns(cfg)

    def _reader(include_psa):
        def reader(fqn):
            cols = {}
            for name in cfg.sources:
                if fqn in cfg.source_fqns(name):
                    for c in req.get(name, ["patientid"]):
                        cols[c] = "string"
                    if name == "enhanced" and include_psa:
                        cols["psainitialdiagnosis"] = "double"   # present optional, typed
            return cols
        return reader

    # optional PRESENT: reported present, observed type captured.
    rep = validate.preflight_report(cfg, _reader(include_psa=True))
    assert rep["ok"]
    enh = rep["sources"]["enhanced"]["tables"][0]
    assert enh["optional_present"].get("psainitialdiagnosis") is True
    assert enh["types"].get("psainitialdiagnosis") == "double"   # observed type from the dict reader

    # optional ABSENT: still ok (optional never fails), but recorded absent so the evidence shows it.
    rep2 = validate.preflight_report(cfg, _reader(include_psa=False))
    assert rep2["ok"], "an absent OPTIONAL column must not fail the report"
    assert rep2["sources"]["enhanced"]["tables"][0]["optional_present"].get("psainitialdiagnosis") is False

    md = validate.preflight_report_md(rep2)
    assert "BUILD-REQUIRED" in md and "Optional present" in md and "psainitialdiagnosis" in md


def test_conmed_name_column_required_when_flags_configured():
    # conmed_bp/csf/steroid are configured, so drugname is REQUIRED — its absence would silently drop all
    # three published conmed outputs. required_columns must include it, and preflight must FAIL when absent.
    cfg = load_config(CONFIG, overrides=GOOD)
    assert cfg.pack("treatment")["conmed_exposures"]["flags"]                 # prostate configures them
    assert "drugname" in validate.required_columns(cfg)["drug_episode"]
    # preflight fails loudly when drugname is missing (not a silent drop).
    req = validate.required_columns(cfg)
    fqn_cols = {fqn: [c for c in req.get(name, ["patientid"]) if c != "drugname"]
                for name in cfg.sources for fqn in cfg.source_fqns(name)}
    rep = validate.preflight_report(cfg, lambda fqn: fqn_cols[fqn])
    assert not rep["ok"] and "drugname" in rep["sources"]["drug_episode"]["tables"][0]["missing"]
    # remove the flags -> drugname is no longer required (nothing else reads it).
    cfg2 = load_config(CONFIG, overrides=GOOD)
    cfg2.pack("treatment")["conmed_exposures"]["flags"] = []
    assert "drugname" not in validate.required_columns(cfg2).get("drug_episode", [])


def test_conmed_date_column_conditional_on_window():
    # Isolate conmed as the only episodedate driver (drop line_outcomes + use a codelist without
    # category_equals) so the window toggle is observable.
    cfg = _cfg_with_codelist([{"code": 1, "label": "A", "match": {"equals": "a"}},
                              {"code": 16, "label": "Any other therapy", "match": {"always": True}}])
    cfg.pack("outcomes").pop("line_outcomes", None)
    ce = cfg.pack("treatment")["conmed_exposures"]
    ce["window_days"] = [None, None]                    # any-time -> date NOT read -> optional
    assert "episodedate" not in validate.required_columns(cfg).get("drug_episode", [])
    assert "episodedate" in validate.optional_columns(cfg).get("drug_episode", [])
    ce["window_days"] = [-30, 0]                         # a real window reads the date -> REQUIRED
    assert "episodedate" in validate.required_columns(cfg)["drug_episode"], \
        "a windowed conmed exposure must require its date column (else it silently evaluates over all time)"


def test_preflight_evidence_envelope_has_provenance_and_presence_status():
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    fqn_cols = {fqn: list(req.get(name, ["patientid"]))
                for name in cfg.sources for fqn in cfg.source_fqns(name)}
    rep = validate.preflight_report(cfg, lambda fqn: fqn_cols[fqn])
    ev = validate.preflight_evidence(cfg, rep, generated_at="2026-07-22T00:00:00+00:00", git_commit="abc123")
    assert ev["schema_presence"] == "passed_live" and ev["ok"] is True   # presence status, NOT source-verified
    assert ev["data_product_id"] == cfg.data_product_id and ev["spec_version"] == cfg.spec_version
    assert ev["data_refresh"] == cfg.refresh and ev["source_schema"] == cfg.source_schema
    assert ev["git_commit"] == "abc123" and ev["generated_at"].startswith("2026")
    json.dumps(ev)   # must be JSON-serializable (machine-readable evidence)


def test_preflight_honors_panoramic_renames():
    # Under a non-EDM format, a required LOGICAL column is satisfied by its PHYSICAL name (renamed at
    # load); without the rename overlay the same physical-only table fails preflight.
    from engine.config import Config
    from pathlib import Path
    raw = {"run": {"source_schema": "s", "refresh": "r", "data_format": "Panoramic"},
           "vendor": "flatiron", "sources": {"enhanced": "enh"},
           "index_dates": {"advanced_diagnosis_date": {"of": ["linename"]}},   # force 'linename' required
           "formats": {"Panoramic": {"rename": {"enhanced": {"RegimenName": "linename"}}}}}
    reader = lambda fqn: ["patientid", "RegimenName"]                          # physical, no 'linename'
    assert validate.preflight(None, Config(raw, Path(".")), _table_reader=reader) is True
    try:
        validate.preflight(None, Config({**raw, "formats": {}}, Path(".")), _table_reader=reader)
        assert False, "preflight should fail when the physical column is not renamed to the logical one"
    except RuntimeError as e:
        assert "linename" in str(e)


def test_data_format_without_overlay_flagged():
    cfg = load_config(CONFIG, overrides={**GOOD, "run.data_format": "Panoramic"})   # no formats.Panoramic
    assert any("no `formats.Panoramic` overlay" in p for p in validate.problems(cfg))


def test_formats_rename_undeclared_source_flagged():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.raw["formats"] = {"Panoramic": {"rename": {"nosuchsource": {"a": "b"}}}}
    assert any("references undeclared source 'nosuchsource'" in p for p in validate.problems(cfg))


def test_source_union_member_validation():
    cfg = load_config(CONFIG, overrides=GOOD)                       # prostate + a broken union
    cfg.raw["source_union"] = {"discriminator": "db", "members": [{"flag": "X"}]}  # member missing schema
    assert any("source_union.members[0] missing 'schema'" in p for p in validate.problems(cfg))


def test_clinical_categorical_missing_field_flagged():
    cfg = load_config(CONFIG, overrides=GOOD)
    clin = cfg.pack("clinical")                                     # cached dict (same object)
    clin["categoricals"] = [{"name": "grade", "column": "grade"}]   # missing 'groups'
    assert any("clinical.categoricals[0] missing 'groups'" in p for p in validate.problems(cfg))


def test_clinical_categorical_source_must_be_declared():
    # A typo'd explicit source must fail validation (else it lint-clean-skips the variable at runtime).
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["categoricals"] = [
        {"name": "grade", "column": "grade", "source": "enhnaced",   # typo of 'enhanced'
         "groups": [{"code": 1, "label": "G1", "from_equals_ci": ["g1"]}]}]
    assert any("categoricals[0].source 'enhnaced' is not a declared source"
               in p for p in validate.problems(cfg))


def test_clinical_staging_source_must_be_declared():
    # A staging source typo must fail validation, else `stage` silently disappears from the ADS.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["staging"] = {"source": "nosuchsource",
                                       "groups": [{"code": 1, "label": "I", "from_prefixes": ["I"]}]}
    assert any("clinical.staging.source 'nosuchsource' is not a declared source"
               in p for p in validate.problems(cfg))


def test_vitals_formula_methods_validated():
    # BMI/BSA formulas are NAMED and resolved from a fixed engine registry; the shipped config uses valid
    # names and lints clean. The validator method sets are DERIVED from the engine registries.
    cfg = load_config(CONFIG, overrides=GOOD)
    assert not any("bmi_method" in p or "bsa_method" in p for p in validate.problems(cfg))
    assert validate.BMI_METHODS == set(validate.BMI_FORMULAS)      # derived, not duplicated
    assert validate.BSA_METHODS == set(validate.BSA_FORMULAS)
    assert "mosteller" not in validate.BSA_METHODS                 # dropped (YAGNI) — re-add on request
    # unknown method names are rejected
    vit = cfg.pack("clinical")["vitals"]                           # cached dict (same object)
    vit["bmi_method"], vit["bsa_method"] = "eyeball", "guess"
    probs = validate.problems(cfg)
    assert any("clinical.vitals.bmi_method 'eyeball'" in p for p in probs)
    assert any("clinical.vitals.bsa_method 'guess'" in p for p in probs)


def test_bmi_method_required_when_vitals_configured():
    # bmi_method must be a non-empty string when vitals is on — null / empty / wrong-type / missing all
    # fail (this is the Python/R null-divergence class the engines now also default identically).
    for bad in (None, "", [], {}):
        cfg = load_config(CONFIG, overrides=GOOD)
        cfg.pack("clinical")["vitals"]["bmi_method"] = bad
        assert any("bmi_method is required" in p for p in validate.problems(cfg)), bad
    cfg = load_config(CONFIG, overrides=GOOD)
    del cfg.pack("clinical")["vitals"]["bmi_method"]
    assert any("bmi_method is required" in p for p in validate.problems(cfg))


def test_legacy_bmi_bsa_formula_keys_flagged():
    # The decorative bmi_formula/bsa_formula strings the engine no longer reads must be flagged so an old
    # config editing them (with no effect) can't pass silently.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["vitals"]["bsa_formula"] = "0.007184 * height^0.725 * weight^0.425"
    assert any("bsa_formula is a legacy decorative key" in p for p in validate.problems(cfg))


def test_follow_up_sources_structural_validation():
    # The shipped dict-form follow_up_sources lints clean; the LOT alias is pinned and filter_method is
    # validated against the engine FOLLOWUP_FILTERS registry.
    assert not any("follow_up_sources" in p
                   for p in validate.problems(load_config(CONFIG, overrides=GOOD)))
    cfg = load_config(CONFIG, overrides=GOOD)
    for s in cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "lot":
            s["alias"] = "last_lot"
    assert any("must use alias 'last_lotenddate'" in p for p in validate.problems(cfg))
    cfg2 = load_config(CONFIG, overrides=GOOD)
    for s in cfg2.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "orals":
            s["filter_method"] = "nope"
    assert any("filter_method 'nope'" in p for p in validate.problems(cfg2))


def test_follow_up_sources_filter_method_type_and_conflict():
    # A non-string filter_method (e.g. an empty list) previously raised an unhashable-key TypeError that
    # the outer except swallowed, so the malformed config passed lint. It must now be flagged.
    cfg = load_config(CONFIG, overrides=GOOD)
    for s in cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "orals":
            s["filter_method"] = []
    assert any("filter_method must be a non-empty string" in p for p in validate.problems(cfg))
    # Setting BOTH a raw 'filter' and a 'filter_method' is ambiguous (the named method wins, the raw
    # filter is silently dropped) -> flagged.
    cfg2 = load_config(CONFIG, overrides=GOOD)
    for s in cfg2.pack("clinical")["death_date_imputation"]["follow_up_sources"]:
        if s.get("source") == "orals":
            s["filter"] = "enddate IS NOT NULL"          # filter_method valid_oral_end already present
    assert any("both 'filter' and 'filter_method'" in p for p in validate.problems(cfg2))


def test_follow_up_sources_names_list_form_validated():
    # The NAMES-list form (restrict the engine default set) must be validated too: a valid list lints
    # clean, but a typo'd source name (which silently yields empty follow-up at runtime) fails lint.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"] = ["visit", "lot"]
    assert not any("follow_up_sources" in p for p in validate.problems(cfg))
    cfg2 = load_config(CONFIG, overrides=GOOD)
    cfg2.pack("clinical")["death_date_imputation"]["follow_up_sources"] = ["visti", "lot"]   # typo
    assert any("'visti' is not a known follow-up source" in p for p in validate.problems(cfg2))


def test_prior_taxane_pre_mcrpc_source_validated_and_preflighted():
    # A typo'd pre_mcrpc_source must fail validation, not silently skip prior_tax_pre_mcrpc...
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("treatment")["prior_taxane"]["pre_mcrpc_source"] = "not_a_source"
    assert any("pre_mcrpc_source 'not_a_source' is not a declared source"
               in p for p in validate.problems(cfg))
    # ...and when declared, its linename/startdate are added to the preflight contract.
    cfg2 = load_config(CONFIG, overrides=GOOD)
    cfg2.pack("treatment")["prior_taxane"]["pre_mcrpc_source"] = "ses"   # a declared source
    assert {"linename", "startdate"} <= set(validate.required_columns(cfg2)["ses"])


def test_drug_episode_columns_required_only_with_line_outcomes():
    # Prostate has line_outcomes -> drug_episode (declared) must expose linenumber/episodedate, so a
    # missing column is caught up front instead of silently falling back to enddate (which would
    # shift vis120/TTD/TTNT).
    cfg = load_config(CONFIG, overrides=GOOD)
    assert cfg.pack("outcomes").get("line_outcomes")                     # prostate enables it
    assert {"linenumber", "episodedate"} <= set(validate.required_columns(cfg)["drug_episode"])
    # episodedate has TWO independent drivers now (line_outcomes AND the B1 category aggregate), so the
    # base case must strip BOTH: no line_outcomes AND a codelist that doesn't use category_equals.
    cfg2 = _cfg_with_codelist([{"code": 1, "label": "A", "match": {"equals": "a"}},
                               {"code": 16, "label": "Any other therapy", "match": {"always": True}}])
    cfg2.pack("outcomes").pop("line_outcomes", None)
    assert "episodedate" not in set(validate.required_columns(cfg2).get("drug_episode", []))


def test_b1_drug_category_preflight_moved_to_drug_episode():
    # B1: the per-line drug category moved LOT -> drug_episode. Prostate's classifier uses category_equals,
    # so preflight must (a) NOT require detaileddrugcategory on lot, and (b) require linesetting, linenumber,
    # episodedate AND detaileddrugcategory on drug_episode — episodedate because the runtime only builds the
    # per-line aggregate (hence the category) when episodedate is present.
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    assert "detaileddrugcategory" not in req["lot"]
    assert {"linesetting", "linenumber", "episodedate", "detaileddrugcategory"} <= set(req["drug_episode"])
    # A codelist that never uses category_equals must NOT force detaileddrugcategory onto drug_episode.
    cfg2 = _cfg_with_codelist([{"code": 1, "label": "A", "match": {"equals": "a"}},
                               {"code": 16, "label": "Any other therapy", "match": {"always": True}}])
    assert "detaileddrugcategory" not in set(validate.required_columns(cfg2).get("drug_episode", []))
    # And a missing category column on drug_episode is caught by preflight, not silently NULLed at runtime.
    cols = _complete_cols(cfg)
    cols["drug_episode"].remove("detaileddrugcategory")
    try:
        validate.preflight(None, cfg, _table_reader=_reader_for(cfg, cols))
    except RuntimeError as e:
        assert "detaileddrugcategory" in str(e)
    else:
        raise AssertionError("expected preflight to flag missing detaileddrugcategory on drug_episode")
    # A product with NO line-setting model (no global AND no cohort setting) must NOT be forced to carry
    # linesetting on drug_episode — it aggregates on patient+linenumber. The category is still required.
    cfg3 = load_config(CONFIG, overrides=GOOD)
    cfg3.raw.pop("lot", None)                                        # global lot.line_setting -> None
    for c in cfg3.cohorts:
        c.pop("line_setting", None)                                 # AND strip every cohort's setting
    req3 = validate.required_columns(cfg3)
    assert "linesetting" not in set(req3.get("drug_episode", []))
    assert "linesetting" not in set(req3.get("lot", []))
    assert {"linenumber", "episodedate", "detaileddrugcategory"} <= set(req3.get("drug_episode", []))


def test_linesetting_required_from_cohort_setting_without_global():
    # The runtime resolves cohort.line_setting BEFORE the global fallback, so a product that sets
    # line_setting only on its cohorts (no global lot.line_setting) still uses a setting model — preflight
    # must require linesetting on BOTH lot and drug_episode, not skip it because the global is unset.
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.raw.pop("lot", None)                                         # global lot.line_setting -> None
    assert cfg.lot_line_setting is None
    assert any(c.get("line_setting") for c in cfg.cohorts)          # cohorts still carry mHSPC/mCRPC
    req = validate.required_columns(cfg)
    assert "linesetting" in set(req.get("lot", []))                 # gate now sees the cohort settings
    assert "linesetting" in set(req.get("drug_episode", []))


def test_custom_followup_filter_columns_required():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["death_date_imputation"]["follow_up_sources"] = [
        {"source": "visit", "date_column": "visitdate", "filter_columns": ["visittype"]}]
    req = validate.required_columns(cfg)
    assert "visittype" in req["visit"] and "visitdate" in req["visit"]


def test_death_conflict_policy_validated():
    cfg = load_config(CONFIG, overrides=GOOD)
    cfg.pack("clinical")["death_date_imputation"]["conflict_resolution"] = "bogus"
    assert any("conflict_resolution" in p for p in validate.problems(cfg))


def test_age_bands_need_fallthrough():
    cfg = load_config(CONFIG, overrides=GOOD)
    for b in cfg.pack("demographics")["age_bands"]:      # mutate the role-cache the validator reads
        b.pop("when", None)                              # remove the fallthrough marker
    assert any("age_bands needs exactly one" in p for p in validate.problems(cfg))


def test_duplicate_code_detected():
    cats = [
        {"code": 1, "label": "A", "match": {"equals": "a"}},
        {"code": 1, "label": "B", "match": {"equals": "b"}},
        {"code": 16, "label": "Any other therapy", "match": {"always": True}},
    ]
    assert any("codes not unique" in p for p in validate.problems(_cfg_with_codelist(cats)))


def test_catchall_must_be_last():
    cats = [
        {"code": 16, "label": "Any other therapy", "match": {"always": True}},
        {"code": 1, "label": "A", "match": {"equals": "a"}},
    ]
    assert any("LAST category" in p for p in validate.problems(_cfg_with_codelist(cats)))


def test_missing_catchall_detected():
    cats = [{"code": 1, "label": "A", "match": {"equals": "a"}}]
    assert any("exactly one always-true catch-all" in p
               for p in validate.problems(_cfg_with_codelist(cats)))


def test_required_columns_includes_index_date_of():
    cfg = load_config(CONFIG, overrides=GOOD)
    req = validate.required_columns(cfg)
    # advanceddiagnosisdate is derived, so enhanced must expose its `of` columns
    assert "metastaticdiagnosisdate" in req["enhanced"]
    assert "crpcdate" in req["enhanced"]
    assert "linesetting" in req["lot"]


def _reader_for(cfg, cols_by_source):
    """Build a _table_reader from {source_name: [cols]} keyed by resolved table FQN."""
    fqn_cols = {cfg.table(n): cols for n, cols in cols_by_source.items()}

    def read(fqn):
        if fqn not in fqn_cols:
            raise RuntimeError("table not found")
        return fqn_cols[fqn]
    return read


def _complete_cols(cfg):
    req = validate.required_columns(cfg)
    return {n: list(req.get(n, ["patientid"])) for n in cfg.sources}   # declared sources


def test_preflight_passes_when_complete():
    cfg = load_config(CONFIG, overrides=GOOD)
    assert validate.preflight(None, cfg, _table_reader=_reader_for(cfg, _complete_cols(cfg))) is True


def test_preflight_flags_missing_column():
    cfg = load_config(CONFIG, overrides=GOOD)
    cols = _complete_cols(cfg)
    cols["lot"].remove("linesetting")
    try:
        validate.preflight(None, cfg, _table_reader=_reader_for(cfg, cols))
    except RuntimeError as e:
        assert "linesetting" in str(e)
    else:
        raise AssertionError("expected preflight to flag the missing column")


def test_preflight_flags_unreadable_table():
    cfg = load_config(CONFIG, overrides=GOOD)
    cols = _complete_cols(cfg)
    del cols["mortality"]                       # simulate a missing/unreadable table
    try:
        validate.preflight(None, cfg, _table_reader=_reader_for(cfg, cols))
    except RuntimeError as e:
        assert "mortality" in str(e) and "not readable" in str(e)
    else:
        raise AssertionError("expected preflight to flag the unreadable table")


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
