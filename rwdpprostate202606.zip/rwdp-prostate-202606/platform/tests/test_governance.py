"""Wave-1 governance checks (pure Python, no jsonschema lib needed). These make the governance/
artifacts REAL — CI fails if the engine VERSION isn't SemVer, a schema is malformed, an active product
lacks a presence-valid source_refs.yaml, or the root CODEOWNERS stops routing governance.

Run: python3 tests/test_governance.py (or pytest). See governance/ + migration doc §H.
"""
import ast
import json
import os
import re
import subprocess
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent      # _framework/
sys.path.insert(0, str(FRAMEWORK))
PRODUCTS = FRAMEWORK.parent / "products"                             # products/
REPO = PRODUCTS.parent                                  # repo root
GOV = REPO / "governance"

from engine.config import load_yaml                     # noqa: E402
from engine.config import product_config, product_dir  # noqa: E402
from engine.version import ENGINE_VERSION, engine_version  # noqa: E402

SEMVER = re.compile(r"^\d+\.\d+\.\d+$")
# The environment file's NAME, from the engine that reads it — not a fourth literal.
from engine.config import PIPELINE as _PIPELINE_REL      # noqa: E402
YYYYMM = re.compile(r"^\d{6}$")


def as_json(doc):
    """A YAML document reshaped into what JSON Schema can type-check: dates as ISO strings.

    PyYAML resolves an UNQUOTED `2026-07-27` to a `datetime.date`, and every date field in the schema
    is `type: string` with an ISO pattern — so a date written the way a person naturally writes one
    failed validation as "not a string", while the same value written in quotes passed. The tool side
    never noticed: `product_gates.bad_date` compares on `str(v)` and accepts both. Schema and gate
    disagreeing about what a valid date looks like is the parity failure this repo keeps finding, and
    it stayed hidden because `approval_date` and `attestation_date` are only required of a
    `reviewed` material and no pack has one. `classified_date` is the first date a live pack carries.

    Normalising rather than demanding quotes: a convention every author must remember, in every pack,
    forever, is not a fix. Both spellings are the same date and both now validate; a genuinely
    malformed one (`27/07/2026`) stays a string and the pattern still refuses it.
    """
    import datetime
    if isinstance(doc, dict):
        return {k: as_json(v) for k, v in doc.items()}
    if isinstance(doc, list):
        return [as_json(v) for v in doc]
    if isinstance(doc, (datetime.date, datetime.datetime)):
        return doc.isoformat()
    return doc


def test_engine_version_is_semver():
    v = (FRAMEWORK / "VERSION").read_text(encoding="utf-8").strip()
    assert SEMVER.match(v), f"platform/VERSION is not SemVer: {v!r}"
    assert engine_version() == v and ENGINE_VERSION == v, "engine.version disagrees with the VERSION file"


def test_schemas_well_formed():
    schemas = sorted((GOV / "schemas").glob("*.json"))
    assert schemas, "no governance/schemas/*.json found"
    for s in schemas:
        doc = json.loads(s.read_text(encoding="utf-8"))                  # must be valid JSON
        assert str(doc.get("$schema", "")).startswith("https://json-schema.org/"), f"{s.name}: no $schema"
        assert "type" in doc and ("required" in doc or "properties" in doc), f"{s.name}: not a schema"


def test_active_products_have_valid_source_refs():
    schema = json.loads((GOV / "schemas" / "source_refs.schema.json").read_text(encoding="utf-8"))
    top_req = schema["required"]                                          # product, spec_version, source_materials
    item_req = schema["properties"]["source_materials"]["items"]["required"]   # path_or_link, role, status
    status_enum = set(schema["properties"]["source_materials"]["items"]["properties"]["status"]["enum"])
    try:
        import jsonschema   # CI installs it (platform/requirements.txt); optional locally
    except ImportError:
        jsonschema = None
    actives = [t for t in load_yaml(PRODUCTS / "registry.yaml")["tumors"] if t.get("status") == "active"]
    assert actives, "no active products in registry"
    for t in actives:
        # EVERY on-disk spec version of an active product (registry-current AND superseded-but-buildable
        # lineage, e.g. prostate 202603 AND 202606) must carry a valid source_refs.yaml — the audit promise
        # covers the buildable prior contracts too, not only the current one.
        pack_root = product_dir(PRODUCTS, t["slug"]).parent
        versions = sorted(d.name for d in pack_root.iterdir()
                          if (d / "config" / "data_product.yaml").exists())
        assert versions, f"active product {t['code']}: no spec-version pack on disk under {pack_root}"
        for sv in versions:
            sr_path = product_dir(PRODUCTS, t["slug"], spec_version=sv) / "source_refs.yaml"
            assert sr_path.exists(), f"active product {t['code']}/{sv} is missing source_refs.yaml (required — doc §C)"
            sr = load_yaml(sr_path)
            # FULL schema validation when jsonschema is present (CI) — required + minItems + status enum +
            # pattern, straight from the schema so this test can't drift from it. (Without it, the manual
            # floor below still catches the named gaps: empty source_materials, a typo'd status.)
            if jsonschema is not None:
                jsonschema.validate(as_json(sr), schema)
            assert sr.get("source_materials"), f"{t['code']}/{sv}: source_materials is empty (schema minItems: 1)"
            for k in top_req:
                assert k in sr, f"{t['code']}/{sv} source_refs.yaml missing top-level '{k}'"
            assert YYYYMM.match(str(sr["spec_version"])), f"{t['code']}/{sv}: source_refs spec_version not YYYYMM"
            # BIND the file to its folder + product: a 202606 source_refs copied under 202603/ must FAIL.
            assert str(sr["spec_version"]) == sv, \
                f"{t['code']}/{sv}: source_refs spec_version '{sr['spec_version']}' != its folder '{sv}'"
            assert str(sr.get("product")) == str(t["code"]), \
                f"{t['code']}/{sv}: source_refs product '{sr.get('product')}' != registry code '{t['code']}'"
            for m in sr["source_materials"]:
                for k in item_req:
                    assert k in m, f"{t['code']}/{sv} source material missing '{k}': {m}"
                assert m["status"] in status_enum, \
                    f"{t['code']}/{sv}: invalid status '{m.get('status')}' (allowed: {sorted(status_enum)})"
                # presence: ANY in-repo (local, non-URL, non-TBD) path must exist — REGARDLESS of status.
                # A `reference_only` in-repo SNAPSHOT (e.g. an in-repo spec snapshot)
                # is governed provenance too, so an accidental deletion must FAIL CI, not slip through. (External
                # http(s) links and `TBD` placeholders are intentionally not presence-checked.)
                p = str(m["path_or_link"])
                local = "://" not in p and not p.strip().upper().startswith("TBD")
                if local:
                    assert (REPO / p).exists(), \
                        f"{t['code']}/{sv}: source material missing on disk: {p} (status={m.get('status')})"


def test_every_pack_source_refs_matches_the_schema():
    """Schema validation followed the REGISTRY, so only active products were checked against it.

    A scaffold tumour — ovarian today, whichever lands next tomorrow — was checked by
    source_manifest.py for cross-file semantics but never against the schema's shape and controlled
    values. That is how a `material_type` no longer in the enum survived in a test fixture. Every pack
    that ships a source record is held to the same shape; the enum stays in the schema and is not
    restated in Python.
    """
    try:
        import jsonschema
    except ImportError:
        import pytest
        pytest.skip("jsonschema not installed (CI installs it via platform/requirements.txt)")
    schema = json.loads((GOV / "schemas" / "source_refs.schema.json").read_text(encoding="utf-8"))
    # rglob, not a fixed depth. `*/*/*/` assumed products/<family>/<slug>/<version>/ exactly, so
    # adding a grouping level (a disease group, or a second family) would have dropped those packs
    # out of schema validation SILENTLY — the same fixed-depth failure product discovery was rewritten
    # to avoid, still present in the test that guards the schema.
    packs = sorted(PRODUCTS.rglob("source_refs.yaml"))
    assert packs, "no products/**/source_refs.yaml found — has the layout changed?"
    for sr in packs:
        jsonschema.validate(as_json(load_yaml(sr)), schema)


def test_material_type_is_one_vocabulary_and_the_gate_enforces_it():
    """The schema had the enum; the gate only checked the field was NON-EMPTY.

    So CI refused a bad material_type while a standalone Gate 1 run accepted it, and reported the
    consequences instead of the cause: putting a PATH on the material_type line produced "0 materials
    of material_type:program_spec" and "which is material_type:<path>" — two indirect errors for one
    typo, neither naming the line to fix.
    """
    import json
    import pathlib
    import tempfile
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import source_manifest

    schema = json.loads((REPO / "governance" / "schemas" / "source_refs.schema.json")
                        .read_text(encoding="utf-8"))
    def find(node):
        if isinstance(node, dict):
            if "material_type" in node.get("properties", {}):
                return node["properties"]["material_type"]["enum"]
            for v in node.values():
                got = find(v)
                if got:
                    return got
        if isinstance(node, list):
            for v in node:
                got = find(v)
                if got:
                    return got
        return None
    assert sorted(find(schema)) == sorted(source_manifest.MATERIAL_TYPES), \
        "the schema and the gate disagree about what a material_type may be"

    with tempfile.TemporaryDirectory() as tmp:
        pack = pathlib.Path(tmp, "products", "oncology", "x", "202601")
        (pack / "handoff").mkdir(parents=True)
        def refs(mtype):
            (pack / "source_refs.yaml").write_text(
                "product: x\nspec_version: \"202601\"\nsource_materials:\n"
                "  - material_id: program_spec\n"
                f"    material_type: {mtype}\n"
                "    path_or_link: \"TBD — link to follow\"\n    role: spec\n    status: pending\n"
                "    ai_classification: sponsor_ai_eligible\n    classified_by: A. Person\n"
                "    classified_date: 2026-01-01\n    why_provisional: not approved yet\n",
                encoding="utf-8")
            return [e for e in source_manifest.check(tmp, "products/oncology/x/202601")
                    if "material_type" in e]

        assert refs("program_spec") == [], refs("program_spec")
        bad = refs("some/path/on/the/wrong/line")
        assert any("is not one of" in e and "path_or_link" in e for e in bad), bad


def test_the_gate1_schema_and_the_gate1_tool_require_the_same_fields():
    """Two statements of one requirement, on either side of a decision that matters.

    source_refs.yaml is checked twice — by jsonschema in CI, and by source_manifest.py, which is the
    tool that actually decides whether a pack's source is approved. Nothing tied the two together, so
    a field could be required by one and not the other. That is not hypothetical here: the schema and
    the tool BOTH had to be edited to move `ai_classification` off the reviewed-program_spec branch,
    and had only one been, a pack would have satisfied CI while Gate 1 refused it — or worse, passed
    Gate 1 with the field the AI boundary rests on left blank.

    Read off the schema's structure rather than restated: the field lists live in source_manifest,
    which is where the gate reads them from.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest
    schema = json.loads((GOV / "schemas" / "source_refs.schema.json").read_text(encoding="utf-8"))
    item = schema["properties"]["source_materials"]["items"]

    # The classification AND its attribution — one is useless without the other, so they are required
    # together on both sides. A schema that demanded the verdict but not its author would let a pack
    # pass CI carrying a judgment nobody owns.
    for field in [source_manifest.AI_CLASSIFICATION] + source_manifest.CLASSIFICATION_FIELDS:
        assert field in item["required"], (
            f"Gate 1 requires `{field}` of every material at every status; the schema does not, so a "
            f"pack missing it passes CI and fails the gate")
    # ...and the date is held to the same shape as every other date in the file, not a looser one.
    assert (item["properties"]["classified_date"].get("pattern")
            == item["properties"]["approval_date"].get("pattern")), \
        "classified_date accepts a date shape approval_date would refuse"
    def required_for(status, material_type):
        """What the SCHEMA demands of a material at this status AND type — every branch that applies.

        `material_type` is not optional. A branch may EXCLUDE a type (`not: {const: ai_extraction}`),
        and the first version's `value == spec.get("const")` read a missing value against a missing
        const as a match — so "any type" silently satisfied a branch that names one.
        """
        out = []
        for b in item["allOf"]:
            cond = b["if"]["properties"]

            def hit(key, value):
                spec = cond.get(key)
                if spec is None:
                    return True                              # this branch does not constrain the key
                if "const" in spec:
                    return value == spec["const"]
                if "enum" in spec:
                    return value in spec["enum"]
                if "not" in spec:
                    no = spec["not"]
                    return not (value == no.get("const") or value in (no.get("enum") or []))
                return True

            if hit("status", status) and hit("material_type", material_type):
                out += b["then"]["required"]
        return out

    assert set(source_manifest.POLICY_FIELDS) <= set(required_for("reviewed", "program_spec"))
    assert set(source_manifest.ATTESTATION_FIELDS) <= set(required_for("reviewed", "extraction_input"))
    # ...and NOT of an ai_extraction, which has a parent but no attester. Gate 1 exempts it; a
    # schema that still demanded `attested_by` would refuse in CI what the gate accepts, which is
    # the same parity failure pointing the other way.
    assert not (set(source_manifest.ATTESTATION_FIELDS)
                & set(required_for("reviewed", source_manifest.AI_EXTRACTION)))
    # The fields that BIND the approval to the artifact. `ai_readable` checks them itself; the schema
    # has to demand them too, or a pack ships an approved-looking extraction that names no bytes.
    assert set(source_manifest.AI_EXTRACTION_FIELDS) <= set(
        required_for("reviewed", source_manifest.AI_EXTRACTION))

    # EVERY status in the enum crossed with EVERY material_type, not the two branches that happened to
    # exist. Python requires `why_provisional` of every non-reviewed status, and the schema demanded it
    # only of `pending` — so a `reference_only` material without one passed CI and failed Gate 1. The
    # old test asserted the `pending` branch alone, which is exactly why it reported parity it had not
    # established, and it took no material_type at all, so the ai_extraction branch was invisible to it.
    for mtype in item["properties"]["material_type"]["enum"]:
        for status in item["properties"]["status"]["enum"]:
            if status != source_manifest.REVIEWED:
                want = source_manifest.PENDING_FIELDS
            elif mtype == source_manifest.AI_EXTRACTION:
                want = source_manifest.AI_EXTRACTION_APPROVAL_FIELDS
            else:
                want = source_manifest.APPROVAL_FIELDS
            missing = [f for f in want if f not in required_for(status, mtype)]
            assert not missing, (f"material_type '{mtype}' at status '{status}': Gate 1 requires "
                                 f"{missing} and the schema does not, so a pack missing them passes "
                                 f"CI and fails the gate")
    assert set(item["properties"][source_manifest.AI_CLASSIFICATION]["enum"]) == set(
        source_manifest.AI_CLASSES), "the classification vocabulary differs between schema and gate"


def test_no_test_dir_shadows_the_stdlib_platform_module():
    """A test file under platform/ must not be NAMED after it.

    pytest's importlib mode (pytest.ini) names a module after its path, so platform/x/test_y.py is
    imported as `platform.x.test_y` — and pytest re-imports the parent `platform` by path, because the
    standard library's platform is a plain module with no `__path__`. sys.modules["platform"] then
    points at this repo's directory, and the next dependency to call `platform.python_implementation()`
    (jsonschema -> attrs does) dies with AttributeError in an unrelated test.

    A directory avoids that by carrying `__init__.py` (which roots the module name at platform/) or by
    being excluded from collection. New test directories are the way this quietly comes back.
    """
    ini = (REPO / "pytest.ini").read_text(encoding="utf-8")
    assert "--import-mode=importlib" in ini, "pytest.ini no longer sets importlib mode; re-check this"
    excluded = [line.split("=", 1)[1].strip() for line in ini.splitlines()
                if line.startswith("norecursedirs")]
    excluded = [e for spec in excluded for e in spec.split()]
    for d in sorted({p.parent for p in FRAMEWORK.rglob("test_*.py")}):
        rel = d.relative_to(REPO).as_posix()
        if any(rel == e or rel.startswith(e + "/") for e in excluded):
            continue
        assert (d / "__init__.py").exists(), (
            f"{rel} holds test files but has no __init__.py, so pytest would name them "
            f"'platform.…' and shadow the standard library's platform module. Add an empty "
            f"__init__.py, or exclude the directory via norecursedirs in pytest.ini.")


def test_codeowners_present_and_routes_governance():
    co = REPO / "CODEOWNERS"
    assert co.exists(), "root CODEOWNERS is missing"
    text = co.read_text(encoding="utf-8")
    assert "/governance/" in text and "/docs/" in text, "CODEOWNERS does not route /governance/ + /docs/"


def test_changelog_documents_active_spec_version():
    # Version-bump governance triangle: config spec_version <-> registry current_spec_version (the
    # lineage test) <-> CHANGELOG. Here: every active product's CHANGELOG must mention its current
    # spec_version, so a contract bump can't land without a documented entry.
    for t in load_yaml(PRODUCTS / "registry.yaml")["tumors"]:
        if t.get("status") != "active":
            continue
        sv = str(t.get("current_spec_version", ""))
        assert YYYYMM.match(sv), f"active {t['code']}: registry current_spec_version not YYYYMM: {sv!r}"
        # Family from the REGISTRY, as engine.config.product_dir already does — hardcoding
        # "oncology" here would have failed the first heme product (DLBCL/COTA) on a path
        # assumption, not on anything about its changelog.
        ch = PRODUCTS / t.get("family", "oncology") / t["slug"] / "CHANGELOG.md"
        assert ch.exists(), f"active {t['code']} missing CHANGELOG.md"
        assert sv in ch.read_text(encoding="utf-8"), f"{t['code']} CHANGELOG.md does not document spec_version {sv}"


def test_the_approval_examples_state_every_field_their_gate_requires():
    """TUMOR_TEMPLATE's approval forms must not drift from the gates' field tuples.

    The Gate 2 form already had: the gate grew `approved_coverage_sha256` and the example kept four
    fields, so every new tumour would have copied a form that fails Gate 2 the moment it reaches
    approval — the template-drift failure the framework exists to prevent, in the framework's own
    template. All three forms are checked from one loop so Gate 4's and Gate 6's cannot repeat it.

    Gate 6's example was MISSING entirely for as long as the gate existed. The six fields were stated
    in `product_gates.RELEASE_APPROVAL_FIELDS`, described in the runner's printout and named in
    products/OPERATIONS.md — so a person could reconstruct the form from Python constants and a
    notebook message, which is not the same as having one. Gate 2 and Gate 4 both ship a form; the one
    approval that is about the data anybody actually receives did not.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates
    handoff = REPO / "platform" / "TUMOR_TEMPLATE" / "handoff"
    for form, fields, gate in (
            (product_gates.CONTRACT_APPROVAL, product_gates.CONTRACT_APPROVAL_FIELDS, "Gate 2"),
            (product_gates.CONFIGURATION_APPROVAL, product_gates.CONFIGURATION_APPROVAL_FIELDS,
             "Gate 4"),
            (product_gates.RELEASE_APPROVAL, product_gates.RELEASE_APPROVAL_FIELDS, "Gate 6")):
        name = Path(form).name.replace(".yaml", ".example.yaml")
        example = handoff / name
        assert example.exists(), f"{name} is gone — a new pack has nothing to copy for {gate}"
        stated = {m.group(1) for m in
                  re.finditer(r"(?m)^([a-z0-9_]+):", example.read_text(encoding="utf-8"))}
        missing = [f for f in fields if f not in stated]
        assert not missing, (f"{name} does not state {missing} — a pack copying it would fail "
                             f"{gate} at approval")


def test_a_deployment_edit_does_not_void_the_scientific_approval():
    """WHERE THE PRODUCT WRITES IS NOT A STATEMENT ABOUT WHAT IT MEANS.

    `run:` — which cut, which schemas, which table, how to write — used to sit in
    `data_product.yaml`, which put it inside `config_bundle_sha256`, the digest a Gate 4 approval
    binds to. So pointing the job at a different output schema moved the hash and INVALIDATED an
    RWP approval of the science. Measured before the split: editing only `run.output_schema` took
    the digest from e60b75cd… to f194958d…. Two questions, two owners, one hash.

    It is now `config/pipeline.yaml`, excluded from the approved graph by NAME. Excluded by name
    rather than by inspecting which keys inside a file look environmental — a function guessing that
    would be a second, worse definition of the boundary, and it would guess wrong the first time a
    pack put a cohort rule next to a schema name.

    BOTH DIRECTIONS ARE ASSERTED. A test that only checked the environment edit is satisfied by a
    digest that has stopped responding to anything at all.
    """
    import re as _re
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates as pg

    packs = [str(REPO / p) for p in pg.products(str(REPO))
             if (REPO / p / "config" / _PIPELINE_REL).exists()]
    assert packs, "no pack has split its environment file — this test would check nothing"

    for src in packs:
        base = pg.config_bundle_sha256(src)
        graph, approved = pg.pack_yaml(src), pg.scientific_yaml(src)
        # The build READS it (so it deploys); Gate 4 does not approve it.
        assert pg.ENVIRONMENT_YAML in graph, f"{src}: the environment file is not in the config graph"
        assert pg.ENVIRONMENT_YAML not in approved, \
            f"{src}: the environment file is still inside what Gate 4 approves"
        assert [f for f in graph if f != pg.ENVIRONMENT_YAML] == approved, \
            "scientific_yaml is not pack_yaml minus one file — two traversals that can disagree"

        def edited(rel, sub):
            tmp = Path(_tf.mkdtemp())
            try:
                dst = tmp / "p"
                _sh.copytree(src, dst)
                p = dst / Path(rel)
                t = p.read_text(encoding="utf-8")
                t2 = sub(t)
                assert t2 != t, f"{rel}: edit was a no-op, so the assertion below proves nothing"
                p.write_text(t2, encoding="utf-8")
                return pg.config_bundle_sha256(str(dst))
            finally:
                _sh.rmtree(tmp, ignore_errors=True)

        env = edited(pg.ENVIRONMENT_YAML,
                     lambda t: _re.sub(r"(?m)^(\s*output_schema:).*$", r"\1 somewhere_else", t))
        assert env == base, \
            f"{src}: a deployment-only edit still moves the Gate 4 digest and voids the approval"

        sci = edited("config/data_product.yaml", lambda t: t + "\n# a scientific edit\n")
        assert sci != base, \
            f"{src}: the digest no longer responds to a change in the approved configuration"


def test_gate_3_evidence_is_bound_to_the_delivery_it_was_measured_on():
    """THE OTHER HALF OF THE SPLIT, AND THE HALF IT BROKE.

    Taking `run:` out of the Gate 4 digest was right. It also took `data_format`, `source_schema`
    and `refresh` out of what GATE 3 pins — and those decide which physical data gets read.
    `data_format` selects a `formats:` overlay carrying its own `sources` map and column renames, so
    a verdict measured on EDM/schema A/cut 2026m06 went on matching a build reading Panoramic under
    a renaming overlay, because `sha256(config/data_product.yaml)` had not moved.

    Two gates, two subjects, asserted in both directions: the delivery digest MOVES on a delivery
    binding and the scientific digest does not, and vice versa for a variables-pack edit. A test
    checking only the first is satisfied by a digest that responds to everything.
    """
    import re as _re
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates as pg

    # ONE resolver of the bindings, ONE merge of the two files — the same function OBJECTS the
    # build uses. A gate reading `run.data_format` itself would miss the top-level fallback that
    # Config honours, and answer a different question with the same name.
    from engine import config as ecfg
    assert pg._delivery_bindings is ecfg.delivery_bindings
    assert pg._merged_raw is ecfg.merged_raw
    assert set(ecfg.delivery_bindings({})) == set(ecfg.DELIVERY_KEYS)
    assert ecfg.delivery_bindings({"data_format": "Panoramic"})["data_format"] == "Panoramic", \
        "the top-level fallback Config honours is not honoured here"

    packs = [str(REPO / p) for p in pg.products(str(REPO))
             if (REPO / p / "config" / _PIPELINE_REL).exists()]
    assert packs, "no pack has split its environment file — this test would check nothing"
    formats_seen, singles, unions = [], [], []

    for src in packs:
        def edited(rel, sub, fn):
            tmp = Path(_tf.mkdtemp())
            try:
                dst = tmp / "p"
                _sh.copytree(src, dst)
                p = dst / Path(rel)
                t = p.read_text(encoding="utf-8")
                t2 = sub(t)
                assert t2 != t, f"{rel}: edit was a no-op, so the assertion below proves nothing"
                p.write_text(t2, encoding="utf-8")
                return fn(str(dst))
            finally:
                _sh.rmtree(tmp, ignore_errors=True)

        delivery, science = pg.delivery_sha256(src), pg.config_bundle_sha256(src)
        assert delivery != science, f"{src}: one digest is answering both questions"

        # A DELIVERY BINDING. Moves Gate 3's subject; leaves the scientific approval standing.
        # `refresh` because EVERY product resolves tables with it — `source_schema` is exercised
        # separately below, since a `source_union` reads its member schemas from the union block and
        # is deliberately not held to it.
        cut = lambda t: _re.sub(r"(?m)^(\s*refresh:).*$", r"\1 another_cut", t)  # noqa: E731
        assert edited(pg.ENVIRONMENT_YAML, cut, pg.delivery_sha256) != delivery, \
            (f"{src}: pointing the run at a different CUT leaves the Gate 3 digest unmoved — "
             f"evidence for one delivery keeps matching a build reading another")
        assert edited(pg.ENVIRONMENT_YAML, cut, pg.config_bundle_sha256) == science, \
            f"{src}: a delivery binding moves the Gate 4 digest and voids the scientific approval"

        # `source_schema` — but only where the product actually reads it. Under a union the member
        # schemas come from `source_union.members`, so hashing `run.source_schema` there would let a
        # field the engine ignores invalidate evidence that is still true.
        import engine.config as _ecfg
        _raw = _ecfg.merged_raw(os.path.join(src, "config", "data_product.yaml"))
        sch = lambda t: _re.sub(r"(?m)^(\s*source_schema:).*$", r"\1 another_delivery", t)  # noqa: E731
        moved = edited(pg.ENVIRONMENT_YAML, sch, pg.delivery_sha256)
        if "source_schema" in _ecfg.delivery_keys(_raw):
            assert moved != delivery, f"{src}: a different SOURCE SCHEMA leaves the digest unmoved"
            singles.append(src)
        else:
            assert moved == delivery, \
                (f"{src} declares a source_union, so run.source_schema is unused — hashing it "
                 f"invalidates source evidence on an edit the engine never reads")
            unions.append(src)

        if _re.search(r"(?m)^\s*data_format:", Path(src, *pg.ENVIRONMENT_YAML.split("/"))
                      .read_text(encoding="utf-8")):
            fmt = lambda t: _re.sub(r"(?m)^(\s*data_format:).*$", r"\1 Panoramic", t)  # noqa: E731
            assert edited(pg.ENVIRONMENT_YAML, fmt, pg.delivery_sha256) != delivery, \
                (f"{src}: selecting a different `formats:` overlay — its own sources map and column "
                 f"renames — leaves the Gate 3 digest unmoved")
            assert edited(pg.ENVIRONMENT_YAML, fmt, pg.config_bundle_sha256) == science, src
            formats_seen.append(src)

        # ...and an OUTPUT binding moves neither. It decides where rows land, not what was read.
        out = lambda t: _re.sub(r"(?m)^(\s*output_schema:).*$", r"\1 somewhere_else", t)  # noqa: E731
        assert edited(pg.ENVIRONMENT_YAML, out, pg.delivery_sha256) == delivery, \
            (f"{src}: the OUTPUT schema moves the Gate 3 digest — re-running live source evidence "
             f"because a table was renamed is the false invalidation the split removed")

        # THE TABLE-NAME TEMPLATE. `run.source_layout` renames every physical table this check
        # looked at — `{schema}.t_{stem}_{refresh}` is a documented per-product override — while
        # refresh, source_schema, data_format and the root config all stay put. Left out of the
        # delivery identity it was a silent way to move the tables under accepted evidence.
        lay = lambda t: t.replace("run:\n", "run:\n  source_layout: \"{schema}.x_{stem}\"\n", 1)  # noqa: E731
        assert edited(pg.ENVIRONMENT_YAML, lay, pg.delivery_sha256) != delivery, \
            f"{src}: run.source_layout is outside the Gate 3 digest — it renames every table"
        assert edited(pg.ENVIRONMENT_YAML, lay, pg.config_bundle_sha256) == science, src

        # A VARIABLES pack is the science: Gate 4's subject, not Gate 3's. It resolves no table.
        var = [f for f in pg.scientific_yaml(src) if f.startswith("variables/")]
        assert var, f"{src}: no variables pack — the last assertion would prove nothing"
        add = lambda t: t + "\n# a scientific edit\n"  # noqa: E731
        assert edited(var[0], add, pg.config_bundle_sha256) != science, var[0]
        assert edited(var[0], add, pg.delivery_sha256) == delivery, \
            (f"{src}: editing {var[0]} invalidates live source evidence, which cannot have looked "
             f"at it — the same false invalidation, pointed at the other gate")

    assert formats_seen, ("no pack states `data_format` in its environment file, so the overlay "
                          "case above never ran — it is the binding that changes column names")
    # BOTH SHAPES, named rather than assumed. The union branch is the one that regressed once; a
    # repository with only single-schema packs would exercise the rule in one direction only.
    assert singles and unions, (f"only one product shape was exercised — single={singles}, "
                                f"union={unions}; the source_schema rule is untested for the other")


def test_the_environment_half_may_not_be_declared_twice():
    """TWO FILES DISAGREEING ABOUT `output_schema` IS A QUESTION ABOUT WHERE THE PRODUCT WRITES.

    `load_config` merges `config/pipeline.yaml` over `data_product.yaml`. A precedence rule would
    resolve a duplicate `run:` silently — and the losing file would keep sitting there looking
    authoritative, which is how a run lands in a schema nobody reviewed. It refuses instead.
    """
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform"))
    from engine.config import load_config

    src = REPO / "products" / "oncology" / "prostate" / "202606"
    tmp = Path(_tf.mkdtemp())
    try:
        dst = tmp / "p"
        _sh.copytree(src, dst)
        cfg = dst / "config" / "data_product.yaml"
        # The pack loads cleanly to begin with, or the refusal below proves nothing.
        load_config(str(cfg), overrides={"run.refresh": "x", "run.source_schema": "s",
                                         "run.output_schema": "o"})
        cfg.write_text(cfg.read_text(encoding="utf-8") + "\nrun:\n  output_schema: sneaky\n",
                       encoding="utf-8")
        try:
            load_config(str(cfg))
            raise AssertionError("a `run:` block in BOTH files was silently resolved")
        except ValueError as e:
            assert "BOTH" in str(e) and "run" in str(e), e
    finally:
        _sh.rmtree(tmp, ignore_errors=True)


def test_both_engines_load_the_same_environment_file():
    """THE TWO ENGINES RUN THE SAME CONFIG, SO ONE MUST NOT SEE A FILE THE OTHER DOES NOT.

    `engine-r/` exists to cross-validate the Python build on the SAME YAML. Split the environment
    half out of `data_product.yaml` and teach only Python to merge it, and the R engine silently
    loses `run:` — the comparison keeps running and stops comparing the same thing.

    THIS IS A SOURCE CHECK, AND DELIBERATELY LABELLED AS ONE. R's `load_config` cannot be executed
    here: it needs the `yaml` R package, which is not installed, and `test_r_parity` drives the R
    compilers from the PYTHON loader — so R's own `load_config` is covered by no executing test at
    all, before or after this change. That is a real coverage gap, recorded rather than papered
    over; what follows is the strongest check available without the package, not a substitute for
    running it.
    """
    sys.path.insert(0, str(REPO / "platform"))
    from engine.config import PIPELINE
    r = (REPO / "platform" / "engine-r" / "config.R").read_text(encoding="utf-8")
    assert f'PIPELINE <- "{PIPELINE}"' in r, \
        f"the R loader does not name {PIPELINE} — it will not merge the environment half"
    body = r[r.index("load_config <- function"):]
    # The IDENTIFIER, not the filename literal — the R side must reference the constant declared
    # above, exactly as the Python side imports it rather than respelling it.
    for needed, why in (("PIPELINE", "the R loader never looks for the environment file"),
                        ("file.exists", "the R loader does not treat the environment file as optional"),
                        ("intersect(names(env), names(raw))",
                         "the R loader does not refuse a key declared in both files")):
        assert needed in body, why


def test_the_contract_declares_the_published_ads_and_something_compares_it():
    """IS THE COLUMN ACTUALLY IN THE PRODUCT? Nothing asked, and both sides already knew.

    Every record carries `output: {physical_name, target_published_name, type, nullable, role}` and
    `publish: {ads: …}`, so the contract states which columns the ADS contains — 154 of them on
    prostate/202606, in specification order. `assemble.build` meanwhile returns `ads.distinct()`
    with no final select, so what ships is whatever the stages left on the frame. G-ADS-WHITELIST is
    that gap and NAME-ALIGN's own text names the fix: "the final ADS must be an approved ordered
    column whitelist".

    `published_surface` is the derivation; `published_surface_errors` is the comparison. Both
    directions, because they are different defects: an internal helper in the delivered ADS, versus
    a promised column the build does not produce.

    THE ORDER IS THE CONTRACT'S. Records are written in specification order, which is the one
    ordering with a provenance — sorting here would invent a new published layout on every rename.

    ACCOUNTED, NOT CLEAN, while an output decision owns the question. CODE-ALIGN and NAME-ALIGN are
    open on prostate/202606, so the divergence rides in `surface_notes` and is printed on every
    --check without failing CI. It becomes an error the moment those close, which is exactly when
    the names are supposed to be settled.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_binding as cb
    import contract_lint as cl

    pack = str(PRODUCTS / "oncology" / "prostate" / "202606")
    text = cl.read(os.path.join(pack, "handoff", "FUNCTIONAL_CONTRACT.md"))
    surface = cl.published_surface(text)
    assert surface, "the contract declares no published surface — the derivation reads nothing"
    assert all(r["physical_name"] for r in surface), "a published column with no physical name"

    # ONE definition of what published means, and both halves are required: a record may be
    # `role: published` with `publish.ads: undecided` — intended, not yet agreed to emit.
    ids = [r["variable_id"] for r in surface]
    assert len(ids) == len(set(ids)), "the published surface repeats a variable_id"
    for r in cl.records(text):
        o, p_ = cl._inline(r, "output"), cl._inline(r, "publish")
        if cl._kv(o, "role") == cl.PUBLISHED_ROLE and cl._kv(p_, "ads") != cl.PUBLISHED_ADS:
            nm = (cl._kv(o, "physical_name") or "").lower()
            assert nm not in {x["physical_name"] for x in surface}, \
                f"{nm} is in the surface with publish.ads != {cl.PUBLISHED_ADS}"

    # ORDER is the contract's own record order, not sorted.
    assert [r["physical_name"] for r in surface] != sorted(r["physical_name"] for r in surface), \
        "the surface is alphabetical — the contract's specification order was not preserved"

    # THE COMPARISON RUNS, and today lands in the accounted branch.
    notes = []
    errs = cb.published_surface_errors(pack, notes=notes)
    open_out = [d for d in cl.open_decisions(pack) if d in cl.OUTPUT_DECISIONS]
    assert open_out, "no output decision is open — this pack can no longer exercise the accounted path"
    assert errs == [], errs
    assert any("ACCOUNTED" in n for n in notes), notes
    assert any("emitted column(s) no record publishes" in n for n in notes), notes

    # ...and provenance stamps are NOT reported as leaks, from the stage that adds them.
    sys.path.insert(0, str(REPO / "platform"))
    from engine.stages.assemble import PROVENANCE_STAMPS
    assert set(PROVENANCE_STAMPS) == {"data_product_id", "spec_version", "data_refresh"}
    for stamp in PROVENANCE_STAMPS:
        assert not any(stamp in n for n in notes), f"{stamp} reported as a leaked column"


def test_an_inline_contract_field_is_read_whole_not_to_the_first_digit():
    """`_kv` stopped at the first non-letter, so `physical_name: lot1sd_mhspc` read as `lot`.

    Every caller until now reads a controlled-vocabulary WORD — role, name_status, requirement,
    implementation, validation — so the truncation never bit. It was waiting for the first caller to
    read a NAME, which is what the published-surface derivation does. Widening only to digits would
    have fixed the name and left `codes: n/a` reading as `n`: the fix that looks complete and is not.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint as cl
    body = ("physical_name: lot1sd_mhspc, target_published_name: LOT1SD_MHSPC, type: date, "
            "codes: n/a, role: published")
    assert cl._kv(body, "physical_name") == "lot1sd_mhspc"
    assert cl._kv(body, "target_published_name") == "LOT1SD_MHSPC"
    assert cl._kv(body, "codes") == "n/a"
    assert cl._kv(body, "role") == "published"
    # `name:` must not match inside `physical_name:` — they are different fields.
    assert cl._kv("physical_name: abc, name: xyz", "name") == "xyz"
    assert cl._kv(None, "role") is None


def test_gate_4_refuses_an_approval_over_config_values_nobody_confirmed():
    """THE TEMPLATE'S SEEDED VALUES ARE EXAMPLES, AND A DIGEST CANNOT TELL THEM FROM CHOSEN ONES.

    `variables/*.yaml` ships with an ECOG window, age bands, a BMI method, stage groupings, a
    death-date conflict policy, `max_lines`, follow-up and visit-recency day counts. They are real
    values rather than REPLACE_ME because a config full of placeholders cannot be linted or executed
    — which makes them plausible, tumour-specific requirements wearing the appearance of framework
    constants. The onboarding doc used to say the demographics/ECOG/vitals/outcomes defaults were
    "tumour-agnostic — usually leave them", which is exactly the belief this refuses.

    Neither existing Gate 4 check catches it. `approved_configuration_bundle_sha256` binds WHICH
    bytes were approved, and a scaffold value hashes as well as a confirmed one. `contract_binding`
    asks whether the config BLOCK is claimed by a contract record, never whether the number inside it
    is the one that record asked for.

    So the check is `status: scaffold` — the pack's own statement that a file was copied rather than
    chosen. The template sets it, `oc/202606` still carries it, and prostate/202606 moved every file
    to `active`, so the vocabulary is already in use and this only makes it load-bearing.

    Driven through a FIXTURE that reaches `configuration: approved`, because no pack claims that
    today: over the real repo this check would never execute and would pass however it was written.
    """
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates as pg

    src = PRODUCTS / "oncology" / "prostate" / "202606"
    tmp = Path(_tf.mkdtemp())
    try:
        pack = tmp / "pack"
        _sh.copytree(src, pack, ignore=_sh.ignore_patterns("__pycache__", "reference", "prog_spec"))
        graph = pg.pack_yaml(str(pack))
        assert graph, "the fixture pack has no config graph — this test would check nothing"
        m = {"configuration": "approved", "contract": "approved", "source": "reviewed"}

        # BASELINE: prostate's files all say `active`, so only the ordinary approval-record errors
        # appear. If `scaffold` were reported here the assertion below would prove nothing.
        base = pg.configuration_approval_errors(str(pack), "fixture", m)
        assert not any("scaffold" in e for e in base), base

        # ...now put ONE file back to the template's state.
        target = next(f for f in graph if "variables" in f)
        full = Path(target) if os.path.isabs(target) else pack / target
        full.write_text(re.sub(r"(?m)^status: active\b", "status: scaffold",
                               full.read_text(encoding="utf-8")), encoding="utf-8")
        why = pg.configuration_approval_errors(str(pack), "fixture", m)
        assert any("scaffold" in e for e in why), \
            f"Gate 4 approved a configuration carrying unconfirmed template values: {why}"

        # ...and it is NOT raised below the approved level — a pack still authoring its config is
        # supposed to say scaffold, and a gate that nags at `draft` gets ignored at `approved`.
        assert pg.configuration_approval_errors(
            str(pack), "fixture", dict(m, configuration="draft")) == []
    finally:
        _sh.rmtree(tmp, ignore_errors=True)


def test_gate_2_refuses_an_approval_over_a_decision_nobody_is_recorded_as_answering():
    """THE SCIENTIFIC JUDGMENT WAS THE ONE APPROVAL THAT BOUND TO NO PERSON.

    Gate 1 names a classifier and a date. Gate 2 and Gate 4 name an approver and a reviewer. Gate 6
    names an approver and a validator. A RESOLVED decision — where the actual clinical or
    methodological call is made — recorded an answer and a status and nobody at all. `Owner` is not
    that: it says who the question was put to while it was open, and it does not change when someone
    replies.

    The approval form hashes DECISIONS.md, so a LATER edit is caught. That is a different guarantee:
    a hash over an unattributed answer only freezes it. The realistic path is a decision packet going
    out, an answer coming back in a meeting, and an analyst typing it in — with nothing recording
    which of several people decided.

    CHECKED AT `approved`, NOT IN THE STRUCTURAL LINT, and the fixture proves both halves. Three
    RESOLVED decisions exist across the repository and none names an approver; linting this everywhere
    would turn three packs red over a field nobody here may fill in, because inventing an approver is
    exactly what this framework forbids a tool to do.
    """
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint as cl
    import product_gates as pg

    # ONE vocabulary, imported — not a second list of spellings here. The registers already disagree
    # ("Approved answer" vs "Resolution"), which is how a resolved answer went missing once before.
    assert pg.APPROVER_COLUMNS is cl.APPROVER_COLUMNS
    assert pg.APPROVAL_DATE_COLUMNS is cl.APPROVAL_DATE_COLUMNS

    tmp = Path(_tf.mkdtemp())
    try:
        pack = tmp / "pack"
        (pack / "handoff").mkdir(parents=True)
        reg = pack / "handoff" / "DECISIONS.md"
        head = ("| ID | Question | Evidence | Owner | Resolution | Approved by | Approval date | "
                "Status |\n|---|---|---|---|---|---|---|---|\n")

        def row(approver, date, status="RESOLVED"):
            return f"| D-1 | Q? | — | RWP | the answer | {approver} | {date} | {status} |\n"

        # A COMPLETE row passes — otherwise every assertion below proves only that the check fires.
        reg.write_text(head + row("A Person", "2026-07-01"), encoding="utf-8")
        assert pg.unaccountable_resolutions(str(pack), "fixture") == []

        for approver, date, expect in (
                ("", "2026-07-01", "blank"),            # no name
                ("A Person", "", "blank"),              # no date
                ("TODO", "2026-07-01", "placeholder"),  # a placeholder is not an answer
                ("A Person", "whenever", "not a date")):
            reg.write_text(head + row(approver, date), encoding="utf-8")
            why = pg.unaccountable_resolutions(str(pack), "fixture")
            assert any(expect in w for w in why), (approver, date, why)

        # ...an ABSENT COLUMN is reported differently from a blank cell, because the repair differs:
        # extend the header, versus fill one cell.
        reg.write_text("| ID | Question | Evidence | Owner | Resolution | Status |\n"
                       "|---|---|---|---|---|---|\n"
                       "| D-1 | Q? | — | RWP | the answer | RESOLVED |\n", encoding="utf-8")
        why = pg.unaccountable_resolutions(str(pack), "fixture")
        assert any("no `Approved by` column" in w for w in why), why

        # ...and an OPEN row demands nothing. Neither do WITHDRAWN/SUPERSEDED: neither asserts an
        # answer, so requiring an approver would be demanding a signature on a retraction.
        for status in ("OPEN", "WITHDRAWN", "SUPERSEDED"):
            reg.write_text(head + row("", "", status), encoding="utf-8")
            assert pg.unaccountable_resolutions(str(pack), "fixture") == [], status
    finally:
        _sh.rmtree(tmp, ignore_errors=True)

    # ...and it is wired into Gate 2's approval, not merely defined. The real registers each carry a
    # RESOLVED decision with no approver, so this must be reachable — and must stay dormant below
    # `approved`, or three packs go red over a field no tool may fill in.
    # `products()` returns ROOT-RELATIVE paths and these suites run from platform/, so they are
    # joined back onto REPO — the CWD trap docs/ENGINEERING.md names, which would otherwise make every pack
    # below read as having no register and this whole block pass vacuously.
    packs = [str(REPO / p) for p in pg.products(str(REPO))]
    live = [p for p in packs if pg.unaccountable_resolutions(p, p)]
    assert live, "no pack has an unattributed RESOLVED decision — the wiring check below is vacuous"
    for p in live:
        m = {"contract": "coverage_complete", "configuration": "draft", "source": "provisional"}
        assert not any("RESOLVED" in e for e in pg.contract_approval_errors(p, p, m)), \
            f"{p}: raised below contract:approved"
        raised = pg.contract_approval_errors(p, p, dict(m, contract="approved"))
        assert any("RESOLVED" in e for e in raised), \
            f"{p}: contract:approved does not ask who answered the resolved decisions"


def test_the_status_page_composes_the_owners_and_recomputes_nothing():
    """A STATUS PAGE'S ONE UNACCEPTABLE FAILURE IS REPORTING A PRODUCT HEALTHIER THAN IT IS.

    `status.py` answers "where is this, and who owes what next" for someone who is not going to run
    the six gate tools. That is only safe while every number and verdict in it comes from the module
    that owns it — a second implementation of a count drifts, and it drifts towards optimism, because
    a re-derivation that misses a blocker looks like a pack with fewer blockers.

    So the assertions are OBJECT IDENTITY, not agreement: the same function objects the gates
    themselves call. Two tools that merely agree today are the shape this repository has paid for
    three times.

    It must also not turn an ABSENCE into a clean result — the recurring defect here. A pack with no
    contract has no `records` key at all (`finalize.facts` omits it rather than reporting 0), and a
    `.get("records", 0)` would render "0 records traced" for a pack that has not started, which reads
    identically to one whose extraction found nothing.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint
    import dry_run
    import finalize
    import product_gates
    import source_manifest
    import status

    # ONE definition of each governed answer, shared as the same object.
    assert status.source_manifest.releasable is source_manifest.releasable
    assert status.source_manifest.source_status is source_manifest.source_status
    assert status.product_gates.maturity is product_gates.maturity
    assert status.contract_lint.open_decisions is contract_lint.open_decisions
    assert status.finalize.facts is finalize.facts
    assert status.dry_run.latent is dry_run.latent

    # ...and it states a gate→role for all six, or the column it exists to add is blank somewhere.
    assert sorted(status.OWNER) == [1, 2, 3, 4, 5, 6], status.OWNER
    assert all(v.strip() for v in status.OWNER.values())

    packs = [str(REPO / p) for p in product_gates.products(str(REPO))]
    assert packs, "no packs discovered — every assertion below would be vacuous"

    scaffold = [p for p in packs if finalize.facts(p).get("records") is None]
    assert scaffold, "no contract-less pack — the absence case below would not be exercised"

    for p in packs:
        rel = status._rel(str(REPO), p)
        gs = status.gates(str(REPO), p)
        assert [n for n, *_ in gs] == [1, 2, 3, 4, 5, 6], (p, gs)

        # THE VERDICT MATCHES ITS OWNER, gate by gate, rather than being recomputed from claims.
        _ok, why = source_manifest.releasable(str(REPO), rel)
        for n, _title, _state, blockers in gs:
            owner_said = [w for w in why if w.startswith(f"Gate {n}")]
            for w in owner_said:
                assert w in blockers, f"{p}: status drops a Gate {n} blocker releasable() reports: {w}"

        # ...and Gate 6 is never reported clear while Gates 1-4 are not, which is the one
        # combination a reader would act on.
        g6 = next(b for n, _t, _s, b in gs if n == 6)
        if why:
            assert g6, f"{p}: Gate 6 shows no blocker while Gates 1-4 have {len(why)}"

        # A contract-less pack must not read as "0 traced" — it must say nothing was drafted.
        out = status.render(str(REPO), p)
        if finalize.facts(p).get("records") is None:
            assert "no contract drafted yet" in out, p
            assert "0 contract record(s)" not in out, f"{p}: an absence rendered as a zero"

    # The one-line sweep must NAME a pack it cannot read rather than omitting it: a status page that
    # silently skips a broken pack reports fewer problems than exist.
    src = (REPO / "platform" / "tools" / "status.py").read_text(encoding="utf-8")
    assert "COULD NOT BE READ" in src, "status.py has no branch for an unreadable pack"


def test_the_status_page_can_actually_reach_done():
    """EVERY PACK IS BLOCKED AT GATE 1, SO NOTHING EXERCISED THE POSITIVE PATH — AND IT WAS BROKEN.

    `status.py` shipped with four state bugs that a sweep over the real repository could not see,
    because a gate that never goes green in any pack has its green branch tested by nothing:

      Gate 1  compared `source_status()` against "reviewed"; it returns "approved". A pack whose
              specification really had been approved would have read "in progress" forever.
      Gate 3  had no `done` branch at all — only "a verdict file exists" / "it does not" — so
              `next_action` would have parked on Gate 3 permanently for a product that finished it.
      Gate 5  claimed in its comment to derive from per-record validation status and actually asked
              only whether a contract file existed, then printed "no build has been validated"
              unconditionally.
      the sweep labelled a Gates-1-4 pass "RELEASE-READY", which is the overstatement the rest of
              this repository is careful to avoid: `releasable()` is a PACK answer over Gates 1-4 and
              says nothing about a cut's validation or a named approval of a build.

    This drives a real pack forwards in a temp copy and asserts each gate CAN report done. The four
    bugs above are each caught by one assertion here; none is caught by any sweep over `products/`.
    """
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import yaml

    import product_gates
    import source_manifest
    import status

    # THE VOCABULARY `status` COMPARES AGAINST IS THE ONE ITS OWNER RETURNS. Pinned, because the
    # Gate 1 bug was exactly a comparison against a word that function never returns.
    live = [str(REPO / p) for p in product_gates.products(str(REPO))]
    seen = {source_manifest.source_status(p) for p in live}
    assert seen <= {"approved", "provisional", None}, seen

    tmp = Path(_tf.mkdtemp())
    try:
        root = tmp / "repo"
        for name in ("platform", "products", "resources", "governance", "databricks.yml"):
            s = REPO / name
            if s.is_dir():
                _sh.copytree(s, root / name, ignore=_sh.ignore_patterns("__pycache__", "reference"))
            else:
                _sh.copy2(s, root / name)
        rel = "products/oncology/prostate/202606"
        pack = root / rel

        def state(n):
            return next(s for g, _t, s, _b in status.gates(str(root), str(pack)) if g == n)

        # BASELINE — nothing is done, or the assertions below prove nothing.
        assert state(1) != "done", "fixture starts with Gate 1 already done"

        # GATE 1 goes done when the AUTHORITATIVE specification is reviewed. Driven through the real
        # register rather than by writing a status word: `source_status` reads the authoritative
        # material, so the fixture has to make that material reviewed.
        # ...and it needs the WHOLE reviewed-state record, not just the word. Gate 1 requires
        # revision, sha256, approval_date, approved_by, data_refresh, rwb_qc_reference and a
        # path_or_link that resolves AND still hashes to the recorded digest. Writing only
        # `status: reviewed` leaves seven Gate 1 reasons standing — which is the gate working, and
        # is why this fixture supplies real bytes and a real digest rather than a status word.
        refs = pack / "source_refs.yaml"
        doc = yaml.safe_load(refs.read_text(encoding="utf-8"))
        spec = source_manifest.authoritative(str(pack))
        assert spec, "fixture pack has no authoritative specification — Gate 1 cannot be driven"
        stand_in = pack / "prog_spec" / "fixture_spec.txt"
        stand_in.parent.mkdir(parents=True, exist_ok=True)
        stand_in.write_bytes(b"fixture specification bytes\n")
        import hashlib as _h
        digest = _h.sha256(stand_in.read_bytes()).hexdigest()
        for mat in doc["source_materials"]:
            if mat.get("material_id") == spec.get("material_id"):
                mat.update({"status": source_manifest.REVIEWED,
                            "path_or_link": f"{rel}/prog_spec/fixture_spec.txt",
                            "revision": "v1", "sha256": digest,
                            "approval_date": "2026-07-01", "approved_by": "A Person",
                            "data_refresh": "2026m06", "rwb_qc_reference": "QC-1"})
        refs.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
        assert source_manifest.source_status(str(pack)) == "approved"
        assert state(1) == "done", \
            "Gate 1 cannot report done even with the specification approved — the positive path"

        # GATE 2 AND GATE 4 MUST NOT GO DONE ON THE WORD ALONE. This is where the first version of
        # this test was wrong, and it locked in a real fail-open: it wrote the two maturity lines and
        # asserted `done`, which is exactly what the tool then did — on a pack carrying NEITHER
        # approval form. `releasable()` reports `maturity_errors` under an `evidence:` prefix that
        # carries no gate number, so writing `approved` deletes the two "not approved" lines and
        # leaves ten evidence blockers standing invisibly.
        (pack / "handoff" / "MATURITY.yaml").write_text(
            "contract: approved\nconfiguration: approved\n", encoding="utf-8")
        _ok, why_now = source_manifest.releasable(str(root), rel)
        assert any(w.startswith("evidence:") for w in why_now), \
            "fixture has no evidence blockers — the false-positive case is not being exercised"
        assert state(2) != "done", \
            "Gate 2 reports done with unmet approval evidence — the word without the record"
        assert state(4) != "done", \
            "Gate 4 reports done with unmet approval evidence — the word without the record"

        # THE DRIFT GUARD, exercised rather than assumed. `maturity_errors` carries checks inline
        # that no per-gate function returns — the axis-ordering rules, MATURITY_REQUIRES, the Gate 3
        # vendor-evidence sweep. Those are UNATTRIBUTED, and the guard reports them against every
        # approval gate instead of dropping them, so a seventh check added to the aggregate tomorrow
        # cannot be invisible here. Without this assertion the guard was dead code: the per-gate
        # calls alone already blocked the fixture, so deleting it changed no result.
        import product_gates as _pg
        _m = _pg.maturity(str(pack))
        _ev = set(_pg.contract_approval_errors(str(pack), rel, _m)
                  + _pg.configuration_approval_errors(str(pack), rel, _m)
                  + _pg.output_decision_errors(str(pack), rel, _m))
        unattr = [e for e in _pg.maturity_errors(str(root), rel) if e not in _ev]
        assert unattr, "fixture has no unattributed evidence blocker — the guard is untested here"
        for n in (2, 4):
            blockers = next(b for g, _t, _s, b in status.gates(str(root), str(pack)) if g == n)
            assert any("no per-gate check accounted for" in b for b in blockers), \
                f"Gate {n} silently drops {len(unattr)} evidence blocker(s) no per-gate check claimed"

        # ...and they DO go done once the evidence actually holds. Without this half the tool could
        # satisfy the assertions above by never reporting done at all.
        assert _pg.maturity_errors(str(root), rel), "fixture should still be blocked here"
        (pack / "handoff" / "MATURITY.yaml").write_text(
            "contract: coverage_complete\nconfiguration: draft\n", encoding="utf-8")
        assert not _pg.maturity_errors(str(root), rel), \
            "the fixture cannot reach an evidence-clean state, so `done` is untestable"
        assert state(2) != "done"          # still blocked, but now by the CLAIM, not the evidence
        assert "Gate 2" in " ".join(
            w for w in source_manifest.releasable(str(root), rel)[1])

        # GATE 3 must have a done branch. It is reached when no vendor-sourced record is left
        # without evidence — asserted here on the SHAPE of the state machine, since manufacturing
        # real Gate 3 evidence for 166 records is not what this test is about.
        assert state(3) in {"done", "in progress", "not started"}, state(3)
        # NON-COMMENT lines throughout. Both blocks EXPLAIN what they must do, so a plain substring
        # search over the region is answered by the explanation: the first version of this assertion
        # passed against a Gate 5 gutted to a constant, because the comment above it still said
        # `VALIDATION_RANK`. That is the same prose-defeats-check shape as the Gate 6 and
        # RELEASE-READY checks, found here by mutating the tool and watching the test stay green.
        src = (REPO / "platform" / "tools" / "status.py").read_text(encoding="utf-8")

        def code_between(start, end):
            return [l.split("#")[0] for l in src[src.index(start):src.index(end)].splitlines()
                    if not l.strip().startswith("#")]

        g3 = code_between("# GATE 3 —", "# GATE 4 —")
        assert any('"done" if not g3' in l for l in g3), \
            "Gate 3 has no done branch — next_action would park on it forever once 1 and 2 close"

        # GATE 5 must derive from the per-record axis, not from a file's existence.
        g5 = code_between("# GATE 5 —", "out.append((6,")
        assert any("VALIDATION_RANK" in l for l in g5), \
            "Gate 5 does not read the validation axis it claims to"
        assert any("passed_live" in l for l in g5)

        # ...and the sweep line must not call Gates 1-4 a release. NON-COMMENT lines only: the code
        # EXPLAINS why that label is wrong, so a whole-file search matches the explanation and the
        # check passes on a file that still prints it. Fifth time this shape has come up here.
        code = [l.split("#")[0] for l in src.splitlines() if not l.strip().startswith("#")]
        assert not any("RELEASE-READY" in l for l in code), \
            "the one-line sweep calls a Gates 1-4 pass RELEASE-READY, over-stating what " \
            "releasable() means"
        assert any("GATES 1-4 READY" in l for l in code)
    finally:
        _sh.rmtree(tmp, ignore_errors=True)


def test_the_dry_run_sandbox_cannot_be_aimed_at_the_real_pack():
    """THE ONE TOOL HERE THAT WRITES `approved` MUST NOT BE STEERABLE OUT OF ITS TEMP COPY.

    `dry_run` simulates an approval by copying a pack to a temp directory and writing
    `contract: approved` into the copy — deliberately, so the claim is never made in the real tree.
    The destination was `os.path.join(tmp, pack)`, and `os.path.join` DISCARDS everything before an
    absolute component: pass an absolute pack path and the destination is the real pack. Both the
    copytree and the `approved` write then aimed at the governed directory.

    It was found by a caller passing the absolute path every other tool here accepts. Nothing was
    damaged, and only because `shutil.copytree` raises on an existing destination — the sandbox was
    defeated by an argument and saved by an unrelated implementation detail. The error named
    `products/oncology/oc/202606` rather than the caller, so it read as a corrupt pack.

    A refusal, not a silent normalisation to a relative path: a caller passing an absolute path has a
    different model of the API than the function does, and quietly repairing it hides that.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import dry_run
    import product_gates

    packs = product_gates.products(str(REPO))
    assert packs, "no packs discovered — nothing to attempt the escape with"
    pack = packs[0]

    for bad in (str(REPO / pack), "../" + pack):
        try:
            dry_run._stage(bad, str(REPO))
            raise AssertionError(f"dry_run staged onto {bad!r} instead of refusing it")
        except ValueError as e:
            assert "ROOT-RELATIVE" in str(e) or "outside the temp copy" in str(e), e

    # ...and the legitimate call still stages INSIDE a temp directory, or the guard has simply
    # broken the tool.
    import shutil as _sh
    tmp, dst = dry_run._stage(pack, str(REPO))
    try:
        assert os.path.abspath(dst).startswith(os.path.abspath(tmp) + os.sep), (tmp, dst)
        assert not os.path.abspath(dst).startswith(str(REPO.resolve()) + os.sep), \
            f"staged inside the real checkout: {dst}"
        assert os.path.isdir(dst), dst
    finally:
        _sh.rmtree(tmp, ignore_errors=True)


def test_a_date_validates_the_same_whether_or_not_it_is_quoted():
    """The schema and the gate disagreed about what a date looks like.

    Every date field in the schema is `type: string` with an ISO pattern, but PyYAML resolves an
    UNQUOTED `2026-07-27` to a `datetime.date` — so a date written the way a person naturally writes
    one failed schema validation as "not a string" while the same value in quotes passed.
    `product_gates.bad_date` compares on `str(v)` and accepted both, so the tool side never noticed.
    It stayed hidden because `approval_date` and `attestation_date` are required only of a
    `reviewed` material and no pack has one; `classified_date` is the first date a live pack carries,
    and it broke CI the moment it held a real value.

    Normalising, not demanding quotes — a convention every author must remember in every pack forever
    is not a fix. What must NOT change is the pattern's bite: a malformed date is still refused.
    """
    try:
        import jsonschema
    except ImportError:
        import pytest
        pytest.skip("jsonschema not installed (CI installs it via platform/requirements.txt)")
    import copy
    import datetime
    schema = json.loads((GOV / "schemas" / "source_refs.schema.json").read_text(encoding="utf-8"))
    packs = sorted(PRODUCTS.rglob("source_refs.yaml"))
    assert packs, "no pack to exercise the schema against"
    base = load_yaml(packs[0])
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest

    def validates(field, value):
        doc = copy.deepcopy(base)
        doc["source_materials"][0][field] = value
        try:
            jsonschema.validate(as_json(doc), schema)
            return True
        except jsonschema.ValidationError:
            return False

    for field in source_manifest.CLASSIFICATION_FIELDS[1:] + ["approval_date"]:
        assert validates(field, datetime.date(2026, 7, 27)), \
            f"{field}: an unquoted ISO date — what a person writes — must validate"
        assert validates(field, "2026-07-27"), f"{field}: a quoted ISO date must validate"
        for bad in ("27/07/2026", "July 2026", "2026-7-7"):
            assert not validates(field, bad), f"{field}: {bad!r} was accepted as a date"


def test_every_tool_reads_governed_yaml_through_the_one_reader():
    """`read_yaml` is only "the ONE reader" if every tool actually uses it.

    It was written to fix gates crashing on malformed-but-parseable YAML, then three tools kept their
    own `yaml.safe_load` and each hit the bug it exists to prevent: contract_binding died with
    TypeError on a list-rooted variables file, source_check's allowlist read AttributeError'd, and
    union_members caught `(yaml.YAMLError, OSError)` — the precise narrowing read_yaml's docstring
    warns about — so an impossible ISO date crashed it with a plain ValueError from inside PyYAML.

    This is not a generic duplicate-scanner: it is one named invariant over one call shape in one
    directory, of the same kind as the lint-ownership test. What it CANNOT see is a tool that reads
    YAML some other way, so it is a floor, not a proof.
    """
    tools = FRAMEWORK / "tools"
    offenders = []
    for f in sorted(tools.glob("*.py")):
        for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
            if re.search(r"yaml\.safe_load\(\s*(fh|open\()", line) and f.name != "product_gates.py":
                offenders.append(f"{f.name}:{i}")
    assert not offenders, (
        f"these read a governed YAML FILE directly instead of product_gates.read_yaml, so a "
        f"parse failure or a non-mapping root becomes a traceback out of a gate: {offenders}")

    # product_gates itself may only do it inside read_yaml.
    src = (tools / "product_gates.py").read_text(encoding="utf-8").splitlines()
    inside = [i for i, l in enumerate(src) if l.startswith("def read_yaml(")]
    assert inside, "read_yaml is gone"
    start = inside[0]
    end = next((i for i in range(start + 1, len(src)) if src[i].startswith("def ")), len(src))
    stray = [f"product_gates.py:{i+1}" for i, l in enumerate(src)
             if re.search(r"yaml\.safe_load\(\s*(fh|open\()", l) and not (start <= i < end)]
    assert not stray, f"product_gates reads YAML outside its own read_yaml: {stray}"


def test_no_suite_defines_a_test_below_its_runner_block():
    """A test defined after `if __name__ == "__main__":` never runs under CI.

    Every suite here is executed as a SCRIPT (`python3 tests/test_x.py`), and each runner reads
    `globals()` at that point — so a `def test_` below the block is simply not there yet. It exits 0
    having asserted nothing. test_contract_lint.py had two, including the only test of I15, the
    invariant binding a record to the text it was written from; under pytest they ran and passed,
    which is exactly what hid it.

    One shape check over every suite, rather than a counter inside one file: the file that grows the
    bug next is by definition the one without the guard, and the pack tests a new tumour copies are
    run the same way.
    """
    suites = sorted((FRAMEWORK / "tests").glob("test_*.py")) \
        + sorted(PRODUCTS.rglob("handoff/tests/test_*.py")) \
        + sorted((FRAMEWORK / "TUMOR_TEMPLATE").rglob("tests/test_*.py"))
    assert len(suites) > 5, f"only {len(suites)} suites discovered — this sweep is vacuous"
    for suite in suites:
        lines = suite.read_text(encoding="utf-8").splitlines()
        main = next((i for i, l in enumerate(lines) if l.startswith("if __name__")), None)
        if main is None:
            continue                       # pytest-only suite; nothing to order
        stranded = [l.split("(")[0][4:] for l in lines[main + 1:] if re.match(r"^def test_", l)]
        assert not stranded, (f"{suite.relative_to(REPO)} defines {stranded} BELOW its "
                              f"`if __name__` block, so running it as a script never registers them")


def test_an_active_registry_entry_must_name_a_buildable_pack():
    """The registry's `current_spec_version` is what every DEFAULT product lookup resolves through, so
    an `active` entry naming a pack without a config does not fail once — it fails in every suite that
    loads the default product, and each failure names the missing config file rather than the registry
    line that caused it. Ten of twenty platform suites went red that way and read as ten defects.

    Reported against the registry's own claim, so the message names the cause.
    """
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import product_gates

    assert product_gates.registry_errors() == [], product_gates.registry_errors()

    import pathlib
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        root = pathlib.Path(tmp)
        (root / "products").mkdir()
        reg = root / "products" / "registry.yaml"

        def write(status, version, make_pack):
            reg.write_text(f"tumors:\n  - {{ code: x, slug: x, status: {status}, "
                           f"current_spec_version: \"{version}\" }}\n", encoding="utf-8")
            pack = root / "products" / "oncology" / "x" / version
            if make_pack:
                (pack / "config").mkdir(parents=True, exist_ok=True)
                (pack / "handoff").mkdir(parents=True, exist_ok=True)
                (pack / "config" / "data_product.yaml").write_text("a: 1\n")
                (pack / "source_refs.yaml").write_text("a: 1\n")
                (pack / "handoff" / "MATURITY.yaml").write_text("contract: not_started\n")
            return pack

        write("active", "209901", make_pack=False)
        errs = product_gates.registry_errors(str(root))
        assert errs and "does not exist" in errs[0], errs

        # `scaffold` is the honest state while a pack is being built — it must NOT be refused.
        write("scaffold", "209901", make_pack=False)
        assert product_gates.registry_errors(str(root)) == [], "a scaffold entry was refused"

        pack = write("active", "209902", make_pack=True)
        assert product_gates.registry_errors(str(root)) == [], product_gates.registry_errors(str(root))

        # the exact failure that happened: the pack exists but its config was removed
        (pack / "config" / "data_product.yaml").unlink()
        errs = product_gates.registry_errors(str(root))
        assert any("data_product.yaml" in e for e in errs), errs


def test_the_template_cold_starts_to_gate_1_and_extracts():
    """Copy the template, drop a spec in, make the edits NEW_TUMOUR.md names — and it must work.

    Nothing held the template to that. It shipped a `path_or_link` placeholder pointing at
    `prog_spec/reference/<workbook>.xlsx`, a layout NO pack in the repo uses, so the one instruction a
    new tumour follows first sent them somewhere that does not exist. The template is the only file a
    new product inherits wholesale; a defect here is a defect in every future tumour at once, and it
    cannot be caught by reading a pack that was set up before the defect landed.

    So this walks it: bare spec folder -> not a pack at all -> template -> Gate 1 refuses the
    placeholders -> documented substitutions -> Gate 1 passes -> the extractor reads the spec.
    """
    import pathlib
    import shutil
    import subprocess
    import tempfile
    sys.path.insert(0, str(FRAMEWORK / "tools"))
    import product_gates
    import source_manifest

    template = FRAMEWORK / "TUMOR_TEMPLATE"
    # A spec layout that PACKS ACTUALLY USE. The previous fixture pointed at
    # `prostate/202607/Program Specification`, which does not exist — so this returned at the first
    # line and passed without asserting anything, for as long as it has existed. The test written to
    # catch "a layout no pack in the repo uses" was itself written against one.
    spec_src = REPO / "products" / "oncology" / "prostate" / "202606" / "prog_spec"
    assert spec_src.is_dir(), (
        f"{spec_src} is missing — the cold-start fixture must exist or this test proves nothing. "
        f"Do not restore the silent return.")

    with tempfile.TemporaryDirectory() as tmp:
        pack = pathlib.Path(tmp, "products", "oncology", "nsclc", "202608")
        spec_dir = pack / "prog_spec"           # where the template's path_or_link points
        spec_dir.parent.mkdir(parents=True)
        shutil.copytree(spec_src, spec_dir)

        # 1. the spec alone is NOT a pack — the gates must not see it
        assert product_gates.products(tmp) == [], product_gates.products(tmp)

        shutil.copytree(template, pack, dirs_exist_ok=True)
        rel = "products/oncology/nsclc/202608"
        assert product_gates.products(tmp) == [rel], product_gates.products(tmp)

        # 2. straight from the template, Gate 1 REFUSES — placeholders are not answers
        assert source_manifest.check(tmp, rel), "the unfilled template passed Gate 1"

        # 3. the substitutions NEW_TUMOUR.md names, and nothing else
        refs = pack / "source_refs.yaml"
        text = refs.read_text(encoding="utf-8")
        for old, new in (("<registry code>", "nsclc"), ("<YYYYMM>", "202608"),
                         ("<family>", "oncology"), ("<slug>", "nsclc"),
                         ("<workbook>.xlsx", ""), ("<TUMOUR>-<PROGRAM>", "NSCLC-PANO"),
                         ("<sponsor_ai_eligible | vendor_restricted | restricted_derived>",
                          "sponsor_ai_eligible"),
                         ("classified_by: REPLACE_ME", "classified_by: A. Person"),
                         ("classified_date: REPLACE_ME", "classified_date: 2026-07-28")):
            text = text.replace(old, new)
        refs.write_text(text.replace("Program Specification/\"", "Program Specification\""),
                        encoding="utf-8")
        conf = pack / "spec_pipeline" / "pipeline.conf"
        conf.write_text('TUMOR="nsclc"\nSPEC_SOURCE_ID=program_spec\n', encoding="utf-8")

        errs = source_manifest.check(tmp, rel)
        assert errs == [], f"the template does not cold-start to Gate 1: {errs}"

        # 4. and the registered path is one the extractor can actually read
        out = subprocess.run([sys.executable, str(FRAMEWORK / "tools" / "spec_extract.py"),
                              str(spec_dir), "--out", str(pathlib.Path(tmp, "e.json"))],
                             capture_output=True, text=True)
        assert out.returncode == 0, out.stderr
        # Read the artifact, not the log line: "20 rows" contains "0 rows", so a substring check on
        # stdout passed on a healthy run and would have passed on an empty one too.
        got = json.loads(pathlib.Path(tmp, "e.json").read_text(encoding="utf-8"))
        assert got["extraction"]["row_count"] > 0, got["extraction"]


def test_the_template_defaults_no_tumours_answers():
    """A default that is legal but wrong is worse than none — nothing notices.

    TUMOR_TEMPLATE shipped `vendor: flatiron` and `tumor_class: solid`: the Flatiron solid-tumour case
    wearing the clothes of a neutral template. Every other field is REPLACE_ME, so these two were the
    only ones a new product could inherit silently — and they are not cosmetic. `vendor` selects the
    physical table layout, so the first COTA/heme pack would have resolved the WRONG tables; and
    `tumor_class` drives the staging system, the outcomes framework and which sources exist.

    engine.validate holds both to a known set, so a placeholder fails loudly and names the options.
    That is what makes leaving them unanswered safe, and this asserts the pair together — the check
    and the blank — because either alone is useless.
    """
    sys.path.insert(0, str(FRAMEWORK))
    from engine.config import load_config
    from engine.validate import problems
    cfg = load_config(str(FRAMEWORK / "TUMOR_TEMPLATE" / "config" / "data_product.yaml"))
    for field in ("vendor", "tumor_class"):
        assert "REPLACE_ME" in str(getattr(cfg, field)), \
            f"TUMOR_TEMPLATE answers `{field}` for the next tumour instead of asking"
    said = problems(cfg)
    for field in ("vendor", "tumor_class"):
        assert any(field in e for e in said), \
            f"nothing refuses an unfilled `{field}` — the blank template would build the wrong tables"

    # The study WINDOW is the same class and shipped as real dates with no placeholder: valid,
    # plausible, and silently wrong for any product whose spec says otherwise.
    raw = (FRAMEWORK / "TUMOR_TEMPLATE" / "config" / "data_product.yaml").read_text(encoding="utf-8")
    for key in ("index_start", "index_end"):
        line = next(l for l in raw.splitlines() if l.strip().startswith(key + ":"))
        assert "REPLACE_ME" in line, f"TUMOR_TEMPLATE answers `{key}` for the next product: {line!r}"

    # ...and so are the tumour-SPECIFIC structures: three line-of-therapy cohorts (a solid-tumour
    # model a heme product would inherit whole) and two prostate therapy tables. Present as comments
    # is right — they are worked examples; ACTIVE is what makes them silent defaults.
    active = [l for l in raw.splitlines() if l.strip() and not l.strip().startswith("#")]
    for token in ("lot1", "lot2", "lot3", "alphabet:", "provenge:"):
        offenders = [l for l in active if token in l]
        assert not offenders, (f"TUMOR_TEMPLATE ships `{token}` ACTIVE, so every copied pack inherits "
                               f"it: {offenders}")


def test_the_gate_2_rule_i_removed_still_has_an_owner_that_ci_runs():
    """Removing a duplicated control is only safe if the remaining one actually runs.

    product_gates no longer blocks `contract: approved` over open requirement decisions, on the
    grounds that contract_lint's I11/I14 own that rule. This asserts the grounds: I14 keys off
    MATURITY.yaml, every pack's own handoff test invokes contract_lint.run(), TUMOR_TEMPLATE ships
    that test so a new tumour inherits it, and CI discovers those tests. Break any link and a control
    was deleted with nothing behind it.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint
    import product_gates

    src = (REPO / "platform" / "tools" / "contract_lint.py").read_text(encoding="utf-8")
    assert 'maturity(product_dir)["contract"]' in src and 'contract_level == "approved"' in src, \
        "I14 no longer keys off MATURITY.yaml — nothing enforces the Gate 2 exit"
    assert not any(getattr(product_gates, n, None) for n in ("_open_decision_block",)), \
        "the removed duplicate must not come back"

    tmpl = REPO / "platform" / "TUMOR_TEMPLATE" / "handoff" / "tests" / "test_functional_contract.py"
    assert tmpl.exists(), "a new tumour would inherit no contract lint at all"
    assert "contract_lint" in tmpl.read_text(encoding="utf-8")

    # Every REAL pack with a contract carries a test that INVOKES the lint, and CI discovers it.
    # Asserting only that some test_*.py exists proved the weaker thing: a pack could carry
    # test_product_codes.py alone and satisfy it while contract_lint never ran there at all. Three
    # links, each checked: the file exists, it calls contract_lint...run(), and --list-tests emits it.
    listed = {l.strip() for l in subprocess.run(
        [sys.executable, "platform/tools/product_gates.py", "--list-tests"],
        cwd=str(REPO), capture_output=True, text=True, check=True).stdout.splitlines() if l.strip()}
    assert listed, "--list-tests found nothing — CI would run no pack test at all"
    packs = [p for p in product_gates.products(str(REPO))
             if (REPO / p / "handoff" / "FUNCTIONAL_CONTRACT.md").exists()]
    assert packs, "no pack with a contract was discovered — this sweep is vacuous"
    import importlib.util
    for pack in packs:
        tdir = REPO / pack / "handoff" / "tests"
        runners = []
        for t in sorted(tdir.glob("test_*.py")) if tdir.is_dir() else []:
            # Function IDENTITY, not a text match. Grepping for `contract_lint.run(` said this pack
            # had no lint at all, when it imports `from contract_lint import run` — a false alarm on
            # the guard meant to catch a real one. Importing the module and asking whether the `run`
            # it holds IS contract_lint.run cannot be fooled by either spelling, and would catch a
            # pack that shadowed the shared lint with a local copy, which is the failure that
            # actually matters here.
            spec = importlib.util.spec_from_file_location(f"packtest_{pack}_{t.stem}", t)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if any(getattr(mod, n, None) is contract_lint.run for n in dir(mod)) or \
                    getattr(mod, "contract_lint", None) is contract_lint:
                runners.append(t)
        assert runners, (f"{pack} has a contract but no handoff test that calls the SHARED "
                         f"contract_lint.run — I11/I14 never run for it")
        for t in runners:
            rel = t.relative_to(REPO).as_posix()
            assert rel in listed, f"{rel} invokes the lint but --list-tests does not emit it, so CI " \
                                  f"never runs it"


def test_claude_md_names_symbols_that_actually_exist():
    """docs/ENGINEERING.md's shared-definition registry must not go stale.

    The file exists so a contributor can see what `contract_lint` / `product_gates` / `profile_io` /
    `pack_run` already own WITHOUT searching — three separate duplications got merged because nobody
    searched. That only works while the list is true. It is read at the start of every session, so a
    drifted entry does not merely fail to help: it sends someone to write a second `sha256` because
    the file no longer mentions the first. Rename or move a shared definition and this fails in the
    same commit.
    """
    import importlib
    claude = REPO / "docs/ENGINEERING.md"
    assert claude.exists(), "docs/ENGINEERING.md is gone — the shared-definition rule lost its home"
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    sys.path.insert(0, str(REPO / "platform"))

    ident = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
    header = re.compile(r"^\*\*`platform/(?:tools|engine)/(\w+)\.py`\*\*")
    checked, module = 0, None
    for line in claude.read_text(encoding="utf-8").splitlines():
        m = header.match(line)
        if m:
            module, = m.groups()
            continue
        if module is None:
            continue
        if not line.strip():                      # the symbol list ends at the blank line
            module = None
            continue
        names = [t for t in re.findall(r"`([^`]+)`", line) if ident.match(t)]
        if not names:
            continue
        mod = importlib.import_module(module)
        for n in names:
            assert hasattr(mod, n), (
                f"docs/ENGINEERING.md says {module} owns `{n}`, but it does not. Either the definition moved "
                f"(update docs/ENGINEERING.md in the same commit) or the entry was always wrong.")
            checked += 1
    assert checked >= 30, f"only {checked} symbols checked — has the registry section been gutted?"


def test_governance_docs_fences_balanced():
    # Cheap doc-integrity gate (replaces a heavyweight markdown-lint action): code fences are balanced
    # and every ```mermaid block is closed, across the governed docs — so a bad edit can't corrupt them.
    docs = [REPO / "docs" / "REPO_STRUCTURE_AND_PROD_MIGRATION.md"]
    docs += sorted((REPO / "governance").rglob("*.md"))
    for d in docs:
        text = d.read_text(encoding="utf-8")
        fences = text.count("```")
        assert fences % 2 == 0, f"{d.name}: unbalanced ``` fences ({fences})"
        assert text.count("```mermaid") <= fences // 2, f"{d.name}: a ```mermaid block is unclosed"


def test_release_schema_signoff_matches_manifest():
    # release.schema.json sign_off properties must mirror engine.refresh.build_manifest's sign_off keys
    # exactly (catches the qc_reviewed_by/released_at drift) — manifest is the source of truth.
    from engine.refresh import build_manifest
    from engine.config import load_config
    schema = json.loads((GOV / "schemas" / "release.schema.json").read_text(encoding="utf-8"))
    schema_keys = set(schema["properties"]["sign_off"]["properties"])
    cfg = load_config(product_config(PRODUCTS, "prostate"),
                      overrides={"run.refresh": "2026q1", "run.source_schema": "s", "run.output_schema": "o"})
    m = build_manifest(cfg, tumor="mcrpc")
    assert set(m["sign_off"]) == schema_keys, f"sign_off drift: manifest {set(m['sign_off'])} vs schema {schema_keys}"


def test_release_schema_block_matches_validator():
    # the schema's release-block required fields must match what engine.refresh.validate_manifest enforces
    # at runtime (public/version/build_id/ads/views) — else a record can pass schema review but fail the
    # runtime validator. (The views[public] == ads condition stays a runtime check.)
    schema = json.loads((GOV / "schemas" / "release.schema.json").read_text(encoding="utf-8"))
    assert set(schema["properties"]["release"]["required"]) == {"public", "version", "build_id", "ads", "views"}


def test_release_readiness_is_derived_not_read_from_a_status_flag():
    """`run_rwdp.py` gated production on `status == "active"`, and the registry says in as many words
    that `active` means "current, supported pack" and "does NOT assert live validation". A
    pack-currency flag was deciding what may reach the public views."""
    import source_manifest
    runner = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    # The CODE, not the prose: the comment above the fix quotes the old line on purpose.
    gate = [ln for ln in runner.splitlines() if ln.startswith("governed = ")]
    assert len(gate) == 1, gate
    assert "status" not in gate[0], f"the registry status is a release gate again: {gate[0]}"
    assert "release_ready" in gate[0], gate[0]
    assert "releasable(" in runner, "the runner no longer derives releasability from evidence"
    # ...and no pack claims releasability today, which is the correct answer for all seven
    root = str(REPO)
    for rel in source_manifest.products(root):
        ok, why = source_manifest.releasable(root, rel)
        assert not ok or why == [], (rel, why)


def test_releasable_says_YES_for_a_fully_evidenced_pack_via_the_runner_s_own_path_math():
    """A gate only ever shown to REFUSE has not been shown to work.

    Every pack is legitimately blocked at Gate 1 today, so the existing test could assert nothing
    about the positive path — and that hid a real bug: the runner derived its repo root as
    `config_path.parents[4]`, which is <repo>/products, one level short. `releasable` passes that root
    to Gate 1, which resolves each material's REPO-ROOT-RELATIVE `path_or_link`, so a registered
    `products/oncology/…` became `<repo>/products/products/oncology/…` and the pack would have stayed
    permanently not-release-ready however many approvals landed.

    This builds a pack that genuinely passes Gates 1-4 and drives it through the runner's OWN path
    calculation, so the arithmetic is under test rather than assumed.
    """
    import shutil
    import tempfile as _tf
    import source_manifest
    repo = Path(_tf.mkdtemp())
    try:
        pack = repo / "products" / "oncology" / "demo" / "202601"
        (pack / "handoff").mkdir(parents=True)
        (repo / "platform").mkdir()
        spec = pack / "reference" / "spec.xlsx"
        spec.parent.mkdir(parents=True)
        spec.write_text("fixture", encoding="utf-8")
        sha = source_manifest.sha256(str(spec))
        # REPO-ROOT-RELATIVE, exactly as a real pack registers it — the shape the bug tripped on.
        (pack / "source_refs.yaml").write_text(
            "source_materials:\n"
            "  - material_id: program_spec\n    material_type: program_spec\n"
            "    status: reviewed\n    path_or_link: products/oncology/demo/202601/reference/spec.xlsx\n"
            f"    document_id: DEMO-1\n    revision: '1'\n    sha256: {sha}\n"
            "    approval_date: 2026-01-05\n    approved_by: A. Approver\n"
            "    data_refresh: 2026q1\n    rwb_qc_reference: QC-1\n"
            "    ai_classification: sponsor_ai_eligible\n"
            "    classified_by: R. Classifier\n    classified_date: 2026-01-05\n", encoding="utf-8")
        (pack / "handoff" / "MATURITY.yaml").write_text(
            "contract: approved\nconfiguration: approved\n", encoding="utf-8")

        ok, why = source_manifest.releasable(str(repo), "products/oncology/demo/202601")
        # Not asserting ok=True outright: this fixture deliberately carries no contract, so Gate 2's
        # evidence requirements still fire. What it MUST show is that Gate 1 is satisfied — which is
        # the half the root bug broke, and which no other test reaches.
        assert not any("Gate 1" in w for w in why), (
            f"Gate 1 rejected a correctly registered, reviewed material — the repo root passed to "
            f"releasable() is wrong: {[w for w in why if 'Gate 1' in w]}")

        # ...and the RUNNER's own arithmetic produces that same root, which is where the bug lived.
        framework_root = repo / "platform"
        config_path = pack / "config" / "data_product.yaml"
        derived_repo = Path(framework_root).resolve().parent
        derived_rel = str(Path(config_path).resolve().parents[1].relative_to(derived_repo))
        assert derived_repo == repo.resolve(), derived_repo
        assert derived_rel.replace("\\", "/") == "products/oncology/demo/202601", derived_rel
        runner = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
        assert "_repo = Path(framework_root).resolve().parent" in runner, \
            "the runner computes its repo root some other way again"
        # CODE, not prose — the comment above the fix quotes the old expression on purpose.
        code = [ln for ln in runner.splitlines() if not ln.lstrip().startswith("#")]
        assert not any("parents[4]" in ln for ln in code), "the parents[] count is back"
    finally:
        shutil.rmtree(repo, ignore_errors=True)


def test_validate_only_stops_BEFORE_the_release_phase_by_reading_the_actual_order():
    """Source-text assertions kept passing while the behaviour was wrong. This reads the ORDER.

    Twice now a guard was present and the thing it was meant to guard still happened: the swap was
    conditional while the line below it read the public table, and then the swap was conditional while
    the run still created immutable versioned release tables and a release pointer. Both times my test
    asserted that a predicate and a guard EXISTED, which was true, and told me nothing.

    So this walks the runner's statements in file order and checks where the validate-only exit sits
    relative to the operations that make a release a release. No Spark, no dbutils — just the sequence,
    which is exactly the property that broke.
    """
    src = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    def at(needle):
        assert needle in src, f"missing from the runner: {needle}"
        return src.index(needle)

    exit_point = at('dbutils.notebook.exit("validate_only")')
    guard = at("if not may_publish:")
    assert guard < exit_point, "the validate-only exit is not inside its guard"

    # Everything that CREATES a release must come after the exit.
    for after in ("v_ads = rel.versioned_ads(",          # immutable versioned table name
                  "rel.release_pointer(",                 # the release pointer in the manifest
                  "rel.swap_plan(final, cfg.refresh, build_id, list(tfl_staged))",   # public swap
                  'manifest["published_at"]',             # the published claim
                  "DROP TABLE IF EXISTS"):                # staging cleanup
        assert at(after) > exit_point, \
            f"a validate-only run still reaches `{after}` — it would create release objects"

    # ...and everything a smoke test EXISTS for must come before it.
    for before in ("build(", "run_qc(", "preflight(", "_policy(\"dictionary\")"):
        assert at(before) < exit_point, f"validate-only skips `{before}`, which it should exercise"

    # the exit records why, so the manifest is not silently a non-release
    assert at('"stopped_before": "versioned_release_tables"') < exit_point


def test_a_waiver_or_an_unready_pack_can_never_reach_the_swap():
    """`allow_governed_waiver` is a smoke-test bypass — it drops the git_commit and reference_table
    requirements and turns REQUIRED deliverables optional. It must not also be able to publish, and
    neither must a prod run whose pack has not passed its gates.

    Asserted on the PREDICATE plus the exit, not on an inline guard around the swap: the swap is no
    longer conditional at all, because the run stops before the release phase. The order test above
    proves the stop is in the right place; this proves what decides it.
    """
    src = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    pred = [ln for ln in src.splitlines() if ln.startswith("may_publish = ")]
    assert len(pred) == 1, pred
    assert pred[0] == 'may_publish = not waiver and (env != "prod" or release_ready)', pred[0]
    # a waiver alone is enough to stop it, whatever the environment
    assert "not waiver and" in pred[0]
    # ...and the guard's OWN BODY only announces the decision — it must not reach the release module.
    #
    # Sliced as the indented block, not as "everything between the guard and the exit". The looser
    # form passed only while nothing in the middle of the notebook happened to say `rel.`, so naming
    # the staging tables through `engine.release` — which is where table names belong — broke a test
    # about the validate-only guard. It was asserting the absence of a substring over 250 lines it
    # was not about.
    lines = src.splitlines()
    start = next(i for i, ln in enumerate(lines) if ln.startswith("if not may_publish:"))
    body = []
    for ln in lines[start + 1:]:
        if ln.strip() and not ln.startswith((" ", "\t")):
            break
        body.append(ln)
    assert body, "the validate-only guard has an empty body"
    assert not any("rel." in ln for ln in body), \
        f"the validate-only guard touches the release module: {body}"
    # the ORDER test above owns the stronger claim: everything that CREATES a release sits after the
    # notebook exit. Restated here as the one line that would silently undo it.
    assert src.index('dbutils.notebook.exit("validate_only")') < src.index("rel.swap_plan(final")


def test_every_registered_product_has_its_own_paused_job():
    """A portfolio is products that do NOT share a schedule, a schema, or an activation state.

    The bundle was one job parameterised by `tumor_slug` defaulting to `prostate`. That deploys
    whichever product is selected; it does not deploy a portfolio, and the prod target flipped that
    single job to UNPAUSED — so deploying the platform scheduled whatever the default happened to be.
    """
    import yaml as _y
    import bundle_products
    gen = REPO / "resources" / "products.yml"
    assert gen.exists(), "resources/products.yml has not been generated"
    doc = _y.safe_load(gen.read_text(encoding="utf-8"))
    slugs = [s for s, _f, _v, _c in bundle_products.entries(str(REPO))]
    assert slugs, "the registry lists no MATERIALIZED products"
    # planned entries must NOT appear: a job pointing at a pack that does not exist is clutter, and it
    # makes "one job per product" untrue when some entries are ideas rather than products
    import yaml as _yy
    reg = _yy.safe_load((REPO / "products" / "registry.yaml").read_text(encoding="utf-8"))
    planned = [t["slug"] for t in reg["tumors"] if str(t.get("status", "")).lower() == "planned"]
    assert planned, "no planned entry left to prove the filter with"
    assert not (set(planned) & set(slugs)), f"planned tumours got deployable jobs: {sorted(set(planned) & set(slugs))}"
    for slug, family, version, _c in bundle_products.entries(str(REPO)):
        assert (REPO / "products" / family / slug / version).is_dir(), \
            f"{slug} has a job but no pack at products/{family}/{slug}/{version}"
    assert sorted(doc["resources"]["jobs"]) == sorted(f"rwdp_build_{s}" for s in slugs)

    for name, job in doc["resources"]["jobs"].items():
        assert job["schedule"]["pause_status"] == "PAUSED", \
            f"{name} ships unpaused — activation is per product and follows that product's gates"
    # ...and the per-product settings really are per product, not shared
    for slug in slugs:
        for knob in ("cron", "refresh", "source_schema", "output_schema", "reference_table",
                     "alert_email", "artifact_root"):
            assert f"{slug}_{knob}" in doc["variables"], f"{slug} shares {knob} with other products"


def test_the_bundle_names_no_product_and_hardcodes_no_family():
    """`products/oncology/${var.tumor_slug}/...` was the family hardcoded one level down. The registry
    supports `family`, and the notebook only recovered by constructing the wrong path first and
    failing over — which works until it silently does not."""
    import yaml as _y
    bundle = (REPO / "databricks.yml").read_text(encoding="utf-8")
    body = "\n".join(ln for ln in bundle.splitlines() if not ln.lstrip().startswith("#"))
    assert "tumor_slug" not in body, "the bundle still selects a single product by slug"
    assert "UNPAUSED" not in body, "a target unpauses on deploy again"
    assert _y.safe_load(bundle).get("resources") is None, \
        "jobs are defined in databricks.yml again instead of being generated"
    assert "resources/products.yml" in (_y.safe_load(bundle).get("include") or [])
    # the generated paths use each product's OWN registry family
    doc = _y.safe_load((REPO / "resources" / "products.yml").read_text(encoding="utf-8"))
    import bundle_products
    for slug, family, _v, _c in bundle_products.entries(str(REPO)):
        path = doc["resources"]["jobs"][f"rwdp_build_{slug}"]["tasks"][0] \
            ["notebook_task"]["base_parameters"]["config_path"]
        assert f"/products/{family}/{slug}/" in path, (slug, family, path)


def test_a_family_change_in_the_registry_moves_the_job_with_no_code_edit():
    """The acceptance criterion: a product declaring `family: heme` lands under products/heme/ with
    nothing edited under platform/ or databricks.yml.

    Built on a SYNTHETIC repo rather than by mutating the real registry. The earlier version used
    DLBCL, which stopped working the moment planned/unmaterialized entries were filtered out — and a
    test that depends on which real products happen to exist is a test that breaks for reasons that
    are not about the thing it checks.
    """
    import shutil
    import tempfile as _tf
    import bundle_products
    repo = Path(_tf.mkdtemp())
    try:
        for family in ("oncology", "heme"):
            (repo / "products" / family / "demo" / "202601").mkdir(parents=True)
        (repo / "products" / "registry.yaml").write_text(
            "tumors:\n"
            '  - { code: demo, name: "Demo", slug: demo, vendor: cota, tumor_class: heme,\n'
            '      status: scaffold, current_spec_version: "202601" }\n', encoding="utf-8")

        fams = {s: f for s, f, _v, _c in bundle_products.entries(str(repo))}
        assert fams == {"demo": "oncology"}, f"no `family` should default to oncology: {fams}"
        assert "/products/oncology/demo/" in bundle_products.render(str(repo))

        text = (repo / "products" / "registry.yaml").read_text(encoding="utf-8")
        (repo / "products" / "registry.yaml").write_text(
            text.replace("slug: demo,", "slug: demo, family: heme,"), encoding="utf-8")
        fams = {s: f for s, f, _v, _c in bundle_products.entries(str(repo))}
        assert fams == {"demo": "heme"}, fams
        assert "/products/heme/demo/" in bundle_products.render(str(repo))
    finally:
        shutil.rmtree(repo, ignore_errors=True)


def test_a_planned_or_unmaterialized_entry_generates_no_job():
    """A job whose config path points at a pack that does not exist is production clutter, and it
    makes "one job per product" untrue when some registry rows are ideas."""
    import shutil
    import tempfile as _tf
    import bundle_products
    repo = Path(_tf.mkdtemp())
    try:
        (repo / "products" / "oncology" / "real" / "202601").mkdir(parents=True)
        (repo / "products" / "registry.yaml").write_text(
            "tumors:\n"
            '  - { code: real, slug: real, status: scaffold, current_spec_version: "202601" }\n'
            '  - { code: plan, slug: plan, status: planned }\n'
            '  - { code: tbd,  slug: tbd,  status: scaffold, current_spec_version: "YYYYMM" }\n'
            '  - { code: gone, slug: gone, status: active, current_spec_version: "202601" }\n',
            encoding="utf-8")
        slugs = [s for s, _f, _v, _c in bundle_products.entries(str(repo))]
        assert slugs == ["real"], (
            f"expected only the materialized product; got {slugs} — `plan` is planned, `tbd` has a "
            f"placeholder version, and `gone` names a pack that does not exist on disk")
    finally:
        shutil.rmtree(repo, ignore_errors=True)


def test_the_generated_bundle_is_current_with_the_registry():
    """A product added to the registry with no job is a product that silently cannot be deployed."""
    import bundle_products
    gen = (REPO / "resources" / "products.yml").read_text(encoding="utf-8")
    assert gen == bundle_products.render(str(REPO)), \
        "resources/products.yml is stale — run python3 platform/tools/bundle_products.py"


def _tree(git_commit="deadbeefcafe"):
    """Build the deployment tree into a temp dir; (out, files, evidence-doc). Copies files. Runs
    nothing, contacts no workspace, deploys no bundle — see deploy_tree.py's docstring."""
    import shutil
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    import product_gates
    out = Path(_tf.mkdtemp()) / "deploy"
    files = deploy_tree.build(str(REPO), str(out), git_commit=git_commit)
    doc, err = product_gates.read_yaml(str(out / "RELEASE_EVIDENCE.yaml"))
    assert not err, err
    return out, files, doc, lambda: shutil.rmtree(out.parent, ignore_errors=True)


def test_the_deployment_tree_excludes_exactly_what_it_exists_to_exclude():
    """`databricks.yml` syncs the repo root minus three globs, so a production workspace received the
    spec stand-ins, reference material, pipeline outputs, sandbox work and every
    historical pack. None of it is read by the build.

    This asserts the RESULT, not the allowlist — an allowlist that grows one wildcard is how a
    stand-in creeps back in, and the wildcard looks harmless in the diff.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    import source_manifest
    out, files, _doc, cleanup = _tree()
    try:
        assert files, "the tree is empty"
        assert not deploy_tree.forbidden_in(files), deploy_tree.forbidden_in(files)

        # The specific documents. Named rather than left to the FORBIDDEN globs, because these are the
        # files the packaging exists for and a rename of a directory should not quietly re-admit them.
        on_disk = {p.name for p in out.rglob("*") if p.is_file()}
        for doc_name in ("clinvars.md", "prospanodatadict.md", "prospanohivemeta.md"):
            assert doc_name not in on_disk, f"{doc_name} reached the deployment tree"

        # ...and the CONTENT test, which is the one that generalises: no file in the tree may quote
        # vendor documentation, by the same markers `--ai-boundary` uses. `products/` in the checkout
        # trips this repeatedly; the tree must not trip it at all.
        hits = []
        for p in out.rglob("*"):
            if p.is_file() and p.suffix in (".md", ".yaml", ".yml", ".json", ".txt"):
                hits += [(str(p.relative_to(out)), h)
                         for h in source_manifest.vendor_prose(p.read_text(encoding="utf-8",
                                                                           errors="replace"))]
        assert not hits, f"the deployment tree quotes vendor documentation: {hits[:3]}"
    finally:
        cleanup()


def test_the_deployment_tree_still_contains_everything_the_build_reads():
    """The other half, and the one an allowlist gets wrong: excluding something the runtime needs.

    A tree that is missing a config file does not fail at build time — it fails in the workspace, at
    the point of running a pipeline, which is exactly where this repo cannot test. So the graph is
    resolved INSIDE the tree with the same resolver the binder and Gate 4 use, and compared to the
    checkout's. Same files or the deployment is short one.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates
    out, files, doc, cleanup = _tree()
    try:
        packs = list(doc["products"])
        assert packs, "the tree deploys no packs"
        for pack in packs:
            want = sorted(product_gates.pack_yaml(str(REPO / pack)))
            got = sorted(product_gates.pack_yaml(str(out / pack)))
            assert want == got, (f"{pack}: the active config graph does not resolve inside the tree — "
                                 f"missing {sorted(set(want) - set(got))}")
            # ...and every file it names is actually THERE. Comparing the two reference lists alone is
            # not enough and I proved it by mutation: `pack_yaml` reports what the config REFERENCES,
            # so dropping a codelist from the copy left both lists identical and the test green while
            # the tree was one file short of buildable.
            for rel_in_pack in want:
                assert (out / pack / rel_in_pack).exists(), \
                    f"{pack}/{rel_in_pack} is referenced by the config graph and absent from the tree"
        # The runtime the job's notebook_task points at, and the modules it imports at top level.
        for needed in ("platform/databricks/run_rwdp.py", "platform/tools/source_manifest.py",
                       "platform/tools/product_gates.py", "platform/engine/config.py",
                       "platform/VERSION", "databricks.yml", "resources/products.yml"):
            assert needed in files, f"the tree omits {needed}, which the run reads"
    finally:
        cleanup()


def test_the_shared_product_assets_actually_LOAD_out_of_the_deployment_tree():
    """The inventory test above missed `products/metadata/catalog.yaml` and stayed green.

    That file is read twice by the runner — dictionary generation and the dashboard manifest — and a
    governed run REQUIRES both deliverables, so a product could pass Gates 1-4, enter the tree as
    releasable, build its ADS, and then be unable to publish. Nothing was red, because the runner's
    five path literals, this builder's `_reporting` walk and this test's hand-written `needed` tuple
    were three separate descriptions of one set, each internally consistent.

    Adding the filename to the tuple would fix the instance and leave the shape. So: the set is owned
    once by `engine.config.SHARED_ASSETS`, and this EXERCISES the loading paths — it builds a real
    dictionary and a real dashboard manifest out of the generated tree. No Spark: both builders take
    the column list as an argument.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    from engine.config import SHARED_ASSETS, load_config, load_yaml, shared_asset
    from engine import dashboard as dash_engine, dictionary as dict_engine, tfl as tfl_engine
    out, _files, doc, cleanup = _tree()
    try:
        products_root = out / "products"
        for name in SHARED_ASSETS:
            assert shared_asset(products_root, name).exists(), \
                f"shared asset {name} is read at run time and is not in the deployment tree"

        registry = load_yaml(str(shared_asset(products_root, "registry")))
        catalog = load_yaml(str(shared_asset(products_root, "catalog")))
        auds = (load_yaml(str(shared_asset(products_root, "audiences"))) or {}).get("audiences")
        layout = load_yaml(str(shared_asset(products_root, "dashboard_vars")))
        specs = tfl_engine.load_specs(str(shared_asset(products_root, "tfl_specs")))
        assert catalog and auds and layout and specs, "a shared asset loaded empty"

        for pack in doc["products"]:
            slug = Path(pack).parent.name
            entry = next((t for t in (registry.get("tumors") or []) if t.get("slug") == slug), {})
            tumor = entry.get("tumor_class") or entry.get("code") or slug
            cfg = load_config(str(out / pack / "config" / "data_product.yaml"))
            cols = sorted(cfg.emitted_variables()) if hasattr(cfg, "emitted_variables") else None
            for audience in auds:
                d = dict_engine.build_dictionary(catalog, audience=audience, tumor=tumor,
                                                 audiences=auds, columns=cols)
                assert d, f"{pack}: the {audience} dictionary built empty from the deployment tree"
            m = dash_engine.build_manifest(cfg, catalog, tumor, dashboard=layout, columns=cols)
            assert m["summary"]["n_variables"] >= 0, m
    finally:
        cleanup()


def test_activation_is_governed_and_an_enabled_product_must_be_releasable():
    """Deploying the platform must schedule nothing, and switching a product on must not be a
    `pause_status` somebody edits in the generated bundle.

    `products/activation.yaml` is where that decision lives, and the rule that makes it safe is
    mechanical: `schedule_enabled: true` requires `releasable(pack) == True`. That is NOT a second
    release flag — releasability is derived from Gates 1-4 and there is nothing to set — so the
    dependency runs one way. A product may be releasable and deliberately unscheduled; never the
    reverse.
    """
    import shutil
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import bundle_products

    assert not bundle_products.activation_errors(str(REPO)), \
        bundle_products.activation_errors(str(REPO))
    # every materialized product has a block, and nothing is scheduled today
    blocks = bundle_products.activation(str(REPO))
    slugs = {slug for slug, _f, _v, _tc in bundle_products.entries(str(REPO))}
    assert set(blocks) == slugs, f"activation and the registry disagree: {set(blocks) ^ slugs}"
    for slug, block in blocks.items():
        assert block.get("schedule_enabled") is False, \
            f"{slug} ships scheduled — no pack in this repo has passed its gates"

    # the generated bundle carries the pause state, and it comes from that file
    doc = bundle_products.document(str(REPO))
    for slug in slugs:
        job = doc["resources"]["jobs"][f"rwdp_build_{slug}"]
        assert job["schedule"]["pause_status"] == "PAUSED", slug
        assert "run_as" not in job, f"{slug} declares an identity it has not been given"

    # ...and every rule BITES, on a throwaway copy. Asserting the real file is currently correct says
    # nothing about what happens when it stops being: two of these mutations survived a version of
    # this test that only inspected the repo as it stands.
    tmp = Path(_tf.mkdtemp())
    try:
        shutil.copytree(REPO / "products", tmp / "products",
                        ignore=shutil.ignore_patterns("reference", "prog_spec", "spec_pipeline"))
        act_path = tmp / "products" / "activation.yaml"
        slug = sorted(slugs)[0]

        def blocks_for(**overrides):
            """A complete, legal activation file, with one product's block overridden."""
            out = {s: {"schedule_enabled": False, "run_as": "", "can_manage": [], "can_view": [],
                       "cluster_policy_id": ""} for s in slugs}
            out[slug].update(overrides)
            return out

        def with_activation(blocks):
            # JSON is valid YAML, so the fixture states exactly the types it means — `true` the
            # boolean and `"true"` the string are different files, which is the whole point below.
            act_path.write_text(json.dumps({"products": blocks}, indent=1), encoding="utf-8")
            return bundle_products.activation_errors(str(tmp))

        # enabled ahead of its gates, and with no declared identity
        errors = with_activation(blocks_for(schedule_enabled=True))
        assert any("may not publish" in e for e in errors), \
            f"a product was enabled ahead of its gates and CI accepted it: {errors}"
        assert any("no run_as" in e for e in errors), errors

        # TRUTHY IS NOT TRUE. `1` and `yes` are what a hand-edit looks like, and neither may switch a
        # production schedule on — checked on the GENERATED JOB, which is the thing that ships. A
        # version of this test that only read the repo's own file could not see the difference.
        for truthy in (1, "yes", "true"):
            with_activation(blocks_for(schedule_enabled=truthy))
            spec = bundle_products.document(str(tmp))["resources"]["jobs"][f"rwdp_build_{slug}"]
            assert spec["schedule"]["pause_status"] == "PAUSED", \
                f"schedule_enabled: {truthy!r} unpaused a production job"

        # a materialized product with no block at all — silently unactivatable, and nobody notices
        missing = blocks_for()
        del missing[slug]
        errors = with_activation(missing)
        assert any("no activation block" in e for e in errors), \
            f"a materialized product missing from activation.yaml was accepted: {errors}"

        # a field left unstated is an unanswered question, not a default
        partial = blocks_for()
        del partial[slug]["run_as"]
        assert any("does not state run_as" in e for e in with_activation(partial)), partial

        # ...and a block for a product that does not exist
        extra = blocks_for()
        extra["nosuchproduct"] = {"schedule_enabled": False}
        assert any("not a materialized product" in e for e in with_activation(extra)), extra

        # the file missing entirely is safe (everything PAUSED) but must not be silent
        act_path.unlink()
        assert all(job["schedule"]["pause_status"] == "PAUSED"
                   for job in bundle_products.document(str(tmp))["resources"]["jobs"].values())
        assert any("does not exist" in e for e in bundle_products.activation_errors(str(tmp)))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_audit_bundle_is_named_and_covered_by_the_tree_digest():
    """The tree carries each pack's approvals, contract, registers and verdicts, and once
    RELEASE_EVIDENCE.yaml is present the runtime reads almost none of them. Raw evidence sitting
    beside a stored verdict, with nothing saying what it is for and nothing binding it, looks live and
    answers to nothing. So it is a NAMED bundle, listed per product and inside the digest.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    out, files, doc, cleanup = _tree()
    try:
        for pack, entry in doc["products"].items():
            bundle = entry["audit_bundle"]
            assert bundle, f"{pack} deploys no audit bundle"
            for rel in bundle:
                assert (out / rel).exists(), f"{pack}: {rel} is listed and not deployed"
                assert rel in files, rel
            # the config graph is NOT the audit bundle — two different reasons to be in the tree
            import product_gates
            config_graph = {f"{pack}/{r}" for r in product_gates.pack_yaml(str(out / pack))}
            assert not (set(bundle) & config_graph), set(bundle) & config_graph
            # the approvals a reader would come here for
            for wanted in ("source_refs.yaml", "handoff/MATURITY.yaml",
                           "handoff/FUNCTIONAL_CONTRACT.md"):
                assert f"{pack}/{wanted}" in bundle, f"{pack}: the audit bundle omits {wanted}"

        # BOUND. Editing an audit file moves the digest exactly like editing a config.
        good = deploy_tree.tree_digest(str(out))
        pack = next(iter(doc["products"]))
        target = out / doc["products"][pack]["audit_bundle"][0]
        target.write_text(target.read_text(encoding="utf-8") + "\n<!-- edited -->\n", encoding="utf-8")
        assert deploy_tree.tree_digest(str(out)) != good, \
            "an audit-bundle file can be edited without invalidating the release"
    finally:
        cleanup()


def test_every_shared_asset_the_runner_names_is_one_the_owner_defines():
    """`shared_asset` raises KeyError on an unknown name — and both dictionary and dashboard
    generation happen inside `except Exception` blocks that record the failure as a deliverable
    problem. So a name removed from `SHARED_ASSETS` while the runner still asks for it would surface
    as "dictionary generation FAILED", one indirect symptom for a one-word cause. Checked statically
    here, where it is a name mismatch rather than a runtime deliverable failure."""
    from engine.config import SHARED_ASSETS
    src = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    asked = set(re.findall(r'shared_asset\(products_root,\s*"([^"]+)"\)', src))
    assert asked, "the runner no longer resolves shared assets through the owner"
    unknown = sorted(asked - set(SHARED_ASSETS))
    assert not unknown, f"the runner asks for shared asset(s) SHARED_ASSETS does not define: {unknown}"
    # ...and no shared path is spelled literally beside the owner
    code = [ln for ln in src.splitlines() if not ln.lstrip().startswith("#")]
    for literal in ('products_root / "metadata"', 'products_root / "_reporting"',
                    'products_root / "registry.yaml"'):
        assert not any(literal in ln for ln in code), f"the runner spells {literal} itself again"


def test_staging_tables_are_build_scoped():
    """`final + "__staging"` was one name shared by every run of a product.

    Validate-only deliberately KEEPS its staging tables so a smoke run can be inspected, and the next
    run overwrote them — so the manifest pointing at that evidence was build-scoped while the evidence
    was not. Two runs at once (a retry, a manual run beside the schedule) raced for the same table.
    """
    from engine import release
    a = release.staging_ads("cat.sch.ads", "sha1_run1")
    b = release.staging_ads("cat.sch.ads", "sha1_run2")
    assert a != b, f"two builds stage to the same table: {a}"
    assert a.startswith("cat.sch.ads__staging__") and a.endswith("sha1_run1"), a
    assert release.staging_tfl("cat.sch.ads", "sha1_run1", "t1") == f"{a}__tfl_t1"
    assert release.staging_tfl("cat.sch.ads", "sha1_run1", "t1") != \
        release.staging_tfl("cat.sch.ads", "sha1_run2", "t1")
    # ...and the staging name is never rebuilt by hand in the notebook
    src = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    code = [ln for ln in src.splitlines() if not ln.lstrip().startswith("#")]
    assert any("staging = rel.staging_ads(final, build_id)" in ln for ln in code), \
        "the runner names its staging table some other way again"
    assert not any('"__staging"' in ln or "__tfl_{tid}" in ln for ln in code), \
        "a staging or TFL name is spelled in the notebook instead of engine.release"


def test_the_deployment_tree_is_the_only_documented_way_to_deploy():
    """The allowlist is a boundary only if it is the route. `databricks.yml` told operators to run
    `databricks bundle deploy` from the repository root, and the product runbooks still described a
    single `rwdp_build` job with a `tumor_slug` variable that no longer exists — so two routes were
    documented, one of which sends the stand-ins to the workspace and neither of which was
    obviously wrong to a reader.

    The mechanical half is in the runner: prod with no RELEASE_EVIDENCE.yaml cannot publish. This is
    the documentary half, and it is a test because prose is exactly what drifts.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import bundle_products
    jobs = {f"rwdp_build_{slug}" for slug, _f, _v, _tc in bundle_products.entries(str(REPO))}
    docs = [p for p in REPO.rglob("*.md") if ".git" not in p.parts and "build" not in p.parts]
    docs += [REPO / "databricks.yml"]
    stale, unrouted = [], []
    for p in docs:
        for i, line in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            where = f"{p.relative_to(REPO)}:{i}"
            if "--var tumor_slug" in line:
                stale.append(f"{where}: the tumor_slug variable was removed with the single job")
            m = re.search(r"bundle run (rwdp_build\S*)", line)
            if m and m.group(1) not in jobs and "<slug>" not in m.group(1):
                stale.append(f"{where}: names job {m.group(1)}, which the generator does not produce")
            # a deploy command must be rooted in the generated tree; databricks.yml OWNS the sequence
            if "bundle deploy" in line and p.name != "databricks.yml" and "build/deploy" not in line:
                unrouted.append(f"{where}: deploys from somewhere other than the generated tree")
    assert not stale, "stale deployment commands:\n" + "\n".join(f"  {s}" for s in stale)
    assert not unrouted, "deployment routes that bypass the allowlist:\n" + \
        "\n".join(f"  {s}" for s in unrouted)


def test_prod_refuses_to_publish_from_a_raw_checkout():
    """The mechanical half of the above. In a checkout the full repo is present, so a live
    `releasable()` there would SUCCEED and publish — the allowlist would be advice. The absence of
    RELEASE_EVIDENCE.yaml is the one signal that says "this is not the packaged tree", and in prod it
    has to be fatal. Dev keeps live derivation, which is what makes a checkout useful to develop in.
    """
    src = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    code = "\n".join(ln for ln in src.splitlines() if not ln.lstrip().startswith("#"))
    branch = code[code.index("_evidence = _repo / RELEASE_EVIDENCE"):code.index("governed = env ==")]
    assert 'elif env == "prod":' in branch, \
        "prod no longer refuses a deployment that carries no release evidence"
    # the live fallback survives, and is reachable ONLY below that prod branch
    assert branch.index('elif env == "prod":') < branch.index("releasable(str(_repo), _rel)"), \
        "the live derivation is reachable in prod again — a raw checkout could publish"


def test_recorded_release_evidence_says_the_same_thing_a_live_evaluation_says():
    """`RELEASE_EVIDENCE.yaml` is a WRITTEN-DOWN verdict, which is the shape this repo rejected once
    already as `release_ready: true`. What separates the two is that this one is regenerated from the
    real evaluation every build — so it is worth proving that it is, rather than assuming it.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest
    _out, _files, doc, cleanup = _tree()
    try:
        assert doc["products"], "the evidence evaluates no packs"
        for pack, entry in doc["products"].items():
            ok, why = source_manifest.releasable(str(REPO), pack)
            assert entry["releasable"] == ok, f"{pack}: recorded {entry['releasable']}, live {ok}"
            assert entry["blockers"] == why, f"{pack}: recorded blockers differ from the live ones"
            # and the shape the reader refuses: cleared AND blocked at once
            assert not (entry["releasable"] and entry["blockers"]), pack
    finally:
        cleanup()


def _complete_pack():
    """A synthetic pack that genuinely satisfies Gates 1-4. Returns (repo, rel, pack, write, sha).

    Every artifact here exists because a gate demands it, so the fixture doubles as the shortest
    written statement of what "releasable" actually costs: an approved and still-matching source, a
    complete extraction, a contract, a decision register, a QC register, two approval records hashed
    over five and two artifacts respectively, and a Gate 3 verdict report that pins the contract, the
    config and a live-schema report to the same delivery.

    It is a fixture, so when a gate grows a requirement this goes stale and fails loudly. That is the
    intended behaviour: a positive path nobody maintains is a positive path nobody has.
    """
    import json as _json
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint as cl
    import product_gates as _pg

    repo = Path(_tf.mkdtemp())
    rel = "products/oncology/demo/202601"
    pack = repo / rel

    def write(rel_in_pack, text):
        target = pack / rel_in_pack
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8", newline="\n")

    def sha(rel_in_pack):
        return _pg.sha256(str(pack / rel_in_pack))

    (repo / "platform").mkdir()
    write("reference/spec.xlsx", "fixture")
    write("source_refs.yaml",
          f"source_materials:\n  - material_id: program_spec\n    material_type: program_spec\n"
          f"    status: reviewed\n    path_or_link: {rel}/reference/spec.xlsx\n"
          f"    document_id: DEMO-1\n    revision: '1'\n    sha256: {sha('reference/spec.xlsx')}\n"
          f"    approval_date: 2026-01-05\n    approved_by: A. Approver\n"
          f"    data_refresh: 2026q1\n    rwb_qc_reference: QC-1\n"
          f"    ai_classification: sponsor_ai_eligible\n"
          f"    classified_by: R. Classifier\n    classified_date: 2026-01-05\n")
    write("handoff/MATURITY.yaml", "contract: approved\nconfiguration: approved\n")
    write("spec_pipeline/pipeline.conf",
          "TUMOR=demo\nSPEC_SOURCE_ID=program_spec\nTABS=demographics\nDOMAINS=demographics\n")
    write("spec_pipeline/out/extracted.json",
          _json.dumps({"items": [{"id": "demo:1", "domain": "demographics"}]}, indent=1))
    write("spec_pipeline/out/COVERAGE.md",
          "# Coverage\n\n| Spec ref | Disposition | Records |\n|---|---|---|\n"
          "| demo:1 | implemented | AGE |\n")
    write("config/data_product.yaml", "name: demo\nversion: '202601'\nrun:\n  refresh: 2026q1\n")
    record = {k: "n/a" for k in cl.TABLE_COLUMNS}
    record.update({"variable_id": "AGE", "spec_refs": "demo:1", "status": "approved",
                   "source": "{kind: derived, inputs: {}}"})
    write("handoff/FUNCTIONAL_CONTRACT.md", "# Functional contract\n\n" + cl.render_table([record]))
    write("handoff/DECISIONS.md",
          "# Decisions\n\n| ID | Question | Status | Owner | Resolution |\n|---|---|---|---|---|\n")
    write("handoff/SPEC_QC_FINDINGS.md",
          "# Spec QC findings\n\n| ID | Finding | Status | Owner | Resolution |\n|---|---|---|---|---|\n")
    write("handoff/CONTRACT_APPROVAL.yaml",
          f"approved_by: A. Approver\napproval_date: 2026-01-10\n"
          f"approved_extraction_sha256: {sha('spec_pipeline/out/extracted.json')}\n"
          f"approved_contract_sha256: {sha('handoff/FUNCTIONAL_CONTRACT.md')}\n"
          f"approved_coverage_sha256: {sha('spec_pipeline/out/COVERAGE.md')}\n"
          f"approved_decisions_sha256: {sha('handoff/DECISIONS.md')}\n"
          f"approved_spec_qc_sha256: {sha('handoff/SPEC_QC_FINDINGS.md')}\n"
          f"spec_qc_reviewed_by: Q. Reviewer\nspec_qc_review_date: 2026-01-08\n")
    write("handoff/CONFIGURATION_APPROVAL.yaml",
          f"approved_by: C. Approver\napproval_date: 2026-01-12\n"
          f"technically_reviewed_by: T. Reviewer\n"
          f"approved_configuration_bundle_sha256: {_pg.config_bundle_sha256(str(pack))}\n"
          f"approved_against_contract_sha256: {sha('handoff/FUNCTIONAL_CONTRACT.md')}\n")
    # Through the OWNER. Spelling the field's value here is a second definition of what
    # Gate 3 pins, and it was one: the fixture hashed the root file while the gate moved to
    # the delivery digest, so a fully evidenced pack stopped being releasable.
    cfg_sha = _pg.delivery_sha256(str(pack))
    fm = {"gate3_result": "passed", "contract_sha256": sha("handoff/FUNCTIONAL_CONTRACT.md"),
          "config_sha256": cfg_sha, "profile_sha256": "0f0f0f", "data_cut": "2026q1",
          "config_refresh": "2026q1", "complete": "true", "profile_schema": "demo_src",
          "union_member": "none", "tool": "fixture",
          "schema_validation_sha256": "1a1a1a", "schema_validation_result": "passed_live",
          "schema_validation_cut": "2026q1", "schema_validation_product_id": "demo",
          "schema_validation_schema": "demo_src", "schema_validation_config_sha256": cfg_sha,
          "unchecked": 0, "ambiguous_source": 0, "derived_input_candidate": 0, "bad_shape": 0,
          "not_a_column": 0, "not_a_table": 0, "unknown_source": 0, "absent_column": 0,
          "absent_table": 0, "reviewed_by": "V. Verifier", "review_date": "2026-01-11"}
    write("handoff/SOURCE_VERDICTS.md",
          "---\n" + "\n".join(f"{k}: {v}" for k, v in fm.items())
          + "\n---\n\n# Source verdicts\n\nNo vendor-sourced records in this pack.\n")
    return repo, rel, pack, write, sha


def test_releasable_returns_TRUE_for_a_pack_that_genuinely_passes_every_gate():
    """The existing positive test asserts only that Gate 1 stops complaining — it deliberately omits
    the contract, so it has never shown `releasable` producing a TRUE verdict at all. Three gates in
    this repo shipped demonstrably refusing and never demonstrably permitting, and two of them could
    not permit: the release gate was handed the wrong repo root, and validate-only fell through to
    the release phase. "It refuses" is half a proof.

    So this builds a pack that satisfies all four gates and asserts the exact answer, then removes one
    gate's evidence at a time and checks the blocker names that gate. Synthetic conformance, no
    workspace, no tumour pilot.
    """
    import shutil
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest

    repo, rel, _pack, _write, _sha = _complete_pack()
    try:
        ok, why = source_manifest.releasable(str(repo), rel)
        assert (ok, why) == (True, []), f"a fully evidenced pack is not releasable: {why}"
    finally:
        shutil.rmtree(repo, ignore_errors=True)

    # One gate at a time. Each mutation is something a pack could really be in the middle of.
    def unapprove_source(pack, write, sha):
        write("source_refs.yaml",
              (pack / "source_refs.yaml").read_text(encoding="utf-8")
              .replace("status: reviewed", "status: pending\n    why_provisional: awaiting RWB"))

    def move_the_spec(pack, write, sha):
        write("reference/spec.xlsx", "the workbook was revised under the approval")

    def unapprove_contract(pack, write, sha):
        write("handoff/MATURITY.yaml", "contract: coverage_complete\nconfiguration: draft\n")

    def unapprove_configuration(pack, write, sha):
        write("handoff/MATURITY.yaml", "contract: approved\nconfiguration: draft\n")

    def edit_the_contract_after_approval(pack, write, sha):
        write("handoff/FUNCTIONAL_CONTRACT.md",
              (pack / "handoff" / "FUNCTIONAL_CONTRACT.md").read_text(encoding="utf-8")
              + "\n<!-- a derivation changed after somebody signed -->\n")

    def edit_the_config_after_approval(pack, write, sha):
        write("config/data_product.yaml",
              (pack / "config" / "data_product.yaml").read_text(encoding="utf-8")
              + "  source_schema: somewhere_else\n")

    def drop_gate3_evidence(pack, write, sha):
        (pack / "handoff" / "SOURCE_VERDICTS.md").unlink()

    def fail_gate3(pack, write, sha):
        write("handoff/SOURCE_VERDICTS.md",
              (pack / "handoff" / "SOURCE_VERDICTS.md").read_text(encoding="utf-8")
              .replace("absent_column: 0", "absent_column: 3"))

    cases = [
        (unapprove_source, "Gate 1"), (move_the_spec, "Gate 1"),
        (unapprove_contract, "Gate 2"), (unapprove_configuration, "Gate 4"),
        (edit_the_contract_after_approval, "CONTRACT_APPROVAL"),
        (edit_the_config_after_approval, "CONFIGURATION_APPROVAL"),
        (drop_gate3_evidence, "SOURCE_VERDICTS"), (fail_gate3, "SOURCE_VERDICTS"),
    ]
    for mutate, expected in cases:
        repo, rel, pack, write, sha = _complete_pack()
        try:
            mutate(pack, write, sha)
            ok, why = source_manifest.releasable(str(repo), rel)
            assert ok is False, f"{mutate.__name__}: still releasable"
            assert any(expected in w for w in why), \
                f"{mutate.__name__}: blocked, but not by {expected} — {why}"
        finally:
            shutil.rmtree(repo, ignore_errors=True)


def test_editing_the_generated_tree_invalidates_its_release_evidence():
    """The commit binding compares two STRINGS and says nothing about the bytes.

    `--git-commit` was a free argument written straight into the evidence, so packaging a dirty
    checkout and stamping it with a clean approved SHA produced a match over a configuration that
    commit does not identify. Editing the generated tree afterwards did the same. The digest closes
    both, and this proves it closes them — by editing the tree and re-asking.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    import source_manifest
    out, _files, doc, cleanup = _tree(git_commit="abc123")
    try:
        pack = next(iter(doc["products"]))
        evidence = str(out / "RELEASE_EVIDENCE.yaml")
        good = deploy_tree.tree_digest(str(out))
        assert good == doc["tree_sha256"], "the build recorded a digest it cannot reproduce"

        # a config EDITED after packaging
        target = out / pack / "config" / "data_product.yaml"
        original = target.read_text(encoding="utf-8")
        target.write_text(original + "\n# slipped in after the evidence was written\n", encoding="utf-8")
        assert deploy_tree.tree_digest(str(out)) != good, "editing a deployed config did not move the digest"
        ok, why = source_manifest.evidence_verdict(evidence, pack, "abc123",
                                                   tree_sha256=deploy_tree.tree_digest(str(out)))
        assert ok is False and any("tree_sha256" in w for w in why), why
        target.write_text(original, encoding="utf-8")
        assert deploy_tree.tree_digest(str(out)) == good, "restoring the file did not restore the digest"

        # a file ADDED — the half a recorded inventory would miss
        extra = out / pack / "config" / "extra.yaml"
        extra.write_text("sneaky: true\n", encoding="utf-8")
        assert deploy_tree.tree_digest(str(out)) != good, "adding a file did not move the digest"
        extra.unlink()

        # bytecode and tool metadata are NOT covered — the notebook imports the tools inside the tree,
        # so the first import would otherwise invalidate the release and the gate would be turned off
        (out / "platform" / "tools" / "__pycache__").mkdir(exist_ok=True)
        (out / "platform" / "tools" / "__pycache__" / "x.cpython-311.pyc").write_bytes(b"\x00")
        assert deploy_tree.tree_digest(str(out)) == good, \
            "running the tree changes its digest — this gate would not survive contact with a cluster"
    finally:
        cleanup()


def test_deploy_tree_never_deletes_a_directory_it_did_not_create():
    """`build()` began `if os.path.exists(out): shutil.rmtree(out)`, guarded only by a CLI check that
    tests `startswith(root + os.sep)` — false for the checkout root itself, for any ancestor of it,
    and for the home directory. `--out .` from the repo root would have deleted the repository."""
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    precious = Path(_tf.mkdtemp()) / "precious"
    precious.mkdir()
    (precious / "important.txt").write_text("do not delete me", encoding="utf-8")
    try:
        try:
            deploy_tree.build(str(REPO), str(precious))
            raise AssertionError("deploy_tree replaced a directory it did not create")
        except SystemExit as exc:
            assert deploy_tree.MARKER in str(exc), exc
        assert (precious / "important.txt").read_text(encoding="utf-8") == "do not delete me"

        # ...and its OWN output it may replace, or the tool is unusable
        out = precious.parent / "tree"
        deploy_tree.build(str(REPO), str(out))
        assert (out / deploy_tree.MARKER).exists(), "the tree carries no marker, so it can never be rebuilt"
        deploy_tree.build(str(REPO), str(out))
    finally:
        import shutil
        shutil.rmtree(precious.parent, ignore_errors=True)


def test_the_packaged_commit_is_derived_from_HEAD_not_accepted_from_the_caller():
    """A supplied SHA may CONFIRM HEAD; it may not replace it. Otherwise the operator chooses which
    commit the evidence claims, which is the whole binding."""
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    head, _dirty = deploy_tree.git_state(str(REPO))
    assert head and len(head) == 40, f"HEAD did not resolve in the checkout: {head!r}"

    src = (REPO / "platform" / "tools" / "deploy_tree.py").read_text(encoding="utf-8")
    code = "\n".join(ln for ln in src.splitlines() if not ln.lstrip().startswith("#"))
    assert "head, dirty = git_state(root)" in code, "the builder no longer reads HEAD itself"
    assert "a.git_commit.strip() != head" in code, "a supplied SHA is accepted without confirming HEAD"
    assert "dirty and not a.allow_dirty" in code, "a dirty checkout is packaged as a release again"
    # --allow-dirty must produce an UNBINDABLE tree, not a differently-stamped one
    dirty_branch = code[code.index("elif dirty:"):code.index("elif a.git_commit")]
    assert 'commit = ""' in dirty_branch, \
        "--allow-dirty stamps a commit — a development tree could then publish"


def test_evidence_verdict_refuses_every_way_of_not_describing_this_deployment():
    """The stored verdict is only safe because of what refuses it. Each case below is a separate way
    a file could grant a release it was not evaluated for, and each must fail CLOSED.
    """
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest
    tmp = Path(_tf.mkdtemp())
    rel = "products/oncology/demo/202601"
    good = (f"git_commit: abc123\ntree_sha256: feed01\nproducts:\n  {rel}:\n"
            f"    releasable: true\n    blockers: []\n")

    def verdict(text, commit="abc123", tree="feed01", evidence=None):
        p = tmp / "RELEASE_EVIDENCE.yaml"
        p.write_text(text, encoding="utf-8")
        import product_gates as _pg
        ev = _pg.sha256(str(p)) if evidence is None else evidence
        return source_manifest.evidence_verdict(str(p), rel, commit, tree_sha256=tree,
                                                evidence_sha256=ev)

    cases = {
        "a different commit": (good, "999999"),
        "no commit passed by the job": (good, ""),
        # the byte binding: a matching commit over different bytes is the dirty-checkout attack
        "a different tree digest": (good, "abc123", "0bad00"),
        # THE FILE THAT GRANTS THE RELEASE. `tree_sha256` must exclude it — a digest cannot cover the
        # bytes it lives in — so an operator flipping `releasable` to true and emptying `blockers`
        # changed nothing any other check looked at. The digest arrives out of band instead.
        "an evidence file edited after packaging": (good, "abc123", "feed01", "0dead0"),
        "no evidence digest passed by the job": (good, "abc123", "feed01", ""),
        "no digest computed by the caller": (good, "abc123", ""),
        "no digest recorded in the file": (good.replace("tree_sha256: feed01", 'tree_sha256: ""'),
                                           "abc123", "feed01"),
        "no commit recorded in the file": (good.replace("git_commit: abc123", 'git_commit: ""'), "abc123"),
        "this pack was not evaluated": (good.replace(rel, "products/oncology/other/202601"), "abc123"),
        "no products mapping at all": ("git_commit: abc123\n", "abc123"),
        # `1` and `yes` are what a hand-edit looks like; `is True` is what refuses them
        "truthy, not true": (good.replace("releasable: true", "releasable: 1"), "abc123"),
        "the string yes": (good.replace("releasable: true", 'releasable: "yes"'), "abc123"),
        # nothing GENERATES this shape — only an edit does, and it is the exact edit someone makes
        "cleared and blocked at once": (good.replace("blockers: []", "blockers: [Gate 2: not approved]"),
                                        "abc123"),
        "not a mapping": ("- a\n- b\n", "abc123"),
        "will not parse": ("git_commit: [unclosed\n", "abc123"),
    }
    for why, case in cases.items():
        ok, blockers = verdict(*case)
        assert ok is False, f"released on evidence with {why}"
        assert blockers, f"refused for {why} but said nothing about it"

    # ...and a file that is simply absent is not a permission either — that is the caller's branch,
    # so assert the caller has it rather than this function.
    runner = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    code = [ln for ln in runner.splitlines() if not ln.lstrip().startswith("#")]
    assert any("if _evidence.exists():" in ln for ln in code), "the runner stopped branching on the file"
    assert any("releasable(str(_repo), _rel)" in ln for ln in code), \
        "the runner no longer derives releasability live when there is no evidence file"


def test_evidence_verdict_says_YES_when_the_evidence_does_describe_this_deployment():
    """The half that keeps being the one that breaks. Three separate gates in this repo were shipped
    demonstrably REFUSING and never demonstrably PERMITTING, and two of them could not permit at all.
    """
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest
    p = Path(_tf.mkdtemp()) / "RELEASE_EVIDENCE.yaml"
    rel = "products/oncology/demo/202601"
    p.write_text(f"git_commit: abc123\ntree_sha256: feed01\nproducts:\n  {rel}:\n"
                 f"    releasable: true\n    blockers: []\n", encoding="utf-8")
    import product_gates
    ok, blockers = source_manifest.evidence_verdict(str(p), rel, "abc123", tree_sha256="feed01",
                                                    evidence_sha256=product_gates.sha256(str(p)))
    assert ok is True, blockers
    assert blockers == []

    # a recorded NO carries its reasons through, so the runner can print them
    p.write_text(f"git_commit: abc123\ntree_sha256: feed01\nproducts:\n  {rel}:\n"
                 f"    releasable: false\n"
                 f"    blockers: ['Gate 2: contract is draft, not approved']\n", encoding="utf-8")
    ok, blockers = source_manifest.evidence_verdict(str(p), rel, "abc123", tree_sha256="feed01",
                                                    evidence_sha256=product_gates.sha256(str(p)))
    assert ok is False and blockers == ["Gate 2: contract is draft, not approved"], blockers


def test_a_run_pointed_at_another_delivery_may_not_publish():
    """THE OVERRIDE THAT OUTRAN THE APPROVAL.

    `evidence_verdict` proves the recorded verdict describes this DEPLOYMENT — commit, tree digest,
    evidence bytes, pack entry. None of that is a statement about the RUN. The build job takes
    `refresh` and `source_schema` as widgets and hands them to `load_config` as overrides, so a job
    parameterised at cut 2026m07 / schema B could read a verdict derived for 2026m06 / schema A,
    satisfy every binding, and reach the release phase with nobody having confirmed a mapping
    against the data it actually read. Preflight proves the tables EXIST; it cannot prove a person
    looked at them.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest

    committed = {"run": {"refresh": "2026m06", "source_schema": "schema_A",
                         "output_schema": "out_dev"}}
    assert source_manifest.delivery_drift(committed, committed) == [], \
        "an un-overridden run is reported as drifted"

    for key, value in (("refresh", "2026m07"), ("source_schema", "schema_B")):
        run = {"run": {**committed["run"], key: value}}
        why = source_manifest.delivery_drift(committed, run)
        assert len(why) == 1 and f"run.{key}" in why[0], why

    # ...and the OUTPUT schema is still free. It decides where rows land, not what was read, and it
    # is the one binding an operator is expected to move per environment — the whole reason `run:`
    # was split out of the Gate 4 digest in the first place.
    moved = {"run": {**committed["run"], "output_schema": "out_prod"}}
    assert source_manifest.delivery_drift(committed, moved) == [], \
        "moving the output schema blocks publication — that is the false invalidation again"

    # A UNION resolves member schemas from `source_union.members`, so `run.source_schema` is unused
    # there and must not be compared: the runner prints exactly that.
    union = {"source_union": {"members": [{"schema": "edm"}, {"schema": "dostar"}]},
             "run": {"refresh": "2026m06", "source_schema": "REPLACE_ME"}}
    union_run = {**union, "run": {**union["run"], "source_schema": "anything_at_all"}}
    assert source_manifest.delivery_drift(union, union_run) == [], \
        "a union pack is held to a source_schema its engine never reads"


def test_the_runner_applies_the_delivery_check_before_it_decides_governed():
    """A pure function nobody calls is the fail-open with extra steps.

    The notebook cannot be executed in CI, so the only thing that can be asserted about it is its
    TEXT — and it has to be asserted on non-comment lines, because the block that calls this is
    thirteen lines of comment naming every identifier involved. This codebase has written a guard
    that its own explanation satisfied more than once.
    """
    src = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    code = [l for l in src.splitlines()
            if l.strip() and not l.lstrip().startswith("#")]
    body = "\n".join(code)
    assert "delivery_drift(" in body, \
        "run_rwdp.py never calls delivery_drift — the override fail-open is open again"

    def at(needle):
        return next(i for i, l in enumerate(code) if needle in l)
    # The drift must be folded in BEFORE `governed` is derived, or a prod run acquires the strict
    # gates from a verdict that does not cover the delivery it is about to read.
    assert at("delivery_drift(") < at("governed = "), \
        "the delivery check runs after `governed` is decided, so it decides nothing"
    assert at("release_ready, release_blockers = False, _drift") < at("governed = "), \
        "the drift is computed but never clears release_ready"


def test_a_source_union_is_not_held_to_a_source_schema_it_never_reads():
    """ONE WRONG LIST, TWO OPPOSITE FAULTS.

    Under `source_union` the member schemas come from `source_union.members` and `run.source_schema`
    is unused — endometrial's own pipeline.yaml says "unused under source_union below". Applying the
    flat DELIVERY_KEYS list to it made the pack populate an irrelevant field to satisfy Gate 3 (a
    false blocker) AND hashed that field into the delivery digest, so editing a value the engine
    ignores invalidated source evidence that was still true (a false invalidation).

    Required and hashed must be the SAME set, so both derive from `delivery_keys`.
    """
    from engine import config as ecfg
    single = {"run": {"refresh": "r", "source_schema": "s"}}
    union = {"source_union": {"members": [{"schema": "a"}]}, "run": {"refresh": "r"}}

    assert "source_schema" in ecfg.delivery_keys(single)
    assert "source_schema" not in ecfg.delivery_keys(union)
    assert "source_schema" in ecfg.delivery_required(single)
    assert "source_schema" not in ecfg.delivery_required(union)
    # The digest follows the same list, so the unused field cannot move it.
    assert "source_schema" not in ecfg.delivery_bindings(union)
    assert set(ecfg.delivery_required(union)) <= set(ecfg.delivery_keys(union)), \
        "a key is REQUIRED that is not even part of this product's delivery identity"

    # Derived by subtraction from the one list, never restated — the two must not be able to differ.
    assert set(ecfg.delivery_keys(single)) == set(ecfg.DELIVERY_KEYS)
    assert set(ecfg.delivery_keys(union)) < set(ecfg.DELIVERY_KEYS)

    # And the live union pack is no longer blocked on it. Asserted against a real pack so the rule
    # cannot pass over a repository where no product has a union.
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates as pg
    unions = [p for p in pg.products(str(REPO))
              if (pg.read_yaml(os.path.join(str(REPO), p, "config", "data_product.yaml"))[0]
                  or {}).get("source_union")]
    assert unions, "no pack declares a source_union — this test would prove nothing"
    for rel in unions:
        raw = ecfg.merged_raw(os.path.join(str(REPO), rel, "config", "data_product.yaml"))
        assert "source_schema" not in ecfg.delivery_required(raw), rel


def test_the_evidence_filename_and_its_reader_have_exactly_one_definition():
    """A filename spelled in the writer and again in the reader is a deployment that writes evidence
    nothing looks at — and it would look green, because each side is internally consistent."""
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    import source_manifest
    assert not hasattr(deploy_tree, "EVIDENCE"), \
        "deploy_tree re-spells the evidence filename instead of using source_manifest.RELEASE_EVIDENCE"
    tree_src = (REPO / "platform" / "tools" / "deploy_tree.py").read_text(encoding="utf-8")
    code = [ln for ln in tree_src.splitlines() if not ln.lstrip().startswith("#")]
    assert not any('"RELEASE_EVIDENCE.yaml"' in ln for ln in code), \
        "the evidence filename is spelled literally in deploy_tree"
    assert source_manifest.RELEASE_EVIDENCE == "RELEASE_EVIDENCE.yaml"

    # the runner decides through the shared function, not a local re-read of the file
    runner = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    rcode = [ln for ln in runner.splitlines() if not ln.lstrip().startswith("#")]
    assert any("evidence_verdict(" in ln for ln in rcode), \
        "the runner no longer uses the shared verdict reader"
    assert not any("_ev.get(" in ln or "safe_load(_evidence" in ln for ln in rcode), \
        "the runner is parsing the evidence file itself again"



def test_packaging_runs_the_bundle_and_activation_gates_before_copying_anything():
    """`deploy_tree` took its pack list from `bundle_products.entries` and then copied the COMMITTED
    `resources/products.yml` without asking whether it still matched the registry and the activation
    file. So a clean commit carrying a stale or hand-edited generated resource packaged cleanly, and
    the deployed job set was not the governed one. CI catches that; this repository merges before CI
    runs, which is exactly when a packaging step should not be trusting CI.

    Calls the EXISTING authorities — `activation_errors` owns `schedule_enabled ⇒ releasable`, and
    `render` owns what the generated file should say. A third validator here would be the duplicate
    this repo keeps paying for.
    """
    import shutil
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import bundle_products
    import deploy_tree

    # the real repo packages cleanly
    out = Path(_tf.mkdtemp()) / "tree"
    try:
        deploy_tree.build(str(REPO), str(out))
    finally:
        shutil.rmtree(out.parent, ignore_errors=True)

    # ...and a STALE generated bundle is refused before anything is written
    tmp = Path(_tf.mkdtemp())
    try:
        for name in ("platform", "products", "resources", "governance", "databricks.yml"):
            src = REPO / name
            if src.is_dir():
                shutil.copytree(src, tmp / name,
                                ignore=shutil.ignore_patterns("reference", "__pycache__"))
            else:
                shutil.copy2(src, tmp / name)
        target = tmp / "resources" / "products.yml"
        target.write_text(target.read_text(encoding="utf-8") + "\n# hand-edited\n", encoding="utf-8")
        dest = tmp / "out"
        try:
            deploy_tree.build(str(tmp), str(dest))
            raise AssertionError("a stale generated bundle was packaged")
        except SystemExit as exc:
            assert "STALE" in str(exc), exc
        assert not dest.exists(), "the tree was written before the gate refused"

        # ...and an ILLEGAL activation is refused too
        target.write_text(bundle_products.render(str(tmp)), encoding="utf-8")
        act = tmp / "products" / "activation.yaml"
        # The INDENTED block, not the first textual match — the header comment explains the field and
        # a bare `.replace(..., 1)` edited the prose, so this fixture proved nothing on the first run.
        lines = act.read_text(encoding="utf-8").splitlines(True)
        for i, ln in enumerate(lines):
            if ln.startswith("    schedule_enabled: false"):
                lines[i] = "    schedule_enabled: true\n"
                break
        else:
            raise AssertionError("no activation block to enable — the fixture checks nothing")
        act.write_text("".join(lines), encoding="utf-8")
        # REGENERATE from the new activation, so `products.yml` is CURRENT and only the activation
        # rule can refuse. Leaving it stale meant the staleness check fired first and this scenario
        # passed with the activation check deleted — one guard masking another, again.
        target.write_text(bundle_products.render(str(tmp)), encoding="utf-8")
        try:
            deploy_tree.build(str(tmp), str(dest))
            raise AssertionError("a product enabled ahead of its gates was packaged")
        except SystemExit as exc:
            assert "activation is not legal" in str(exc), exc
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# --- repo hygiene: what may never be COMMITTED ---------------------------------------------------

def test_the_checkout_carries_no_scanned_document_or_transfer_snapshot():
    """The property, re-derived rather than asserted.

    A document can state that restricted source material is not held here; only a check makes that
    true tomorrow. This is the check, and it reads the git index rather than `.gitignore`, which says
    nothing about what is already tracked.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    assert len(repo_hygiene.tracked(str(REPO))) > 100, "the git index looks empty — this is vacuous"
    found = repo_hygiene.errors(str(REPO))
    assert not found, found


def test_repo_hygiene_refuses_a_document_wherever_it_sits():
    """The check must bite on the NAME, at any depth, under any directory.

    Matching basenames rather than paths is what survives a rename or an extra nesting level — and the
    deployment tree derives its file-kind refusals from here rather than keeping a second list that
    could come to permit one.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    import repo_hygiene
    planted = ["products/oncology/oc/202606/prog_spec/reference/spec appendix.pdf",
               "a/b/c/d/e/Meeting.msg",
               "tools/repo_snapshot.txt"]
    hits = {p for p, _why in repo_hygiene.restricted_files("", planted + ["engine/config.py"])}
    assert hits == set(planted), hits
    # ...and a spreadsheet is judged by its REGISTRATION, not its extension. The governed workbook is
    # permitted because a pack names it; the same file one directory away is not. A blanket `.xlsx`
    # allowance — which is what "the one pack with a real spec must stay buildable" first produced —
    # equally admits a vendor data dictionary, a patient-level extract or a saved profile.
    wb = "products/oncology/oc/202606/prog_spec/reference/PROG_SPEC_RWDP_Ovarian_PANO_202606.xlsx"
    assert wb in repo_hygiene.registered_workbooks(str(REPO)), \
        "the OC workbook is not registered — this assertion would pass for the wrong reason"
    assert not repo_hygiene.restricted_files(str(REPO), [wb])
    assert repo_hygiene.restricted_files(str(REPO), ["sandbox/copy of the same workbook.xlsx"])

    # TWO RULES, and conflating them made "only approved specifications reach production" untrue. That
    # OC workbook is a RECONSTRUCTION at `status: pending`, recorded in its own manifest as something
    # that must not be read as the specification. A checkout may hold it — refusing it would refuse
    # the work — and a shipped artifact may not.
    assert wb not in repo_hygiene.production_eligible_workbooks(str(REPO))
    assert repo_hygiene.restricted_files(str(REPO), [wb], production=True), \
        "a pending reconstruction is production-eligible"
    assert deploy_tree.forbidden_in([wb]) == [wb], "the tree guard admits a pending workbook"
    # ...and it fails CLOSED on today's real state: nothing is reviewed, so nothing is eligible.
    assert repo_hygiene.production_eligible_workbooks(str(REPO)) <= \
        repo_hygiene.registered_workbooks(str(REPO))
    # The deployment tree refuses the same files without restating the list.
    assert set(deploy_tree.forbidden_in(planted + ["engine/config.py"])) >= set(planted)


def test_every_product_declares_which_schema_evidence_it_owes():
    """The profiler was the only route the framework had, because the vendor it was built against does
    not permit holding the delivered documentation — and that constraint was absorbed as if it were
    universal. Under a vendor whose dictionary the sponsor may keep, profiling patient-level data to
    learn what a document already states is a computation over real records for no evidentiary gain.

    So the route is DECLARED, and the point of declaring it is that `--profile` absent stops meaning
    two things at once: "evidenced another way" and "nobody has run one yet".
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates
    assert product_gates.vendor_policy_errors(str(REPO)) == [], \
        product_gates.vendor_policy_errors(str(REPO))
    packs = product_gates.products(str(REPO))
    assert packs, "no packs discovered — this test would be vacuous"
    for rel in packs:
        route, why = product_gates.evidence_route(str(REPO), rel)
        assert route in product_gates.SCHEMA_EVIDENCE, f"{rel}: {why}"


def test_a_declared_route_with_no_evidence_report_is_refused_where_the_operator_is():
    """`vendor_documentation` was declarable and could never complete Gate 4. Gate 4 reads a
    SOURCE_VERDICTS.md carrying a profile digest, `complete: true` and the profile counters;
    `source_check` refuses a profile when the route is documentation, then writes
    `profile_sha256: none`, which Gate 4 rejects for a reason that has nothing to do with the real
    situation. A route that can be chosen and never completed is worse than one that says so.

    The declaration STAYS legal — recording the decision before the tooling exists is the point of a
    vendor policy, and a policy that could not express it would push every product back onto the
    profiler. What changes is that it refuses at the point of selection, naming the gap.
    """
    import shutil
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates
    assert set(product_gates.IMPLEMENTED_EVIDENCE) < set(product_gates.SCHEMA_EVIDENCE), \
        "nothing is unimplemented — this test would be vacuous"
    # Today nothing trips it: every product is on the profiler route.
    for rel in product_gates.products(str(REPO)):
        assert product_gates.unimplemented_route(str(REPO), rel) is None, rel
    tmp = Path(_tf.mkdtemp())
    try:
        for d in ("governance", "products"):
            shutil.copytree(REPO / d, tmp / d, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__"))
        pol = tmp / "governance" / "vendor_policy.yaml"
        pol.write_text(pol.read_text(encoding="utf-8").replace(
            "schema_evidence: data_profile", "schema_evidence: vendor_documentation", 1),
            encoding="utf-8")
        rel = "products/oncology/prostate/202606"
        route, _why = product_gates.evidence_route(str(tmp), rel)
        assert route == "vendor_documentation", route          # still a LEGAL declaration
        gap = product_gates.unimplemented_route(str(tmp), rel)
        assert gap and "no evidence report exists for that route yet" in gap, gap
        assert not product_gates.uses_data_profiler(str(tmp), rel), \
            "an unimplemented route fell back to reading delivered data"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_an_undeclared_or_unknown_vendor_does_NOT_default_to_profiling():
    """FAIL-CLOSED, and this is the whole reason to declare it. A tool that reads patient-level data
    must not do so because nobody said not to — and an unreadable policy is not a passing one, the
    same rule `boundary_markers` follows about a missing marker list."""
    import shutil
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates
    tmp = Path(_tf.mkdtemp())
    try:
        for d in ("governance", "products"):
            shutil.copytree(REPO / d, tmp / d, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__"))
        reg = tmp / "products" / "registry.yaml"
        reg.write_text(reg.read_text(encoding="utf-8").replace("vendor: flatiron",
                                                               "vendor: acme_data", 1),
                       encoding="utf-8")
        rel = "products/oncology/prostate/202606"
        route, why = product_gates.evidence_route(str(tmp), rel)
        # Either the pack is now on the unknown vendor (refused) or the replacement hit another entry;
        # assert the POLICY catches it either way, which is the claim that matters.
        assert any("acme_data" in e for e in product_gates.vendor_policy_errors(str(tmp))), \
            product_gates.vendor_policy_errors(str(tmp))
        if route is None:
            assert "acme_data" in why or "schema_evidence" in why, why
            assert not product_gates.uses_data_profiler(str(tmp), rel)
        # A route the vocabulary does not contain is not a route. `schema_evidence: maybe` would
        # otherwise sit in the policy unremarked, and `evidence_route` would refuse every product on
        # that vendor with a message about the value rather than the file naming its own defect.
        pol = tmp / "governance" / "vendor_policy.yaml"
        pol.write_text(pol.read_text(encoding="utf-8").replace(
            "schema_evidence: data_profile", "schema_evidence: whatever_is_lying_around", 1),
            encoding="utf-8")
        errs = product_gates.vendor_policy_errors(str(tmp))
        assert any("whatever_is_lying_around" in e for e in errs), errs
        # ...and a vendor that states no reason for its route. Every other governed judgment here
        # carries one; a value nobody can question is a value nobody can correct.
        pol.write_text("vendors:\n  flatiron:\n    vendor_documentation: not_available\n"
                       "    schema_evidence: data_profile\n", encoding="utf-8")
        assert any("states no `why`" in e for e in product_gates.vendor_policy_errors(str(tmp))), \
            product_gates.vendor_policy_errors(str(tmp))
        # ...and a policy that cannot be read refuses too, rather than reporting no constraint.
        pol.write_text("- not: a mapping\n", encoding="utf-8")
        route, why = product_gates.evidence_route(str(tmp), rel)
        assert route is None and not product_gates.uses_data_profiler(str(tmp), rel), (route, why)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_the_tree_deploys_the_tools_the_runner_IMPORTS_and_no_others():
    """`PLATFORM` carried `tools` whole, so all 23 modules went to the workspace when the runner
    imports six — the AI slicer, the contract-drafting interface, the profiler runner and every gate
    CLI among them. Those are not inert in production: they read specifications and write governed
    files, in the one place nobody reviews a diff.

    Asserted BOTH ways. Missing a module the runner imports fails in the workspace at run time, which
    is exactly where this repo cannot test; carrying one it does not is the exposure. And the set is
    derived from the imports rather than listed, so it cannot drift from them.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    out, files, _doc, cleanup = _tree()
    try:
        want = set(deploy_tree.runtime_tools(str(REPO)))
        assert {"source_manifest", "deploy_tree", "product_gates", "contract_lint"} <= want, want
        got = {p.split("/")[-1][:-3] for p in files if p.startswith("platform/tools/")}
        assert got == want, f"deployed {sorted(got - want)}, missing {sorted(want - got)}"
        # ...and the modules that read or write governed material are NOT among them.
        for dev in ("spec_slice", "contract_record", "run_product_profile", "finalize"):
            assert dev not in got, f"{dev} reached the workspace"
        # The runner must actually import out of the tree — a subset that drops a transitive
        # dependency is a tree that fails at the first `import`, in production.
        for mod in sorted(want):
            assert (out / "platform" / "tools" / f"{mod}.py").exists(), mod
    finally:
        cleanup()


def test_a_BUILT_tree_is_checkable_and_the_check_bites():
    """`repo_hygiene --check` cannot see a generated tree — it reads the git INDEX, and a tree has no
    `.git`; run from the repository it skips `build/` as generated. So the artifact actually being
    packaged was checked by nothing, and a file dropped into it by hand reached the workspace. The
    runtime would refuse to publish afterwards on a digest mismatch, which is integrity; refusing to
    ship it is containment."""
    import shutil as _sh
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    out, files, _doc, cleanup = _tree()
    try:
        assert deploy_tree.check_tree(str(out)) == [], deploy_tree.check_tree(str(out))
        # A PLANTED FILE — the case this exists for. Three findings, and each is a different question:
        # what may be here, does the inventory still match, and is this tool one the runtime imports.
        (out / "products" / "appendix.pdf").write_text("%PDF-1.4\n", encoding="utf-8")
        _sh.copy(REPO / "platform" / "tools" / "spec_slice.py", out / "platform" / "tools")
        found = deploy_tree.check_tree(str(out))
        assert any("must not be in a deployment tree" in e for e in found), found
        assert any("tree_sha256 MISMATCH" in e for e in found), found
        assert any("spec_slice.py is in the tree" in e for e in found), found
        (out / "products" / "appendix.pdf").unlink()
        (out / "platform" / "tools" / "spec_slice.py").unlink()
        # ...and a REMOVED runtime module, which fails at `import` inside a workspace and nowhere else.
        (out / "platform" / "tools" / "contract_lint.py").unlink()
        found = deploy_tree.check_tree(str(out))
        assert any("contract_lint.py is imported by an entrypoint and is NOT in the tree" in e
                   for e in found), found
        # A directory that is not a built tree is REFUSED rather than reported clean.
        assert "was not built by deploy_tree" in deploy_tree.check_tree(str(REPO))[0]
    finally:
        cleanup()


def test_the_audit_bundle_can_be_written_OUTSIDE_the_runtime_tree():
    """Two artifacts, two audiences. The bundle answers "what was approved" and the runtime reads
    almost none of it; it also carries the source-provenance prose — pending workbook locations,
    stand-in explanations, missing attestations — that a runtime workspace has no business holding.
    Either way RELEASE_EVIDENCE.yaml still LISTS it, so the tree says what evidence exists.

    "almost none" is the exception that matters: `RUNTIME_EVIDENCE` is the subset the RUN reads, and
    it goes into the tree either way. See the fixture test below for why.
    """
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    import product_gates
    assert set(deploy_tree.RUNTIME_EVIDENCE) <= set(deploy_tree.PACK_EVIDENCE), \
        "RUNTIME_EVIDENCE is not a subset of PACK_EVIDENCE — a runtime file nothing archives"
    tmp = Path(_tf.mkdtemp())
    try:
        out, ev = tmp / "deploy", tmp / "evidence"
        # A commit, so the tree is release-bindable and `check_tree` has nothing else to report — the
        # value is irrelevant here, its PRESENCE is what the packaging check asks about.
        files = deploy_tree.build(str(REPO), str(out), git_commit="0" * 40, evidence_out=str(ev))
        doc, err = product_gates.read_yaml(str(out / deploy_tree.sm.RELEASE_EVIDENCE))
        assert not err, err
        for pack, entry in doc["products"].items():
            assert entry["audit_bundle"], f"{pack}: nothing listed"
            assert entry["audit_bundle_in_tree"] is False, pack
            for rel in entry["audit_bundle"]:
                assert (ev / rel).exists(), f"{rel} was not written to the evidence directory"
                if any(rel.endswith("/" + r) for r in deploy_tree.RUNTIME_EVIDENCE):
                    continue                      # runtime input — deliberately in both
                assert not (out / rel).exists(), f"{rel} is still in the runtime tree"
                assert rel not in files, rel
        # ...and the tree is still a valid, checkable tree without it.
        assert deploy_tree.check_tree(str(out)) == [], deploy_tree.check_tree(str(out))
    finally:
        _sh.rmtree(tmp, ignore_errors=True)


def test_the_release_approval_reaches_the_tree_even_when_the_bundle_does_not():
    """THE ONE PIECE OF EVIDENCE THE RUN ITSELF OPENS, AND `--evidence-out` USED TO SEND IT AWAY.

    Everything else in `PACK_EVIDENCE` is for an auditor: the deployed tree deliberately cannot
    re-derive Gates 1-4 from it, which is exactly why `RELEASE_EVIDENCE.yaml` records the verdict
    instead. Gate 6 cannot work that way. The approval names a BUILD, so it does not exist when the
    deployment is packaged, and no verdict recorded at build time can stand in for it —
    `run_rwdp.py` opens `<runtime root>/<pack>/handoff/RELEASE_APPROVAL.yaml` at run time.

    Under `--evidence-out DIR` the whole bundle went to DIR and nothing to the tree, so the runner
    looked where the file was not. Gate 6 fails closed, so the effect was a release that could never
    complete rather than one that completed unapproved — the kind of defect that surfaces only once
    the promotion path exists and someone is waiting on it.

    THE FIXTURE IS THE POINT. No pack carries a RELEASE_APPROVAL.yaml today, so a test over the real
    repository asserts this against a file that is absent and passes whatever the code does. That is
    the absence-reported-as-a-clean-result shape this repository keeps finding.
    """
    import shutil as _sh
    import tempfile as _tf
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    import product_gates
    tmp = Path(_tf.mkdtemp())
    try:
        src = tmp / "repo"
        for name in ("platform", "products", "resources", "governance", "databricks.yml"):
            s = REPO / name
            if s.is_dir():
                _sh.copytree(s, src / name, ignore=_sh.ignore_patterns("reference", "__pycache__"))
            else:
                (src / name).parent.mkdir(parents=True, exist_ok=True)
                _sh.copy2(s, src / name)
        # The pack set the BUILD deploys, not everything `products()` discovers — the template pack
        # is shape-valid and never packaged, so seeding it would assert against a pack the tree
        # legitimately omits and this test would fail for the wrong reason.
        import bundle_products
        packs = [f"products/{f}/{s}/{v}" for s, f, v, _c in bundle_products.entries(str(src))]
        assert packs, "no packs deployed in the fixture — this test would check nothing"
        pack = packs[0]
        rel_in_pack = deploy_tree.RUNTIME_EVIDENCE[0]
        form = src / pack / rel_in_pack
        form.parent.mkdir(parents=True, exist_ok=True)
        form.write_text("approved_by: A Person\napproved_build_id: b1\n", encoding="utf-8")

        out, ev = tmp / "deploy", tmp / "evidence"
        files = deploy_tree.build(str(src), str(out), git_commit="0" * 40, evidence_out=str(ev))
        rel = f"{pack}/{rel_in_pack}"
        assert (out / rel).exists(), \
            f"{rel} is not in the runtime tree — run_rwdp.py opens it from there and would not find it"
        assert rel in files, \
            f"{rel} is in the tree but not in the deployed file list, so tree_digest does not cover it"
        assert (ev / rel).exists(), f"{rel} left the audit bundle — it must be archived as well"

        # ...and it did not drag the rest of the bundle in with it.
        doc, err = product_gates.read_yaml(str(out / deploy_tree.sm.RELEASE_EVIDENCE))
        assert not err, err
        prose = [r for r in doc["products"][pack]["audit_bundle"] if r != rel]
        assert prose, "the fixture pack has no other evidence, so the exclusion is untested"
        for other in prose:
            assert not (out / other).exists(), f"{other} entered the tree with the approval"
    finally:
        _sh.rmtree(tmp, ignore_errors=True)


def test_the_deploy_docstring_names_the_directories_the_code_refuses():
    """The docstring said all of `platform/tools` ships, months after the code stopped doing that; it
    listed `prog_spec/` twice and had lost `reference/`. Documentation nothing re-derives is the
    failure this repository keeps finding, and a module about what production may see is the worst
    place for it."""
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import deploy_tree
    doc = deploy_tree.__doc__
    stays_out = doc.split("WHAT STAYS OUT:", 1)[1].split("\n\n", 1)[0]
    for entry in deploy_tree.FORBIDDEN:
        assert entry.strip("/") in stays_out, f"FORBIDDEN carries {entry} and the docstring omits it"
    assert len(set(deploy_tree.FORBIDDEN)) == len(deploy_tree.FORBIDDEN), "duplicate FORBIDDEN entry"
    goes_in = doc.split("WHAT GOES IN", 1)[1].split("WHAT STAYS OUT", 1)[0]
    assert "runtime_tools" in goes_in, "the docstring does not say the tool set is derived"
    assert "platform/tools/<" in goes_in or "only what the entrypoints import" in goes_in, \
        "the docstring still implies every tool module is deployed"


def test_an_attribution_names_a_PERSON_and_the_rule_actually_bites():
    """"A name, not a team" was written twice in `source_refs.schema.json` and enforced NOWHERE, so
    every material in every pack recorded `classified_by: RWP`. A classification is one person's
    judgment about what AI may read; attributed to a function it is a verdict nobody can be asked
    about, and there is no way to tell a considered call from a value pasted in to make CI pass.

    The check cannot verify a person EXISTS and does not pretend to — a made-up name passes, and
    catching that is a reviewer's job. It refuses the two shapes that are demonstrably not a person.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import product_gates
    import source_manifest
    for team in ("RWP", "rwb", "GSK", "Biostats"):
        assert product_gates.not_a_person(team), team
    # ...and an acronym NOBODY DECLARED, which is the case the declared list cannot cover and the one
    # most likely to arrive next. A test using only listed names would pass with the shape check gone.
    for acronym in ("HEOR", "CDISC", "QRM"):
        assert acronym.upper() not in product_gates.NOT_A_PERSON, f"{acronym} is declared — pick another"
        assert product_gates.not_a_person(acronym), acronym
    # ...and a NAME passes, including the ones a cleverer check would break on. Narrow on purpose.
    # `J.S.` is INITIALS — a weak person reference but a real one, and the source specifications'
    # own QC columns are initialled, so refusing the dotted form would refuse their convention.
    for name in ("Onkar Kshirsagar", "Ng", "de Vries", "O'Brien", "Jean-Luc Picard", "J.S."):
        assert product_gates.not_a_person(name) is None, name
    # A blank or a placeholder is `unstated`'s finding, not this one — two messages for one defect is
    # the I9/I13 duplication this repo already fixed once.
    for blank in ("", None, "TODO", "REPLACE_ME"):
        assert product_gates.not_a_person(blank) is None, blank

    # It runs where the value actually lives: Gate 1's classification record...
    bad = {"ai_classification": "sponsor_ai_eligible", "classified_by": "RWP",
           "classified_date": "2026-07-27"}
    assert any("is a team, not a person" in e for e in source_manifest.classification_errors(bad))
    good = {**bad, "classified_by": "Onkar Kshirsagar"}
    assert source_manifest.classification_errors(good) == [], \
        source_manifest.classification_errors(good)
    # ...and the approver on the same material, which is a DIFFERENT human act and was unchecked.
    assert any("approved_by" in e for e in
               source_manifest.classification_errors({**good, "approved_by": "RWP"}))

    # ...and every shipped pack now names one.
    for rel in product_gates.products(str(REPO)):
        for m in source_manifest.materials(str(REPO / rel)) or []:
            assert product_gates.not_a_person(m.get("classified_by")) is None, \
                f"{rel}/{m.get('material_id')}: {product_gates.not_a_person(m.get('classified_by'))}"


def test_repo_hygiene_fails_closed_outside_a_git_checkout():
    """`git ls-files` failing must RAISE, never return an empty list. An empty list reports a clean
    repository, which is the one answer this may not invent — the same reason `boundary_markers`
    refuses to read a missing policy file as zero markers."""
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    with tempfile.TemporaryDirectory() as tmp:
        try:
            repo_hygiene.tracked(tmp)
            raise AssertionError("a non-checkout reported a file list")
        except repo_hygiene.NotAGitCheckout as exc:
            assert "has not been shown clean" in str(exc), exc


def test_repo_hygiene_finds_a_machine_path_in_any_tracked_text_file():
    """The scan `test_spec_pipeline` runs over generated artifacts, widened to the whole tree. Both
    take `MACHINE_PATHS` from this one module: two spellings of "what a machine path looks like" would
    agree today and diverge at the first addition, and the narrow copy is the one nobody updates."""
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    with tempfile.TemporaryDirectory() as tmp:
        # EVERY marker, and none of them written here as a literal. A test that spells the marker out
        # contains it, so the scan finds this file and the suite reports its own fixture — the same
        # self-pollution `redact_vendor_prose` hit. Deriving them also means the test cannot drift
        # from the list it is testing.
        for i, marker in enumerate(repo_hygiene.MACHINE_PATHS):
            name = f"note{i}.md"
            (Path(tmp) / name).write_text(f"built from {marker}someone/x.tsv\n", encoding="utf-8")
            # CONTAINMENT, not equality: one marker is a substring of another (a Windows profile path
            # contains the POSIX one once slashes are folded), so a correct scan reports both.
            assert (name, marker) in repo_hygiene.machine_paths_in(tmp, [name]), marker
        # CASE AND SLASH DIRECTION do not make it a different defect: the same Windows profile path
        # spelled upper-case with backslashes used to walk past a list written lower-case with forward
        # ones. Assembled rather than written out, for the reason above.
        (Path(tmp) / "mixed.md").write_text("C:" + chr(92) + "USERS" + chr(92) + "someone\n",
                                            encoding="utf-8")
        assert repo_hygiene.machine_paths_in(tmp, ["mixed.md"]), "case/slash variant not matched"
        # A standard Windows install location is NOT a machine path — three run-instruction READMEs
        # name the Git-for-Windows bash, which is identical on every machine. It IS refused in a
        # generated artifact, where any absolute path means "regenerated here".
        (Path(tmp) / "run.md").write_text('& "C:' + chr(92) + 'Program Files' + chr(92) +
                                          'Git' + chr(92) + 'bin' + chr(92) + 'bash.exe" x.sh\n',
                                          encoding="utf-8")
        assert repo_hygiene.machine_paths_in(tmp, ["run.md"]) == []
        assert repo_hygiene.machine_paths_in(
            tmp, ["run.md"], markers=repo_hygiene.MACHINE_PATHS + repo_hygiene.GENERATED_ONLY) == \
            [("run.md", repo_hygiene.GENERATED_ONLY[0])]


def test_ci_actually_runs_the_spark_suites_and_cannot_skip_them():
    """A SUITE THAT SKIPS IS NOT A SUITE THAT PASSES.

    `test_stages_spark` and `test_smoke_spark` sat in the main CI job for months under the heading
    "skip without PySpark" — which is exactly what they did, because PySpark is not in
    requirements.txt. Both printed SKIP and exited 0, so the engine's stage dataflow (reads, joins,
    windows, aggregations) had never been executed by CI. When it was finally run, two real defects
    surfaced immediately.

    So the arrangement that fixes it must itself be checked, or it regresses the same silent way:
    a job that installs PySpark, an import assertion that fails the job when the install did not
    take, and both suites invoked. Asserting on the workflow text is crude, and it is what catches
    someone deleting the install step and leaving the suites behind."""
    wf = (REPO / ".github" / "workflows" / "rwdp-ci.yml").read_text(encoding="utf-8")
    assert re.search(r"(?m)^  spark:$", wf), "no `spark` job — the suites are unrun again"

    body = wf.split("\n  spark:", 1)[1].split("\n  r-parity:", 1)[0]
    assert "pip install \"pyspark" in body or "pip install pyspark" in body, \
        "the spark job does not install PySpark, so both suites will skip and pass"
    assert "setup-java" in body, "Spark needs a JDK; without one the suites error or skip"
    assert "import pyspark" in body, \
        "nothing asserts the install took — a failed install would present as a passing job"
    for suite in ("tests/test_stages_spark.py", "tests/test_smoke_spark.py"):
        assert suite in body, f"the spark job does not run {suite}"

    # ...and they must not ALSO be INVOKED from a job with no PySpark, which is what made them
    # decorative. Matched on the invocation, not the filename: the `test` job names both suites
    # legitimately, in the exclusion list of its glob loop, and an earlier version of this check
    # tried to allow that with `or "pyspark" in job` — which any comment mentioning PySpark
    # satisfies, so the guard was defeated by prose. Twice in one session; match behaviour, not
    # vocabulary.
    for job in re.split(r"(?m)^  (?=[a-z][\w-]*:$)", wf):
        if job.startswith("spark:"):
            continue
        for suite in ("test_stages_spark", "test_smoke_spark"):
            assert not re.search(rf"python3\s+tests/{suite}\.py", job), \
                f"{suite}.py is invoked outside the spark job, where it would skip and pass"

    # The `test` job runs `for t in tests/test_*.py`, so the two suites stay out of it only because
    # its case statement skips them BY NAME. Delete that and they run there without PySpark, skip,
    # and pass — the original defect, restored by removing something rather than adding it.
    testjob = wf.split("\n  test:", 1)[1].split("\n  spark:", 1)[0]
    assert "tests/test_*.py" in testjob, "the pure-Python glob loop moved — re-read this check"
    for suite in ("test_stages_spark.py", "test_smoke_spark.py"):
        assert suite in testjob, \
            f"the pure-Python glob no longer excludes {suite}, so it runs there without PySpark"


def test_only_a_contract_that_covers_its_spec_may_say_nobody_required_it():
    """AN UNCLAIMED CONFIG BLOCK IS A FACT; "BEHAVIOUR NOBODY REQUIRED" IS A CONCLUSION.

    The second is an assertion about the WHOLE requirement set and holds only when the contract has
    read the whole specification. oc/202606 has 9 of 360 items in its contract and 299 never
    examined, and the binder reported 34 blocks as behaviour nobody required — while 295 drafted
    records for that same product sat in a sandbox it cannot see. Acting on that deletes config that
    IS required.

    So: full coverage keeps the strong sentence; incomplete coverage must say the conclusion is not
    established. Both branches are asserted, because a fix that silenced the sentence everywhere
    would lose a real check on the packs that have earned it."""
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_binding as cb

    covered, phrase = cb.spec_coverage(str(REPO / "products/oncology/prostate/202606"))
    assert covered and phrase == "", f"a fully-covered pack was reported as incomplete: {phrase!r}"

    covered, phrase = cb.spec_coverage(str(REPO / "products/oncology/oc/202606"))
    assert not covered, "oc/202606 covers 9 of 360 items but was reported as complete"
    assert "360" in phrase and "never examined" in phrase, phrase

    # ...and the message actually changes.
    from product_gates import pack_yaml
    oc = str(REPO / "products/oncology/oc/202606")
    errors, _stats = cb.check(oc, pack_yaml(oc))
    unclaimed = [e for e in errors if "claimed by no contract record" in e]
    assert unclaimed, "oc/202606 no longer has unclaimed blocks — this test would prove nothing"
    for e in unclaimed:
        assert "behaviour nobody required" not in e, \
            f"an unproven conclusion survived on a pack covering 9 of 360 items: {e[:120]}"
        assert "not established here" in e, e

    # THE OTHER DIRECTION, and it needs forcing: no pack in the repository today has BOTH full
    # coverage and an unclaimed block, so nothing exercises the strong branch and a fix that
    # silenced the sentence everywhere would pass unnoticed — which is exactly what happened when
    # this test was first written. Same pack, same blocks, only the coverage verdict substituted.
    real = cb.spec_coverage
    try:
        cb.spec_coverage = lambda _product: (True, "")
        errors, _stats = cb.check(oc, pack_yaml(oc))
    finally:
        cb.spec_coverage = real
    strong = [e for e in errors if "behaviour nobody required" in e]
    assert strong, ("with coverage complete the binder must still say a block is behaviour nobody "
                    "required — the check was silenced rather than scoped")


def test_a_record_may_not_promise_a_published_column_the_catalog_does_not_carry():
    """THE ORACLE MATTERS, AND THE OBVIOUS ONE IS WRONG.

    The first attempt compared published records against `engine.validate.emitted_variables` and
    reported 92 of 171 as unemitted. That function returns 153 codes against a built ADS of 187
    columns and its own docstring says it excludes the parallel `-n` code columns: it is a
    catalog-COMPLETENESS helper, not a column manifest, and a check built on it accuses records that
    are correct. Against `products/metadata/catalog.yaml` — the governed manifest `test_catalog`
    already holds against the engine — the real number was three, each a different defect.

    Both directions are asserted. A check that refused everything would satisfy the first half.
    """
    import shutil
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_binding as cb

    codes = cb.catalog_codes(str(PRODUCTS))
    assert codes and len(codes) > 100, f"the catalog did not load ({codes and len(codes)})"
    live = REPO / "products" / "oncology" / "prostate" / "202606"
    assert not cb.published_name_errors(str(live), str(PRODUCTS)), \
        "the shipped pack reports published-name errors — a false positive gets a check switched off"

    # The `-n` parallel columns must stay exempt. RACEN/PRACTICN/COHORTN/COHORTUN are published,
    # implemented and name_status:aligned, and the catalog documents each through its LABEL
    # (race/practic/cohort/cohortu) — dropping the rule reports four correct records.
    for code in ("race", "practic", "cohort", "cohortu"):
        assert code in codes, f"{code} left the catalog — the parallel-column assertion is vacuous"
        assert code + cb.CODE_COLUMN_SUFFIX not in codes, \
            f"{code}n is now catalogued directly, so it no longer proves the parallel rule"

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "products"
        shutil.copytree(str(PRODUCTS), str(root), symlinks=True)
        dst = root / "oncology" / "prostate" / "202606"
        c = dst / "handoff" / "FUNCTIONAL_CONTRACT.md"
        text = c.read_text(encoding="utf-8")

        # AGE is published, implemented and aligned on `age`, which the catalog carries. Rename only
        # the physical_name: same record, same status, a column nobody receives.
        row = next(l for l in text.splitlines() if l.startswith("| AGE |"))
        assert "physical_name: age," in row, "the AGE record no longer names `age` — fixture is stale"
        c.write_text(text.replace(row, row.replace("physical_name: age,", "physical_name: aeg,")),
                     encoding="utf-8")
        errs = cb.published_name_errors(str(dst), str(root))
        assert any("[AGE]" in e and "aeg" in e for e in errs), \
            f"a published+implemented+aligned record naming a column nobody ships passed: {errs}"

        # ...and each exemption is the record's OWN honest statement, so each must clear it alone.
        for was, now in (("name_status: aligned", "name_status: undecided"),
                         ("role: published", "role: internal"),
                         ("implementation: implemented", "implementation: engine_gap")):
            bad = next(l for l in c.read_text(encoding="utf-8").splitlines()
                       if l.startswith("| AGE |"))
            assert was in bad, (was, bad[:120])
            c.write_text(c.read_text(encoding="utf-8").replace(bad, bad.replace(was, now)),
                         encoding="utf-8")
            assert not [e for e in cb.published_name_errors(str(dst), str(root)) if "[AGE]" in e], \
                f"{now} did not clear the finding — the exemption is not the record's own statement"
            c.write_text(c.read_text(encoding="utf-8").replace(bad.replace(was, now), bad),
                         encoding="utf-8")

        # ...and an OPEN decision naming the variable accounts for it, exactly as one accounts for an
        # unclaimed config block. Backticked, so an ordinary word in a question cannot exempt anything.
        d = dst / "handoff" / "DECISIONS.md"
        rows = d.read_text(encoding="utf-8")
        last = [l for l in rows.splitlines() if l.startswith("| ") and not l.startswith("| ID")
                and not l.startswith("|---")][-1]
        d.write_text(rows.replace(last, last + "\n| AEG-NAME | Is `AGE` right? | n/a | RWP | — | OPEN |"),
                     encoding="utf-8")
        assert not [e for e in cb.published_name_errors(str(dst), str(root)) if "[AGE]" in e], \
            "an OPEN decision naming the variable did not account for it"
        d.write_text(d.read_text(encoding="utf-8").replace("| OPEN |", "| RESOLVED |"))
        assert any("[AGE]" in e for e in cb.published_name_errors(str(dst), str(root))), \
            "answering the decision did not bring the finding back — the accounting is one-way"

    # FAIL-CLOSED: an unreadable catalog reports that it could not look, never a clean pass.
    with tempfile.TemporaryDirectory() as tmp:
        assert cb.catalog_codes(tmp) is None, "a missing catalog returned a code set"
        out = cb.published_name_errors(str(live), tmp)
        assert out and "unchecked, not passing" in out[0], out


def test_the_published_name_check_is_scoped_to_THIS_products_vocabulary():
    """THE CATALOG IS CROSS-TUMOUR AND SAYS SO PER ENTRY.

    30 codes are `applies_to: all`; 91 are `['mcrpc']`, 24 `['oc']`, 19 `['ec']`. The first version
    of this check asked only whether a code existed ANYWHERE, so an ovarian-only entry would have
    satisfied a prostate record's published name. It never fired wrongly on the shipped packs, which
    is exactly how that stays invisible — so it is asserted here with a forced case.

    Also: EVERY name in a compound `physical_name`, not any. `any` let one catalogued sibling carry
    an uncatalogued one through, and `physical_name` is compound on real records (ELIGPFS emits
    "eligpfs / lastclinicnotedate").
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_binding as cb
    from engine.dictionary import _applies

    codes = cb.catalog_codes(str(PRODUCTS))
    assert codes, "the catalog did not load"
    # The predicate is the ONE the dictionary and test_catalog already use, not a second copy.
    assert cb.published_name_errors.__module__ == "contract_binding"
    assert _applies is not None

    oc_only = [c for c, e in codes.items()
               if isinstance(e.get("applies_to"), list) and "oc" in e["applies_to"]
               and "mcrpc" not in e["applies_to"]]
    assert oc_only, "no ovarian-only catalog code — this test would prove nothing"
    assert cb.tumour_code(str(REPO / "products/oncology/prostate/202606")) == "mcrpc"

    # An mcrpc pack must NOT be satisfied by an oc-only code...
    e = codes[oc_only[0]]
    assert not _applies(e, "mcrpc"), f"{oc_only[0]} applies to mcrpc after all"
    assert _applies(e, "oc"), f"{oc_only[0]} does not apply to oc — fixture is wrong"
    # ...and an `all` code satisfies both.
    every = [c for c, x in codes.items() if x.get("applies_to") == "all"]
    assert every, "no applies_to: all code — this test would prove nothing"
    assert _applies(codes[every[0]], "mcrpc") and _applies(codes[every[0]], "oc")

    # THE CHECK MUST ACTUALLY APPLY IT. Asserting `_applies` works proves the predicate, not the
    # call — and the first version of this test passed with `applies_to` ignored entirely. So: give a
    # prostate record an ovarian-only published name and require the check to report it.
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "products"
        shutil.copytree(str(PRODUCTS), str(root), symlinks=True)
        dst = root / "oncology" / "prostate" / "202606"
        c = dst / "handoff" / "FUNCTIONAL_CONTRACT.md"
        text = c.read_text(encoding="utf-8")
        row = next(l for l in text.splitlines() if l.startswith("| AGE |"))
        assert "physical_name: age," in row, "the AGE record no longer names `age` — fixture is stale"
        c.write_text(text.replace(row, row.replace("physical_name: age,",
                                                   f"physical_name: {oc_only[0]},")), encoding="utf-8")
        errs = cb.published_name_errors(str(dst), str(root))
        assert any("[AGE]" in e and oc_only[0] in e for e in errs), (
            f"an mcrpc record published under the ovarian-only code {oc_only[0]!r} passed — the "
            f"check is not applying the catalog's per-tumour applies_to: {errs}")

        # EVERY name in a compound `physical_name`. No shipped record reaches this check with one
        # (they sit in other role/status combinations), so `any` vs `all` is unobservable without a
        # forced case — and unobservable is how it survived the first version.
        c.write_text(text.replace(row, row.replace("physical_name: age,",
                                                   "physical_name: age / notacode,")),
                     encoding="utf-8")
        errs = cb.published_name_errors(str(dst), str(root))
        assert any("[AGE]" in e and "notacode" in e for e in errs), (
            f"a compound published name passed because ONE of its names is catalogued — an "
            f"uncatalogued sibling rode through: {errs}")

    # FAIL-CLOSED on an unresolvable tumour: a pack with no registry entry is unchecked, not passing.
    with tempfile.TemporaryDirectory() as tmp:
        fake = Path(tmp) / "products" / "oncology" / "nosuch" / "202606"
        (fake / "handoff").mkdir(parents=True)
        (fake / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text("# none\n", encoding="utf-8")
        out = cb.published_name_errors(str(fake), str(PRODUCTS))
        assert out and "unchecked, not passing" in out[0], out


def test_the_public_views_cannot_move_without_a_named_approval_of_THIS_build():
    """GATE 6 WAS DOCUMENTED AND NOT IMPLEMENTED.

    `WORKFLOW.md` requires a named final approval before release. The runner confirmed Gates 1-4 via
    `releasable()`, built, ran QC, swapped the public views — and sign-off was promoted to the ledger
    AFTERWARDS. Production credentials plus a technically clean run moved the public product with no
    accountable person having looked at it.

    `releasable()` cannot fix this and should not try: it answers "may this PACK publish" from
    artifacts that sit still. A release approves a CUT — these patients, these counts, this QC result
    — so the approval has to name the BUILD, and the build does not exist until the run has run.
    """
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_manifest as sm

    rel = "products/oncology/prostate/202606"
    good = ('approved_by: A Person\napproval_date: "2026-08-07"\n'
            'validated_by: B Person\nvalidation_date: "2026-08-06"\n'
            'approved_build_id: b123\napproved_manifest_sha256: deadbeef\n')

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / "r"
        (root / rel / "handoff").mkdir(parents=True)
        form = root / rel / "handoff" / "RELEASE_APPROVAL.yaml"

        # No form at all -> refused, naming the file.
        errs = sm.publish_approval_errors(str(root), rel, "b123", "deadbeef")
        assert errs and "RELEASE_APPROVAL" in errs[0], errs

        # Placeholders in every human field -> refused. An unfilled form is not an approval.
        form.write_text("\n".join(f"{f}: TODO" for f in sm.RELEASE_APPROVAL_FIELDS), encoding="utf-8")
        assert len(sm.publish_approval_errors(str(root), rel, "b123", "deadbeef")) >= 4

        # A VALID approval of a DIFFERENT build -> refused. This is the one that matters: an approval
        # naming only the product would keep authorising every later refresh.
        form.write_text(good.replace("b123", "SOME_OTHER_BUILD"), encoding="utf-8")
        errs = sm.publish_approval_errors(str(root), rel, "b123", "deadbeef")
        assert any("DIFFERENT" in e for e in errs), errs

        # ...and of a different MANIFEST — same build id, different output.
        form.write_text(good.replace("deadbeef", "0000"), encoding="utf-8")
        assert any("approved_manifest_sha256" in e for e in
                   sm.publish_approval_errors(str(root), rel, "b123", "deadbeef"))

        # The matching approval passes.
        form.write_text(good, encoding="utf-8")
        assert sm.publish_approval_errors(str(root), rel, "b123", "deadbeef") == []

        # ...and a runner that supplies no build id cannot satisfy it by omission.
        assert sm.publish_approval_errors(str(root), rel, None, "deadbeef")

    # ONE-WAY: Gate 6 cannot rescue a pack failing Gates 1-4. prostate/202606 fails them today, so a
    # perfect approval must still not make it publishable.
    ok, why = sm.publishable(str(REPO), rel, "b123", "deadbeef")
    assert not ok and any("Gate 1" in w for w in why), why

    # THE RUNNER MUST ACTUALLY ASK. The whole defect was a documented gate nothing called.
    runner = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    assert "publish_approval_errors(" in runner, "the runner does not ask — Gate 6 is documentation"
    swap = runner.index("Ledger written -> PUBLISH")
    assert runner.index("publish_approval_errors(") < swap, \
        "the Gate 6 check runs AFTER the release phase begins — it must gate the swap, not follow it"

    # ...and it must NOT re-derive Gates 1-4 live. In prod that verdict comes from
    # RELEASE_EVIDENCE.yaml because the allowlisted tree deliberately omits the Gate 1 material a
    # live evaluation needs; calling `releasable()` here could never pass in production, which is a
    # gate that blocks for a reason unrelated to approval.
    # NON-COMMENT lines only. The block EXPLAINS why it must not call `releasable()`, so a substring
    # search flags the explanation — the same prose-defeats-check shape this repo has hit twice.
    gate6 = [l.split("#")[0] for l in runner[runner.index("GATE 6 — THE NAMED APPROVAL"):swap]
             .splitlines() if not l.strip().startswith("#")]
    assert not any("releasable(" in l for l in gate6), \
        "the Gate 6 block re-derives Gates 1-4 live; in prod that fails because the evidence is " \
        "outside the deployed tree by design"

    # The manifest status it writes must be one the ledger accepts. An invented state fails
    # `validate_manifest`, and a ledger entry that will not validate is not a ledger entry.
    sys.path.insert(0, str(REPO / "platform"))
    from engine.refresh import STATUSES
    for bad in ("awaiting_release_approval", "pending_approval"):
        assert f'"status"] = "{bad}"' not in runner and f"status: {bad}\n" not in runner, \
            f"the runner writes manifest status {bad!r}, which is not in {STATUSES}"

    # ...and the approval must reach the audit bundle, or the record of who released a cut is the
    # one approval the bundle does not carry.
    import deploy_tree
    assert any("RELEASE_APPROVAL" in e for e in deploy_tree.PACK_EVIDENCE), \
        "RELEASE_APPROVAL.yaml is not in PACK_EVIDENCE — Gate 6's approval is not archived"

    # ...and it ships. `deploy_tree` derives the runtime tool set from what the runner imports; a
    # check the deployed tree cannot import is a check production does not have.
    import deploy_tree
    assert "source_manifest" in deploy_tree.runtime_tools(str(REPO)), \
        "source_manifest is not deployed, so the runner cannot call publishable in production"


def test_the_approved_digest_and_the_persisted_candidate_are_the_same_bytes():
    """AN APPROVAL BINDS TO BYTES, SO THE BYTES MUST NOT BE EDITED AFTER THEY ARE HASHED.

    Gate 6 prints a `candidate manifest sha256` and tells a person to copy it into
    `approved_manifest_sha256`. That value is only worth anything if the artifact they can open —
    `<artifact_root>/manifest.yaml` — reproduces it, and if the promotion step that verifies the
    approval hashes that same file.

    The first version of the block broke this quietly. It hashed the manifest, printed the digest,
    then added a `release_approval` block to the dict and PUT `manifest.yaml` again. The file on disk
    hashed to something else. Nothing failed: the approver signs the printed value, and the promotion
    step — which does not exist yet, so nobody found out — would have rejected the exact build the
    approval named. A binding whose subject is rewritten after the hash binds nothing, and it is
    indistinguishable from a working one until the day it matters.

    Checked through `ast`, NOT substring search. The block now EXPLAINS this failure in a comment
    naming `manifest.yaml` and `release_approval`, so a text scan is satisfied by the description of
    the bug — the prose-defeats-check shape this repo has already hit three times.
    """
    src = (REPO / "platform" / "databricks" / "run_rwdp.py").read_text(encoding="utf-8")
    tree = ast.parse(src)

    # THE CANDIDATE REGION: from where the candidate manifest is BUILT to where the release phase
    # begins. Scoping matters — the notebook writes `manifest.yaml` on several other paths (preflight
    # failure, source-QC refusal, the QC-gate-failed evidence dump, the post-swap `published_at`
    # stamp) and none of those is the subject of a Gate 6 approval. An unscoped sweep would flag the
    # legitimate ones and this test would have to be weakened to pass, which is how a check ends up
    # asserting nothing.
    cand_lo = [n.lineno for n in ast.walk(tree)
               if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == "manifest" for t in n.targets)
               and isinstance(n.value, ast.Call) and getattr(n.value.func, "id", "") == "build_manifest"]
    assert len(cand_lo) == 1, \
        f"expected exactly one `manifest = build_manifest(...)` candidate build, found {len(cand_lo)}"
    lo, cand_lo = cand_lo[0], cand_lo[0]
    hi = src[:src.index("Ledger written -> PUBLISH")].count("\n") + 1
    in_scope = lambda n: cand_lo <= getattr(n, "lineno", 0) <= hi   # noqa: E731

    # 1. WHAT WAS HASHED — the name inside `_manifest_sha = sha256(<name>.encode(...)).hexdigest()`.
    hashed = set()
    for node in ast.walk(tree):
        if (isinstance(node, ast.Assign) and in_scope(node)
                and any(isinstance(t, ast.Name) and t.id == "_manifest_sha" for t in node.targets)):
            hashed |= {sub.value.id for sub in ast.walk(node.value)
                       if isinstance(sub, ast.Attribute) and sub.attr == "encode"
                       and isinstance(sub.value, ast.Name)}
    assert len(hashed) == 1, \
        f"the candidate digest is not taken over one named string ({hashed or 'no _manifest_sha'}) — " \
        "an inline re-serialization is a second subject free to differ from the one persisted"

    # 2. WHAT WAS WRITTEN as manifest.yaml in that region — the value paired with that filename.
    written = set()
    for node in ast.walk(tree):
        if (isinstance(node, ast.Tuple) and in_scope(node) and len(node.elts) == 2
                and isinstance(node.elts[0], ast.Constant) and node.elts[0].value == "manifest.yaml"):
            body = node.elts[1]
            written.add(body.id if isinstance(body, ast.Name) else ast.dump(body))
    assert written == hashed, \
        f"manifest.yaml is written from {written} but the approval digest is taken over {hashed} — " \
        "the approver is told to sign a value the artifact does not reproduce"

    # 3. ...AND THE GATE 6 BLOCK MUST NOT REWRITE IT. Recording the stop is fine; recording it INTO
    #    the hashed subject is the defect. The block writes a sibling file instead.
    lo = src[:src.index("GATE 6 — THE NAMED APPROVAL")].count("\n") + 1
    for node in ast.walk(tree):
        if not lo <= getattr(node, "lineno", 0) <= hi:
            continue
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == "put" and node.args):
            assert "manifest.yaml" not in ast.dump(node.args[0]), \
                f"line {node.lineno}: Gate 6 rewrites manifest.yaml after hashing it"
        if isinstance(node, ast.Assign):
            assert not any(isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name)
                           and t.value.id == "manifest" for t in node.targets), \
                f"line {node.lineno}: Gate 6 mutates `manifest` after its digest was taken and printed"


def test_the_source_preflight_emits_real_names_and_refuses_placeholders():
    """THE PREFLIGHT SQL IS THE CHEAPEST FAILURE TO HIT, SO IT MUST NOT BE HAND-SUBSTITUTED.

    `DEV_SMOKE.md` carries the right questions with `<source_schema>` and `<refresh>` in every one.
    `source_preflight` resolves them from the pack's own config — through `cfg.source_fqns`, never a
    `{stem}_{refresh}` format string, because `run.source_layout` is a documented per-product
    override.

    Two properties, and the second is why this test exists at all: the tool prints a COLUMN name for
    the LOT setting, and the config holds only the VALUE. The first version printed
    `SELECT DISTINCT mCRPC` — the value read as though it were the column — which is a query that
    fails in a way that looks like a finding about the delivery.
    """
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import source_preflight as sp

    pack = str(REPO / "products" / "oncology" / "prostate" / "202606")
    out = sp.render(pack, "2026m06", "cat.sch")

    # Resolved names, not placeholders.
    assert "<source_schema>" not in out and "<refresh>" not in out, "a placeholder survived"
    assert "REPLACE_ME" not in out, "a runtime binding leaked into the SQL"
    assert "cat.sch.t_enh_prostate_lot_2026m06" in out, out[:400]

    # The LOT setting COLUMN, never the value.
    assert f"SELECT DISTINCT {sp.LOT_SETTING_COLUMN} FROM" in out, out
    import yaml as _y
    cfgraw = _y.safe_load((Path(pack) / "config" / "data_product.yaml").read_text(encoding="utf-8"))
    value = (cfgraw.get("lot") or {}).get("line_setting")
    assert value, "the pack no longer declares lot.line_setting — this test would prove nothing"
    assert f"SELECT DISTINCT {value} FROM" not in out, \
        f"the config VALUE {value!r} is being emitted as a column name"

    # ...and that column is still what the engine filters on. The tool names it as a literal because
    # the engine does; if the engine renames it, this fails rather than the SQL silently going wrong.
    engine_src = (REPO / "platform" / "engine" / "stages" / "treatment.py").read_text(encoding="utf-8")
    assert f'"{sp.LOT_SETTING_COLUMN}"' in engine_src, \
        f"the engine no longer references {sp.LOT_SETTING_COLUMN!r} — the preflight SQL is now wrong"

    # FAIL-CLOSED: with the pack's own placeholders and no override, it REFUSES rather than emitting
    # a query against a schema called REPLACE_ME.
    try:
        sp.render(pack, None, None)
    except SystemExit as exc:
        assert "REFUSING" in str(exc), exc
    else:
        raise AssertionError("emitted SQL from unfilled runtime bindings")

    # THE PACK PASSED IS THE PACK READ. This resolved through `product_config(root, slug)`, which
    # returns the registry's CURRENT spec version — so asking for 202603 emitted 202606's source
    # list, and 202607 (which has no config/ at all) produced a full preflight from another pack's
    # config with nothing to say it had. 202603 declares 16 sources and 202606 declares 20, so the
    # two are distinguishable and this assertion is not vacuous.
    older = str(REPO / "products" / "oncology" / "prostate" / "202603")
    if os.path.exists(os.path.join(older, "config", "data_product.yaml")):
        a = sp.render(older, "2026m06", "cat.sch")
        b = sp.render(pack, "2026m06", "cat.sch")
        n_a = len([l for l in a.splitlines() if "DESCRIBE TABLE" in l])
        n_b = len([l for l in b.splitlines() if "DESCRIBE TABLE" in l])
        assert n_a and n_b, (n_a, n_b)
        assert n_a != n_b, (
            f"202603 and 202606 emitted the same {n_a} tables — the pack argument is being "
            f"re-resolved through the registry instead of read directly")

    # ...and a pack with no config REFUSES rather than answering from a neighbour.
    #
    # The subject is prostate/202607, PARKED at platform/tests/fixtures/ — every product now has a
    # config, so the live tree no longer holds this case. It was reached by path, guarded by "if the
    # config is absent", and when the pack moved the guard turned the whole case into a silent skip:
    # a refusal test that stopped exercising the refusal. Asserted, not guarded.
    nocfg = str(FRAMEWORK / "tests" / "fixtures" / "prostate_202607")
    assert os.path.isdir(nocfg) and not os.path.exists(os.path.join(nocfg, "config")), \
        f"{nocfg} is not a no-config pack — this case needs one"
    try:
        sp.render(nocfg, "2026m06", "cat.sch")
    except SystemExit as exc:
        assert "no config" in str(exc), exc
    else:
        raise AssertionError("a pack with no config/ produced a preflight")


def test_revising_a_record_keeps_the_status_that_record_already_holds():
    """A REVISION MUST NOT SILENTLY DOWNGRADE A HUMAN'S EVIDENCE CLAIM.

    `contract_record.main` looked the existing record up with `cl.records(<path>)` — and `records`
    takes the TEXT. It parsed a filename as a contract, yielded nothing, and `existing` was None for
    every record that has ever existed, so every revision got `INITIAL_STATUS` instead. Revising a
    record at `requirement: approved, implementation: implemented` rewrote it to `draft` /
    `not_implemented`: the tool that refuses a drafter's status because "moving it is an evidence
    transition an accountable person makes" was moving it itself, downward, on every revision.

    It hid behind a second bug — `records()` yields block TEXT, so the `r.get(...)` on the next line
    would have raised AttributeError, but the generator was empty so it never ran. The existing
    revision test asserts rc == 0 and no duplication, so it passed against both.
    """
    import subprocess
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_lint as cl
    import contract_scaffold as cs
    import yaml as _y

    live = REPO / "products" / "oncology" / "prostate" / "202606"
    contract = live / "handoff" / "FUNCTIONAL_CONTRACT.md"
    block = next(b for b in cl.records(cl.read(str(contract)))
                 if (cl._scalar(b, "variable_id") or "").strip() == "AGE")
    held = cl._inline(block, "status")
    assert "implementation: implemented" in held, f"AGE is no longer implemented: {held}"

    rec = {}
    for line in block.splitlines():
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        if k.strip() in cs.MACHINE_OWNED or k.strip() == "status":
            continue
        rec[k.strip()] = v.strip()
    with tempfile.TemporaryDirectory() as tmp:
        draft = Path(tmp) / "d.yaml"
        draft.write_text(_y.safe_dump(rec, sort_keys=False, width=10 ** 6, allow_unicode=True),
                         encoding="utf-8")
        r = subprocess.run([sys.executable, str(REPO / "platform/tools/contract_record.py"),
                            str(draft), "--product", str(live), "--item", "demographics:9"],
                           capture_output=True, text=True, cwd=str(REPO))
        assert r.returncode == 0, r.stdout + r.stderr
        row = next(l for l in r.stdout.splitlines() if l.startswith("| AGE |"))
    assert "implementation: implemented" in row, \
        f"the revision downgraded a status the record holds:\n{row[:400]}"


def test_a_config_block_the_engine_never_reads_is_refused():
    """RENAMING A BLOCK IN THE CONFIG *AND* IN THE RECORD SATISFIED EVERYTHING.

    `age_bands` -> `age_bandz` in `variables/demographics.yaml` and in the `implementation_refs` that
    claims it, on a copy of prostate/202606: `contract_binding --check` 0 issues (the record names a
    block that exists; the block is claimed by a record), `validate.check` PASSED, `finalize --check`
    "every stated summary matches the evidence" — and `emitted_variables` went 153 -> 151, because
    AGEGR1 and AGEGR1N are produced by an engine that reads `age_bands` and nothing else. A
    config-only edit deleted two published variables with every gate in the repository green.

    The binder checked that a name resolves between the CONTRACT and the CONFIG. Nothing checked the
    third side — that the ENGINE is listening for it — which is precisely the side that matters once
    the framework's promise is "edit the spec, not the code".

    Built on a COPY; the real tree is asserted byte-identical afterwards.
    """
    import hashlib
    import shutil
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_binding as cb
    from product_gates import pack_yaml

    live = REPO / "products" / "oncology" / "prostate" / "202606"
    before = hashlib.sha256((live / "variables" / "demographics.yaml").read_bytes()).hexdigest()

    # The derivation must be COMPLETE on the real packs, or the check is unusable noise. Its first
    # version regex-scanned for string constants and reported `biomarkers` and `labs` — read through
    # `for blk in ("biomarkers", "labs")` — as blocks nothing reads, on three shipped packs.
    reads = cb.engine_config_keys()
    assert reads is not None, "the engine could not be located — this test would prove nothing"
    assert {"biomarkers", "labs"} <= reads["clinical"], \
        "keys read through a loop variable are missed again; the check would fire on real packs"
    import product_gates
    assert product_gates.products(str(REPO)), "no packs discovered — this sweep would be vacuous"
    for pack in sorted(product_gates.products(str(REPO))):
        assert not cb.unread_config_blocks(pack), \
            f"{pack} reports blocks the engine never reads — a false positive gets a check switched off"
    assert cb.PACK_META, "PACK_META is empty, so metadata keys would be reported as unread"

    with tempfile.TemporaryDirectory() as tmp:
        dst = Path(tmp) / "202606"
        shutil.copytree(str(live), str(dst))
        y = dst / "variables" / "demographics.yaml"
        text = y.read_text(encoding="utf-8")
        assert "\nage_bands:" in text, "the fixture block is gone — this test would prove nothing"
        y.write_text(text.replace("\nage_bands:", "\nage_bandz:", 1), encoding="utf-8")
        c = dst / "handoff" / "FUNCTIONAL_CONTRACT.md"
        c.write_text(c.read_text(encoding="utf-8").replace(
            "demographics.yaml#/age_bands", "demographics.yaml#/age_bandz"), encoding="utf-8")

        found = cb.unread_config_blocks(str(dst))
        assert any(k == "age_bandz" for _f, _r, k, _w in found), \
            f"a renamed block the engine never reads was not reported: {found}"
        errors, _stats = cb.check(str(dst), pack_yaml(str(dst)))
        assert any("age_bandz" in e and "never reads" in e for e in errors), \
            "unread_config_blocks found it but `check` did not surface it — the wiring is missing"

        # ...and a variables/ file that cannot be PARSED is reported, not skipped. The first version
        # unpacked `read_yaml`'s (doc, error) tuple into one name, so `isinstance(doc, dict)` was
        # False everywhere and it returned [] — a clean result over nothing examined, inside the
        # check written to catch exactly that.
        (dst / "variables" / "outcomes.yaml").write_text("- a\n- b\n", encoding="utf-8")
        assert any(f.endswith("outcomes.yaml") and k is None
                   for f, _r, k, _w in cb.unread_config_blocks(str(dst))), \
            "an unreadable variables file was skipped rather than reported"

    assert hashlib.sha256((live / "variables" / "demographics.yaml").read_bytes()).hexdigest() \
        == before, "the test mutated the real pack"


def test_the_coverage_used_for_that_comes_from_the_producer():
    """Never from the rendered COVERAGE.md — the reason finalize gives at length. And FAIL-CLOSED:
    a pack whose extraction cannot be read must report "cannot prove", not "covered"."""
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import contract_binding as cb
    src = (REPO / "platform" / "tools" / "contract_binding.py").read_text(encoding="utf-8")
    assert "coverage_report" in src, "the binder no longer asks the coverage producer"
    # Look for a READ, not a mention: the docstring explains at length why the rendered table is not
    # parsed, so a substring search over the source flags the explanation itself. Only string
    # constants that are NOT docstrings can name a file the code actually opens.
    tree = ast.parse(src)
    docstrings = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            d = ast.get_docstring(node, clean=False)
            if d:
                docstrings.add(d)
    literals = [n.value for n in ast.walk(tree)
                if isinstance(n, ast.Constant) and isinstance(n.value, str)
                and n.value not in docstrings]
    assert not [s for s in literals if "COVERAGE.md" in s], \
        "the binder names COVERAGE.md in code — it must read the producer, not the rendered table"
    with tempfile.TemporaryDirectory() as tmp:
        covered, phrase = cb.spec_coverage(tmp)
        assert not covered and "unknown" in phrase, \
            f"a pack with no extraction was treated as covered: {phrase!r}"


def test_the_glossary_points_at_things_that_exist():
    """A GLOSSARY IS PROSE, AND PROSE IS WHAT GOES STALE.

    `GLOSSARY.md` deliberately defines words and NOT rules — where a term has an authoritative
    definition in code it names the owner instead of restating it, so the two cannot disagree. That
    only holds while the owners it names are real. A prose claim that nothing re-derives is a claim
    that goes stale silently.

    So: every `module.function` and every path the glossary cites must resolve. Renaming a shared
    definition now fails here rather than leaving a newcomer reading a pointer to nothing."""
    glossary = REPO / "GLOSSARY.md"
    if not glossary.exists():
        return
    text = glossary.read_text(encoding="utf-8")
    sys.path.insert(0, str(REPO / "platform" / "tools"))

    # `module.member` inside backticks, for the modules that actually live in platform/tools.
    # A bare FILENAME has the same shape — `demo.py` parses as module `demo`, member `py` — so the
    # file extensions are excluded rather than the match being narrowed, which would also drop
    # legitimate single-letter members.
    SUFFIXES = {"py", "md", "yaml", "yml", "json", "r", "sh", "txt", "tsv", "csv", "xlsx", "conf"}
    owners = set(re.findall(r"`([a-z_]+)\.([A-Za-z_][A-Za-z0-9_]*)`", text))
    tools = {p.stem for p in (REPO / "platform" / "tools").glob("*.py")}
    checked = 0
    for mod, member in sorted(owners):
        if mod not in tools or member.lower() in SUFFIXES:
            continue
        checked += 1
        m = __import__(mod)
        assert hasattr(m, member), \
            f"GLOSSARY.md cites `{mod}.{member}`, which no longer exists"
    assert checked >= 5, f"only {checked} code owners checked — the extraction stopped working"

    # Repo-relative paths in backticks (files and directories alike).
    paths = set(re.findall(r"`((?:platform|products|governance|handoff)[\w./<>-]*)`", text))
    for rel in sorted(paths):
        if any(ch in rel for ch in "<>"):        # `<pack>` style placeholders
            continue
        if rel.startswith("handoff/"):           # relative to a pack, checked against the reference one
            rel = f"products/oncology/prostate/202606/{rel}"
        assert (REPO / rel).exists(), f"GLOSSARY.md cites `{rel}`, which does not exist"


def _git_repo(tmp, *files):
    """A throwaway checkout with one commit per file. Returns the path."""
    import subprocess
    run = lambda *a: subprocess.run(["git", "-C", tmp] + list(a), check=True, capture_output=True)
    subprocess.run(["git", "init", "-q", "-b", "main", tmp], check=True, capture_output=True)
    run("config", "user.email", "t@example.invalid")
    run("config", "user.name", "t")
    for name in files:
        p = Path(tmp) / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"x")
        run("add", "-A")
        run("commit", "-qm", f"add {name}")
    return tmp


def test_repo_hygiene_history_finds_what_deleting_from_the_tree_left_behind():
    """THE POINT OF THE MODE, and the one that must bite.

    A document committed and then deleted is absent from the index and present in every clone. This
    repository shipped in exactly that state: the vendor PDFs were removed from the tree, the index
    check went green, and 450 MB of them stayed reachable from every ref. `errors` reports clean here
    — correctly, it is a different question — and `history_errors` must not."""
    import subprocess, tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    with tempfile.TemporaryDirectory() as tmp:
        _git_repo(tmp, "keep.md")
        (Path(tmp) / "vendor").mkdir()
        (Path(tmp) / "vendor" / "dict.pdf").write_bytes(b"a vendor document")
        subprocess.run(["git", "-C", tmp, "add", "-A"], check=True, capture_output=True)
        subprocess.run(["git", "-C", tmp, "commit", "-qm", "add doc"], check=True, capture_output=True)
        subprocess.run(["git", "-C", tmp, "rm", "-q", "vendor/dict.pdf"], check=True,
                       capture_output=True)
        subprocess.run(["git", "-C", tmp, "commit", "-qm", "remove it"], check=True,
                       capture_output=True)
        assert repo_hygiene.restricted_files(tmp) == [], "the index still holds it — fixture is wrong"
        found = repo_hygiene.history_errors(tmp)
        assert any("vendor/dict.pdf" in f for f in found), \
            f"a deleted document was not found in history: {found}"
        assert any("did not remove it from the repository" in f for f in found), found


def test_repo_hygiene_history_sees_a_document_git_deduplicated_against_a_permitted_file():
    """`rev-list --objects` prints each OBJECT once, and git stores one blob per unique content — so
    a document whose bytes coincide with a permitted file is named by that file's path and the
    document's own path never appears. The first fixture written for the mode hit this by accident
    (two files, both `b"x"`) and the scan came back empty against a repository that held a `.pdf`.

    It is not a fixture artifact: an empty placeholder, a one-line stub or two copies of the same
    delivered document collide exactly this way. `history_paths` unions the object walk with
    `log --name-only`, which has no content-dedupe blind spot."""
    import subprocess, tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    with tempfile.TemporaryDirectory() as tmp:
        _git_repo(tmp)                                   # identical bytes in both, deliberately
        for name in ("keep.md", "vendor/dict.pdf"):
            p = Path(tmp) / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b"same")
        subprocess.run(["git", "-C", tmp, "add", "-A"], check=True, capture_output=True)
        subprocess.run(["git", "-C", tmp, "commit", "-qm", "both"], check=True, capture_output=True)
        blobs = subprocess.run(["git", "-C", tmp, "rev-list", "--objects", "--all"],
                               capture_output=True, check=True).stdout.decode()
        assert "vendor/dict.pdf" not in blobs, \
            "git did not deduplicate — this fixture no longer exercises the blind spot"
        assert any("vendor/dict.pdf" in f for f in repo_hygiene.history_errors(tmp)), \
            "a deduplicated document was invisible to the history scan"


def test_repo_hygiene_history_refuses_a_shallow_clone_rather_than_reporting_it_clean():
    """`actions/checkout@v4` clones at `fetch-depth: 1` BY DEFAULT, and this checkout was itself
    shallow when the mode was written — the first run refused instead of printing a green line over a
    sliver of history. Truncated history examined and pronounced clean is the absence-as-clean-result
    failure this codebase keeps reproducing."""
    import subprocess, tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    with tempfile.TemporaryDirectory() as tmp:
        src = _git_repo(str(Path(tmp) / "src"), "a.md", "b.md")
        (Path(src) / "vendor").mkdir()
        (Path(src) / "vendor" / "dict.pdf").write_bytes(b"a vendor document")
        subprocess.run(["git", "-C", src, "add", "-A"], check=True, capture_output=True)
        subprocess.run(["git", "-C", src, "commit", "-qm", "doc"], check=True,
                       capture_output=True)
        dst = str(Path(tmp) / "shallow")
        subprocess.run(["git", "clone", "-q", "--depth", "1", f"file://{src}", dst],
                       check=True, capture_output=True)
        assert repo_hygiene.is_shallow(dst), "fixture is not shallow"
        try:
            repo_hygiene.history_paths(dst)
            raise AssertionError("a shallow clone was scanned and reported on")
        except repo_hygiene.NotAGitCheckout as exc:
            assert "SHALLOW" in str(exc) and "fetch-depth" in str(exc), exc
        # ...and the full clone of the same repository does find it, so the refusal above is the
        # shallowness and not the fixture having nothing in it.
        full = str(Path(tmp) / "full")
        subprocess.run(["git", "clone", "-q", f"file://{src}", full], check=True, capture_output=True)
        assert any("vendor/dict.pdf" in f for f in repo_hygiene.history_errors(full))


def test_repo_hygiene_history_refuses_a_bare_repo_rather_than_inventing_a_finding():
    """A bare mirror has no working tree, so `_registered` finds no source_refs.yaml and the
    spreadsheet allowlist comes back empty — which reports the REGISTERED ovarian program-spec
    workbook as "a spreadsheet that no pack registers". That is not fail-closed, it is a false
    finding, and false findings are how a check gets switched off. Found by running --history
    against a mirror clone while verifying the history purge."""
    import subprocess, tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    with tempfile.TemporaryDirectory() as tmp:
        src = _git_repo(str(Path(tmp) / "src"), "keep.md")
        bare = str(Path(tmp) / "m.git")
        subprocess.run(["git", "clone", "-q", "--mirror", f"file://{src}", bare],
                       check=True, capture_output=True)
        try:
            repo_hygiene.history_files(bare)
            raise AssertionError("a bare repository was scanned against an empty registry")
        except repo_hygiene.NotAGitCheckout as exc:
            assert "BARE" in str(exc) and "unregistered" in str(exc), exc


def test_repo_hygiene_history_and_index_are_the_same_rule():
    """One definition of what may not be here, applied to two sets of paths. A separate extension list
    for history would agree the day it was written and diverge at the first addition to either —
    docs/ENGINEERING.md's opening failure mode, and the reason `history_files` takes `restricted_files` whole."""
    import tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    paths = ["a/doc.pdf", "b/deck.pptx", "c/notes.md", "d/sheet.xlsx", "tools/repo_snapshot.txt"]
    with tempfile.TemporaryDirectory() as tmp:
        _git_repo(tmp, "keep.md")
        real = repo_hygiene.history_paths
        try:
            repo_hygiene.history_paths = lambda _root: paths
            assert repo_hygiene.history_files(tmp) == repo_hygiene.restricted_files(tmp, paths)
        finally:
            repo_hygiene.history_paths = real
    # ...and every refused kind is refused in BOTH, derived from the list rather than restated.
    for pattern, _why in repo_hygiene.NEVER_COMMITTED:
        name = pattern.replace("*", "x")
        assert repo_hygiene.restricted_files("", [f"any/where/{name}"]), \
            f"{pattern} is declared refused but matches nothing"


def test_repo_hygiene_history_reports_a_path_once_and_ignores_directories():
    """A file committed, edited and deleted is ONE path to remove; six lines for it bury the other
    findings. And `rev-list --objects` names trees too — a directory called `reports.html` is not a
    saved web page, and classifying it as one puts noise into the check that most needs believing."""
    import subprocess, tempfile
    sys.path.insert(0, str(REPO / "platform" / "tools"))
    import repo_hygiene
    with tempfile.TemporaryDirectory() as tmp:
        _git_repo(tmp, "vendor/dict.pdf")
        for body in (b"v2", b"v3"):
            (Path(tmp) / "vendor" / "dict.pdf").write_bytes(body)
            subprocess.run(["git", "-C", tmp, "commit", "-qam", "edit"], check=True,
                           capture_output=True)
        (Path(tmp) / "reports.html").mkdir()
        (Path(tmp) / "reports.html" / "index.md").write_text("x", encoding="utf-8")
        subprocess.run(["git", "-C", tmp, "add", "-A"], check=True, capture_output=True)
        subprocess.run(["git", "-C", tmp, "commit", "-qm", "dir"], check=True, capture_output=True)
        hits = [f for f in repo_hygiene.history_errors(tmp) if "vendor/dict.pdf" in f]
        assert len(hits) == 1, f"three revisions of one path reported {len(hits)} times"
        assert not any("reports.html" in f for f in repo_hygiene.history_errors(tmp)), \
            "a directory was reported as a saved web page"


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
