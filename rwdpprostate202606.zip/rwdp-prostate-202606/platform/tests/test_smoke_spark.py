"""Registry-driven Spark smoke test: build the ADS for EVERY configured tumor on tiny synthetic
data. This is the multi-tumor execution coverage the pure-Python lint can't give — it exercises
optional sources (OC/EC drop alphabet/provenge), the index-SOURCE shape (DLBCL indexes off
diagnosis), and the config-driven LOT line-setting.

Spark-only -> skips without pyspark (the pure-Python CI runner). Has been run locally on a real
Spark (pyspark in a venv); install pyspark to execute it, or it skips.
"""
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(FRAMEWORK))
sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
PRODUCTS = FRAMEWORK.parent / "products"

# The synthetic frames and the local session live in ONE place, because they had two: a copy in
# `tools/smoke_prostate.py` that had already DIVERGED from this file, so the standalone demo built
# a different dataset than the one this suite proves.
import synthetic_sources                                                          # noqa: E402
_augment, _synth_src = synthetic_sources.augment, synthetic_sources.sources

try:
    from pyspark.sql import SparkSession
except Exception:
    SparkSession = None

# Stage modules are import-safe without pyspark OR pyyaml. engine.config needs pyyaml, so it is
# imported LAZILY inside the test — this file reaches the pyspark skip even when neither is present.
from engine.stages import (index as index_stage, demographics as dem_stage,         # noqa: E402
                           clinical as clin_stage, treatment as trt_stage,
                           outcomes as out_stage, assemble as asm_stage, lot as lot_stage)

try:
    import pytest
    pytestmark = pytest.mark.skipif(SparkSession is None, reason="pyspark not installed")
except Exception:
    pytest = None

GOOD = {"run.refresh": "v", "run.source_schema": "s", "run.output_schema": "o"}
_SPARK = None


def _spark():
    global _SPARK
    if _SPARK is None:
        _SPARK = synthetic_sources.session("smoke")
    return _SPARK


def _build_all_cohorts(cfg):
    from pyspark.sql import functions as F
    s = _spark()
    src = _synth_src(s, cfg)
    total = 0
    for cohort in cfg.cohorts:
        # treated derived PER COHORT off its line_setting (== build_ads.py), so the dual-setting mHSPC
        # path (treated/untreated mHSPC) is actually exercised, not just the global mCRPC setting.
        treated = (lot_stage.normalized(src, cohort.get("line_setting", cfg.lot_line_setting),
                                        exclude_settings=cfg.lot_exclude_settings,
                                        line_number_col=cfg.lot_line_number_col,
                                        maintenance_column=cfg.lot_maintenance_column)
                   .select("patientid").distinct().withColumn("treat_flag", F.lit(1)))
        idx = index_stage.build(src, cfg, cohort)
        dem = dem_stage.build(src, idx, cfg)
        clin = clin_stage.build(src, idx, cfg)
        trt = trt_stage.build(src, idx, cfg, cohort)
        out = out_stage.build(src, idx, clin, trt, cfg, cohort)
        ads = asm_stage.build(idx, dem, clin, trt, out, cfg, cohort, treated)
        assert "cohort" in ads.columns and "spec_version" in ads.columns
        total += ads.count()
    return total


def test_smoke_every_configured_tumor():
    if SparkSession is None:
        return
    from engine.config import load_yaml, load_config, product_config   # deferred: needs pyyaml
    checked, planned = 0, []
    for t in load_yaml(PRODUCTS / "registry.yaml")["tumors"]:
        # A registry entry with no `current_spec_version` is a PLANNED product — nsclc, sclc, mcrc,
        # hnscc, gist and cll are all listed and none has a pack. `product_config` RAISES on those
        # rather than returning a path that does not exist, so the `.exists()` skip below never got
        # the chance to run and the whole suite died on the first one. Skipping them here, by name,
        # keeps the reason legible instead of wrapping the call in a bare except.
        if not t.get("current_spec_version"):
            planned.append(t["slug"])
            continue
        cfg_path = product_config(PRODUCTS, t["slug"])
        if not cfg_path.exists():
            continue
        cfg = load_config(cfg_path, overrides=GOOD)
        _build_all_cohorts(cfg)        # end-to-end build must not error for any tumor
        checked += 1
    assert checked >= 2, (
        f"expected at least 2 configured tumors (prostate + one more); built {checked}, "
        f"skipped as planned-only: {planned}")


def test_smoke_prostate_production_union_path():
    # Exercise the REAL production entrypoint (build_ads.build_from_sources -> per-cohort stages,
    # unionByName, derived cohorts) on synthetic prostate sources — not the per-cohort loop. Asserts the
    # 7-cohort dual-setting ADS unions and carries BOTH per-setting COHORTU labels.
    if SparkSession is None:
        return
    from engine.config import load_config, product_config
    from engine import build_ads
    cfg = load_config(product_config(PRODUCTS, "prostate"), overrides=GOOD)
    ads = build_ads.build_from_sources(_synth_src(_spark(), cfg), cfg)
    assert {"cohort", "cohortu", "spec_version"} <= set(ads.columns)
    us = {r["cohortu"] for r in ads.select("cohortu").distinct().collect() if r["cohortu"]}
    assert any("mHSPC" in u for u in us) and any("mCRPC" in u for u in us), us  # both settings present


if __name__ == "__main__":
    if SparkSession is None:
        print("SKIP: pyspark not installed — run on a Spark runtime.")
        sys.exit(0)
    test_smoke_every_configured_tumor()
    print("ok  test_smoke_every_configured_tumor")
    test_smoke_prostate_production_union_path()
    print("ok  test_smoke_prostate_production_union_path")
