"""A record may only be carried forward on evidence — never on resemblance.

`platform/tools/spec_diff.py` answers "what did this spec revision actually change, and what can
carry". The answer is worth having because prostate 202606 -> 202607 changed NOTHING (199 of 200
rows byte-identical) and was re-drafted in full. It is also the answer with the worst failure mode
in the framework: a record wrongly carried forward is a requirement nobody re-read, still asserting
a rule the specification may no longer make, with a digest that says somebody checked.

So every test here pushes in the same direction — that carrying is hard and re-drafting is the
default:

  * a record with no digest, or whose cited row vanished, must be RE-DRAFT and never carried;
  * a pack with no extraction must REFUSE, not report zero changes;
  * the verdict must come from `contract_lint.spec_digest`, not a second implementation.

Run: python3 tests/test_spec_diff.py (or pytest).
"""
import ast
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import contract_lint as cl   # noqa: E402
import product_gates         # noqa: E402
import spec_diff             # noqa: E402

A = "products/oncology/prostate/202606"
B = "platform/tests/fixtures/prostate_202607"


def _extracted(pack):
    return os.path.exists(os.path.join(str(REPO), pack, "spec_pipeline", "out", "extracted.json"))


def test_the_two_revisions_this_was_written_for_still_look_the_same():
    """The premise. If a future revision genuinely changes the spec these numbers move, and the
    test should be re-read rather than relaxed — it is here to keep the fixture honest, not to
    freeze the packs."""
    assert _extracted(A) and _extracted(B), "both prostate packs need an extraction"
    delta, note = spec_diff.spec_delta(A, B, str(REPO))
    assert note is None, note
    assert delta["unchanged"] > 0.9 * delta["old_rows"], \
        f"the revisions diverged: {delta} — re-read this test rather than loosening it"


def test_an_unchanged_specification_carries_its_records():
    """The whole point. 202607 re-drafted what 202606 had already settled."""
    verdicts = spec_diff.carry(A, B, str(REPO))
    assert verdicts, "no records were assessed"
    carried = [v for v in verdicts if v[1] in (spec_diff.AS_IS, spec_diff.NEW_REF)]
    assert len(carried) > 0.9 * len(verdicts), \
        f"only {len(carried)} of {len(verdicts)} carried across an unchanged specification"


def test_a_different_specification_carries_nothing():
    """FAIL-CLOSED, and the direction that matters. Ovarian's spec shares no row with prostate's,
    so every prostate record must be re-drafted — a tool that carried any of them would be
    asserting a prostate rule over an ovarian specification."""
    oc = "products/oncology/oc/202606"
    if not _extracted(oc):
        return
    verdicts = spec_diff.carry(A, oc, str(REPO))
    assert verdicts
    carried = [v for v in verdicts if v[1] != spec_diff.REDRAFT]
    assert not carried, f"{len(carried)} record(s) carried onto a different tumour's spec: {carried[:3]}"


def test_a_record_with_no_digest_is_never_carried():
    """A digest is the evidence. Without one there is nothing to check, and 'nothing to check' is
    RE-DRAFT — the same rule the rest of this codebase applies to an absent counter."""
    verdicts = {v: (verdict, detail) for v, verdict, detail in spec_diff.carry(A, B, str(REPO))}
    for block in cl.records(cl.read(os.path.join(str(REPO), A, spec_diff.CONTRACT))):
        vid = (cl._scalar(block, "variable_id") or "").strip()
        digest = cl._scalar(block, "spec_digest")
        refs = cl._list(block, "spec_refs") or []
        if digest and digest != cl.NA and refs and refs != [cl.NO_SPEC_ROW]:
            continue
        assert verdicts.get(vid, ("",))[0] == spec_diff.REDRAFT, \
            f"{vid} has no checkable digest but was not marked re-draft"


def test_a_pack_with_no_extraction_refuses_rather_than_reporting_no_changes():
    """`unchanged: 0, added: 0` and "there is no extraction" are opposite answers. The second
    rendered as the first would report a revision that changed nothing."""
    without = [p for p in sorted(product_gates.products(str(REPO))) if not _extracted(p)]
    assert without, "every pack has an extraction — this test would prove nothing"
    delta, note = spec_diff.spec_delta(A, without[0], str(REPO))
    assert delta is None and note and "nothing was compared" in note, note
    assert spec_diff.carry(A, without[0], str(REPO)) is None
    text = spec_diff.render(A, without[0], str(REPO))
    assert "nothing was compared" in text
    assert "carries as-is" not in text, "an unreadable pack rendered as a carry-forward report"


def test_the_verdict_is_the_lints_digest_and_not_a_second_one():
    """`spec_digest` is what I15 uses to catch an edit made in place. Recomputing it differently
    here would mean the lint and the carry-forward could disagree about whether the same text
    changed."""
    assert spec_diff.cl is cl
    tree = ast.parse((TOOLS / "spec_diff.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    assert "spec_digest" in called and "spec_rows" in called
    assert "sha256" not in called and "md5" not in called, "spec_diff hashes something itself"


def test_it_writes_nothing():
    import hashlib
    def snap():
        out = {}
        for pack in (A, B):
            for rel in (spec_diff.CONTRACT, os.path.join("spec_pipeline", "out", "extracted.json"),
                        os.path.join("handoff", "DECISIONS.md")):
                p = Path(str(REPO)) / pack / rel
                if p.exists():
                    out[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
        return out
    before = snap()
    spec_diff.render(A, B, str(REPO))
    spec_diff.carried_decisions(A, B, str(REPO))
    assert snap() == before, "spec_diff modified a pack"


def test_it_is_not_deployed_to_production():
    import deploy_tree
    assert not any("spec_diff" in str(f) for f in deploy_tree.ROOT_FILES)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
