#!/usr/bin/env python3
"""The drafting skill must not fall behind the code it describes.

A skill is PROSE, and prose is the one place this repository's cardinal rule cannot be obeyed
literally: a markdown file cannot import `VALUE_MATCHERS`. So the names are written down twice, and
what holds the two copies equal is this test rather than a convention.

That distinction is the whole point. docs/ENGINEERING.md's own examples — the positional table parser, the
second `open_decisions`, the duplicate `PLACEHOLDERS` set — were all green when they diverged, and
each was caught by a person reading a diff. Here the divergence has a specific, cheap failure: the
engine grows an operator, nobody updates the skill, and the next drafter raises an `engine_gap` for a
capability that shipped. The gap is triaged, scheduled, and closed weeks later as a duplicate by
somebody who had to go and read `clinical.py` to find out. That is not a hypothetical shape — it is
what `from_startswith_ci` cost while the skill did not know it existed.

The direction matters and only one direction is checked: **every name the code defines must appear in
the skill.** The reverse is deliberately NOT asserted. A skill may name a thing the engine does not
have — it says `TODO` and `n/a` and quotes error text — and a test demanding the reverse would fail on
its own vocabulary.

WHAT IT DOES NOT CHECK, so nobody reads a pass as more than it is:

* **That the text SAYS the right thing.** A name pasted into a table with a wrong description passes.
  This defends against a name silently ABSENT, not against a wrong sentence, which needs a reader.
* **Where a vocabulary name appears.** `test_vocabularies_are_current` scans both pages, so deleting
  an operator's table row while a prose mention survives elsewhere passes — measured, not assumed.
  The scenario it does catch is the one that motivates it: the engine gains an operator, which
  appears NOWHERE, and CI goes red in the change that added it. The two SET comparisons — the
  invariant table and the domain list — are stricter, because both have one canonical list to hold
  the skill to and the vocabularies are spread across tables and prose.

    python3 platform/tests/test_skill_currency.py
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, "platform"))
sys.path.insert(0, os.path.join(ROOT, "platform", "tools"))

import contract_lint                                                  # noqa: E402
from engine.stages import clinical                                    # noqa: E402

SKILL = os.path.join(ROOT, ".claude", "skills", "draft-contract-record")

# The skill's OWN pages, not its evals. `evals.json` and `EVAL_RATIONALE.md` are measurements against
# named packs — they cite `products/oncology/<tumour>/<version>` because an eval that does not name a
# real pack cannot be run, and a count without its subject is not a measurement. They are excluded
# from both checks below for that reason, and excluding them is the honest scope: this test governs
# the instructions, which must work for a tumour nobody has configured yet.
PAGES = ("SKILL.md", "REFERENCE.md")


def _text():
    out = []
    for name in PAGES:
        path = os.path.join(SKILL, name)
        assert os.path.exists(path), f"{name} is missing from {SKILL}"
        with open(path, encoding="utf-8") as fh:
            out.append((name, fh.read()))
    return out


def test_vocabularies_are_current():
    """Every name in the engine's named registries is written down in the skill."""
    pages = _text()
    blob = "\n".join(t for _, t in pages)
    registries = {
        "clinical.DATE_BASIS": clinical.DATE_BASIS,
        "clinical.RECORD_PICK": clinical.RECORD_PICK,
        "clinical.TIE_BREAK": clinical.TIE_BREAK,
        "clinical.VALUE_MATCHERS": clinical.VALUE_MATCHERS,
        "clinical.GROUP_MARKERS": clinical.GROUP_MARKERS,
        "clinical.BLOCK_ONLY": clinical.BLOCK_ONLY,
    }
    missing = []
    for where, names in registries.items():
        assert names, f"{where} is empty — the registry moved and this test is now vacuous"
        for name in names:
            # `\b` will not do: `from_prefixes` and `prefixes` differ by a word boundary the regex
            # engine does not see inside an identifier, and `later_of` sits inside `earlier_of`.
            if not re.search(r"(?<![\w-])" + re.escape(name) + r"(?![\w-])", blob):
                missing.append(f"{where}: {name!r}")
    assert not missing, (
        "the drafting skill does not know these engine names:\n  " + "\n  ".join(missing) +
        "\n\nAdd them to .claude/skills/draft-contract-record/REFERENCE.md "
        "§'Is the rule expressible?'. A drafter that cannot express an operator raises a gap for a "
        "capability that already shipped.")
    print(f"ok  vocabularies — {sum(len(v) for v in registries.values())} names across "
          f"{len(registries)} registries")


def test_citation_domains_are_current():
    """The skill's list of citable domains is the one the extraction actually produces.

    `spec_refs` is `<domain>:<row>`, and the domains are the VALUES of `spec_sheet_map.yaml`'s
    `sheets:` block — the six an extraction can emit. The skill writes them out, because a drafter
    picking the domain has to know the set. A seventh arriving without the skill learning it is the
    same failure as a new operator: a drafter cites the tab label instead, and I8 rejects a record
    over a row that exists.
    """
    import product_gates as pg
    m, err = pg.read_yaml(os.path.join(ROOT, "governance", "spec_sheet_map.yaml"))
    assert not err, f"governance/spec_sheet_map.yaml: {err}"
    domains = {str(v).strip() for v in (m.get("sheets") or {}).values() if str(v).strip()}
    assert len(domains) >= 5, f"only {domains} — the sheet map moved and this check is vacuous"

    # THE LIST, not the file. Scanning the whole text for each name passed a mutation that deleted
    # `study_period` from the list, because the worked example further down happens to cite a
    # `study_period` row. A domain mentioned in passing is not a domain a drafter can choose from.
    with open(os.path.join(SKILL, "SKILL.md"), encoding="utf-8") as fh:
        skill = fh.read()
    lines = [l_ for l_ in skill.splitlines() if l_.count("·") >= 3 and "domain" not in l_.lower()]
    listed = set()
    for l_ in lines:
        cand = {p.strip().strip("`*") for p in l_.split("·")}
        if cand & domains:
            listed = cand
            break
    assert listed, ("no `a · b · c` domain list found in SKILL.md — if it was reformatted, teach "
                    "this test the new shape rather than dropping it")
    assert listed == domains, (
        f"SKILL.md's citable-domain list is {sorted(listed)}; the extraction emits "
        f"{sorted(domains)}. Missing: {sorted(domains - listed) or 'none'}. "
        f"Not a domain: {sorted(listed - domains) or 'none'}.")
    print(f"ok  domains — the list is exactly the {len(domains)} the extraction emits")


def test_invariants_are_current():
    """The reference's invariant TABLE lists exactly the invariants the lint defines.

    `contract_lint.INVARIANTS` is derived from the lint's own docstring, so this tracks the lint
    rather than a number somebody typed. A drafter that has never heard of I11 writes
    `decision_required` on a record blocked by nothing, and finds out from CI.

    THE TABLE, not the file. An earlier version of this test scanned the whole text for each id and
    then refused any mention of a retired one — which failed on the reference's own sentence saying
    I7 and I9 are retired. That sentence is useful and true; what must not happen is a retired id
    appearing in the drafter's list of things to satisfy, or an active one missing from it. The table
    rows are that list, so they are what is compared, and prose may discuss whatever it needs to.

    Both directions, which is the point of comparing SETS: a folded invariant left in the table sends
    someone looking for a check that no longer runs.
    """
    with open(os.path.join(SKILL, "REFERENCE.md"), encoding="utf-8") as fh:
        ref = fh.read()
    listed = set(re.findall(r"^\|\s*\*\*(I\d+)\*\*\s*\|", ref, re.M))
    active = set(contract_lint.INVARIANTS)
    assert len(active) >= 15, f"only {len(active)} active invariants — INVARIANTS parsing broke"
    assert listed, ("no invariant table found in REFERENCE.md — rows must read `| **I3** | … |`; "
                    "if the table was reformatted, this test needs to learn the new shape rather "
                    "than being dropped")
    missing = sorted(active - listed, key=lambda i: int(i[1:]))
    extra = sorted(listed - active, key=lambda i: int(i[1:]))
    assert not missing, (
        f"REFERENCE.md §'The invariants' does not list {', '.join(missing)} — add a row saying what "
        "each asks of a DRAFTER (the lint's own docstring already says what it checks).")
    assert not extra, (
        f"REFERENCE.md §'The invariants' lists {', '.join(extra)}, which the lint no longer defines "
        "— a drafter satisfying a retired check is doing work nothing asks for.")
    print(f"ok  invariants — table lists exactly the {len(active)} the lint defines")


def test_skill_names_no_tumour():
    """The instructions are for ANY tumour, so they may not carry one's name.

    Not a style point. The eval suite exists because a drafter recited one pack's answer against
    another — the right domain, the wrong row, a digest it could not have computed. Instructions
    carrying a worked `--product products/oncology/<tumour>/<version>` are the most copyable form of
    that error, and the pack under test is the one thing the user always supplies.

    Checked against the REGISTRY rather than a word list, so a new product is covered by being
    registered. `products/` is not walked: the shape-based discovery in `product_gates` would also
    find the test fixtures, whose slugs (`prostate_202607`) are exactly what EVAL_RATIONALE may
    legitimately discuss.
    """
    import product_gates as pg                     # the ONE governed YAML reader, not a second one
    reg, err = pg.read_yaml(os.path.join(ROOT, "products", "registry.yaml"))
    assert not err, f"products/registry.yaml: {err}"
    entries = [t for t in (reg.get("tumors") or []) if isinstance(t, dict)]
    names = set()
    for t in entries:
        # slug and code identify the TUMOUR; the spec versions identify a revision of it. All three
        # are what a copied `--product products/<family>/<slug>/<version>` is made of.
        names |= {str(t.get("slug") or ""), str(t.get("code") or ""),
                  str(t.get("current_spec_version") or "")}
        names |= {str(l_.get("spec_version") or "")
                  for l_ in (t.get("lineage") or []) if isinstance(l_, dict)}
        # `name` is a display string — "Prostate (mHSPC + mCRPC)" — so match its WORDS. The slug is
        # not always the word a writer reaches for: the ovarian pack's slug is `oc` and every
        # sentence about it said "ovarian", which a slug-only check waved through.
        names |= {w for w in re.findall(r"[A-Za-z]{4,}", str(t.get("name") or ""))}
    names = sorted(n for n in names if n.strip())
    assert len(entries) >= 2 and names, (
        "products/registry.yaml yielded no tumour names — this check is vacuous")

    hits = []
    for page, text in _text():
        for i, line in enumerate(text.splitlines(), 1):
            for n in names:
                if re.search(r"(?<![\w-])" + re.escape(n) + r"(?![\w-])", line, re.I):
                    hits.append(f"{page}:{i}: {n} — {line.strip()[:90]}")
    assert not hits, (
        "the drafting instructions name a specific product:\n  " + "\n  ".join(hits) +
        "\n\nWrite `<pack>` and let the caller supply it. Measurements about a named pack belong in "
        "EVAL_RATIONALE.md, and an eval must name one to be runnable — both are excluded here.")
    print(f"ok  tumour-neutral — {len(names)} registered names, none in {', '.join(PAGES)}")


def test_reference_points_at_the_owning_module():
    """The reference must SAY where each vocabulary lives, or the next editor has no way to know the
    text is a copy — and a copy nobody knows is a copy is the one that drifts."""
    with open(os.path.join(SKILL, "REFERENCE.md"), encoding="utf-8") as fh:
        ref = fh.read()
    for owner in ("platform/engine/stages/clinical.py", "platform/tools/contract_lint.py",
                  "platform/tests/test_skill_currency.py"):
        assert owner in ref, f"REFERENCE.md does not name {owner} as the authority"
    print("ok  reference names its owning modules")


if __name__ == "__main__":
    test_vocabularies_are_current()
    test_citation_domains_are_current()
    test_invariants_are_current()
    test_skill_names_no_tumour()
    test_reference_points_at_the_owning_module()
    print("\nALL SKILL CURRENCY TESTS PASSED")
