"""The packet shows a question; it must never quietly answer one, or invent a count.

`platform/tools/decision_packet.py` is the first thing in this framework built for the person who
has to DECIDE rather than the person who builds. Three ways it could go wrong, each with a test:

  * it recounts something — a blast radius or a status computed here would be a second
    implementation of a governed number, and a stakeholder would eventually be shown a figure the
    gates disagree with;
  * it reports a pack with no register as having nothing to answer — the absence-as-clean-result
    failure this codebase has produced in six other tools;
  * it writes to the pack, or offers a signature box for an attestation the register cannot store.

Run: python3 tests/test_decision_packet.py (or pytest).
"""
import ast
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import contract_lint     # noqa: E402
import decision_packet   # noqa: E402
import decision_report   # noqa: E402
import product_gates     # noqa: E402


def _with_register():
    out = [p for p in sorted(product_gates.products(str(REPO)))
           if os.path.exists(os.path.join(str(REPO), p, decision_packet.DECISIONS))]
    assert out, "no pack keeps a decisions register — these tests would prove nothing"
    return out


def test_it_writes_nothing_to_the_pack():
    """Asserted on the BYTES of every register before and after rendering both forms."""
    before = {p: (Path(str(REPO)) / p / decision_packet.DECISIONS).read_bytes()
              for p in _with_register()}
    for pack in _with_register():
        decision_packet.render_text(pack, str(REPO))
        decision_packet.render_html(pack, str(REPO))
    after = {p: (Path(str(REPO)) / p / decision_packet.DECISIONS).read_bytes()
             for p in _with_register()}
    assert before == after, f"changed: {[p for p in before if before[p] != after[p]]}"


def test_a_pack_with_no_register_refuses_rather_than_reporting_nothing_to_answer():
    """`[]` means "checked, nothing open". No register means nobody can be asked anything, and the
    two must not render the same — a stakeholder reading "0 open questions" concludes they are
    finished."""
    without = [p for p in sorted(product_gates.products(str(REPO)))
               if not os.path.exists(os.path.join(str(REPO), p, decision_packet.DECISIONS))]
    assert without, "every pack keeps a register — this test would prove nothing"
    items, note = decision_packet.packet(without[0], str(REPO))
    assert items == [] and note and "nothing was assembled" in note, note
    for render in (decision_packet.render_text, decision_packet.render_html):
        text = render(without[0], str(REPO))
        assert "nothing was assembled" in text
        assert "open question(s), ordered" not in text, "an unreadable pack rendered as a worklist"


def test_the_blast_radius_is_the_reporters_and_not_a_second_count():
    """Every number on the page comes from the tool that owns it. A packet that counted blocked
    records itself would drift from `decision_report` the first time either changed."""
    assert decision_packet.decision_report is decision_report
    assert decision_packet.contract_lint is contract_lint
    tree = ast.parse((TOOLS / "decision_packet.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    assert "blast_radius" in called, "the packet no longer asks decision_report"
    # ...and it agrees with the owner, per decision, on a real pack.
    for pack in _with_register():
        items, note = decision_packet.packet(pack, str(REPO))
        assert note is None
        blocking, _t, _i, _s = decision_report.blast_radius(os.path.join(str(REPO), pack))
        for d in items:
            assert d["blocks"] == sorted(blocking.get(d["id"], [])), \
                f"{pack}:{d['id']} blast radius disagrees with decision_report"


def test_it_reads_a_register_whatever_it_spells_its_columns():
    """The packs disagree — `Approved answer`/`Conflict / evidence` in one, `Resolution`/`Evidence`
    in the others. The packet must read every one of them, through the shared vocabulary rather than
    a list of its own, or a stakeholder is shown a blank question."""
    tree = ast.parse((TOOLS / "decision_packet.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(tree)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)}
    for accessor in ("decision_question", "decision_evidence", "decision_owner"):
        assert accessor in called, f"the packet does not read through {accessor}()"
    seen_spellings = set()
    for pack in _with_register():
        rows = contract_lint.decision_rows(
            contract_lint.read(os.path.join(str(REPO), pack, decision_packet.DECISIONS)))
        seen_spellings |= {k for k in next(iter(rows.values()))}
        items, _n = decision_packet.packet(pack, str(REPO))
        for d in items:
            assert d["question"].strip(), f"{pack}:{d['id']} rendered with an empty question"
    assert {"Approved answer", "Resolution"} & seen_spellings, \
        "the packs no longer disagree — this test would prove nothing"


def test_only_open_decisions_are_put_in_front_of_a_person_and_the_worst_comes_first():
    for pack in _with_register():
        items, _n = decision_packet.packet(pack, str(REPO))
        status = contract_lint.decision_status(
            contract_lint.read(os.path.join(str(REPO), pack, decision_packet.DECISIONS)))
        for d in items:
            assert str(status.get(d["id"], "OPEN")).strip().upper() == "OPEN", \
                f"{pack}:{d['id']} is settled but was put in front of a person again"
        counts = [len(d["blocks"]) for d in items]
        assert counts == sorted(counts, reverse=True), f"{pack}: not ranked by blast radius"


def test_the_page_says_what_it_cannot_record():
    """It offers somewhere to write an answer, so it must say plainly that no signature can be
    stored yet. A form collecting an attestation the register has nowhere to put would be gathering
    them into a void — and every OTHER approval in this framework carries who, when and a hash."""
    assert decision_packet.UNRECORDABLE, "the honesty notice was removed"
    for pack in _with_register()[:1]:
        for render in (decision_packet.render_text, decision_packet.render_html):
            text = render(pack, str(REPO))
            for what, _why in decision_packet.UNRECORDABLE:
                assert what in text, f"{render.__name__} does not disclose: {what}"


def test_register_prose_cannot_inject_markup():
    """The questions are hand-written markdown and end up in HTML."""
    page = decision_packet.render_html(_with_register()[0], str(REPO))
    body = page.split("<div class='w'>", 1)[1]
    for tag in ("<script", "<iframe", "onerror="):
        assert tag not in body.lower(), f"{tag} survived into the page"


def test_it_is_not_deployed_to_production():
    import deploy_tree
    assert not any("decision_packet" in str(f) for f in deploy_tree.ROOT_FILES)


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
