"""The finalization check: a pack's stated summary against the evidence it summarizes.

These exist because of a measured failure. `sandbox/experiments/ovarian_202606_contract_draft` is a
frozen 295-record run whose records were individually plausible and whose SUMMARY was not — a header
claiming "Scope: `demographics` only" over six domains and a maturity note claiming
"0 undispositioned" against 47. Every gate the repo had passed it,
because a claim written in prose was not an artifact anyone validated.

Run: python3 platform/tests/test_finalize.py (CI runs these as scripts, not under pytest).
"""
import os
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "platform" / "tools"))

import re                                                           # noqa: E402
import contract_lint as cl                                          # noqa: E402
import finalize                                                     # noqa: E402

FROZEN = REPO / "sandbox" / "experiments" / "ovarian_202606_contract_draft"


def _pack(tmp, note=None, header="", records=(("AGE", "demographics:9"),)):
    """The smallest pack `finalize` will read: a contract, and optionally a maturity note."""
    d = Path(tmp) / "pack"
    (d / "handoff").mkdir(parents=True)
    cols = list(cl.TABLE_COLUMNS)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for vid, ref in records:
        cells = [vid, f"[{ref}]"] + ["n/a"] * (len(cols) - 2)
        lines.append("| " + " | ".join(cells) + " |")
    (d / "handoff" / "FUNCTIONAL_CONTRACT.md").write_text(header + "\n".join(lines), encoding="utf-8")
    if note is not None:
        (d / "handoff" / "MATURITY.yaml").write_text(
            f"configuration: not_started\ncontract: draft\nnote: >\n  {note}\n", encoding="utf-8")
    return str(d)


def test_a_true_claim_passes_and_a_stale_one_does_not():
    """The whole point: same sentence shape, one number right and one wrong."""
    with tempfile.TemporaryDirectory() as tmp:
        good = _pack(tmp, note="1 records, none approved.")
        assert finalize.claim_errors(good) == [], finalize.claim_errors(good)
    with tempfile.TemporaryDirectory() as tmp:
        bad = _pack(tmp, note="53 records, none approved.")
        errs = finalize.claim_errors(bad)
        assert len(errs) == 1 and "53 records" in errs[0] and "1 records" in errs[0], errs


def test_a_narrowed_scope_claim_is_caught():
    """The failure that reads as finished: a header naming one domain over records citing several."""
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack(tmp, header="**Scope: `demographics` only.**\n\n",
                  records=(("AGE", "demographics:9"), ("PFS", "outcomes:13")))
        errs = finalize.claim_errors(d)
        assert len(errs) == 1 and "scope 'demographics' only" in errs[0] and "outcomes" in errs[0], errs

    # A header claiming a scope it actually keeps is not an error, and a header claiming none is not
    # making a claim at all. Both would be noise, and a noisy check gets switched off.
    with tempfile.TemporaryDirectory() as tmp:
        assert finalize.claim_errors(_pack(tmp, header="**Scope: `demographics` only.**\n\n")) == []
    with tempfile.TemporaryDirectory() as tmp:
        assert finalize.claim_errors(_pack(tmp, header="Covers what it covers.\n\n",
                                           records=(("A", "demographics:9"), ("B", "outcomes:1")))) == []


def test_a_section_heading_count_tracks_distinct_records_not_citations():
    """`## `outcomes` — N records` drifts the moment a record lands without the heading being touched.

    Counted as DISTINCT records citing the domain: prostate/202606 has two records over `outcomes:11`,
    so 21 records sit under a heading whose row range (2–21) is correct. Counting citations instead of
    records would make every multi-row record look like drift.
    """
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack(tmp, header="## `demographics` — 2 records, spec rows 9–10\n\n",
                  records=(("AGE", "demographics:9"),))
        errs = finalize.claim_errors(d)
        assert len(errs) == 1 and "headed 2 records but 1" in errs[0], errs

    with tempfile.TemporaryDirectory() as tmp:
        # one record, two citations in the same domain -> ONE record for the heading
        d = Path(_pack(tmp, header="## `demographics` — 1 records, spec rows 9–10\n\n"))
        f = d / "handoff" / "FUNCTIONAL_CONTRACT.md"
        f.write_text(f.read_text(encoding="utf-8").replace("[demographics:9]",
                                                           "[demographics:9, demographics:10]"),
                     encoding="utf-8")
        assert finalize.claim_errors(str(d)) == [], finalize.claim_errors(str(d))


def test_the_invariant_count_has_one_definition():
    """`INVARIANTS` derives from the docstring enumeration, which is where they are declared.

    Three separate prose counts used to restate it, and a governed pack note said "all 15 invariants"
    after I16 and I17 landed — a stale claim nothing could see because nothing owned the number.
    """
    assert len(cl.INVARIANTS) == len(set(cl.INVARIANTS)), "an invariant is enumerated twice"
    assert cl.INVARIANTS[0] == "I1"
    assert [int(i[1:]) for i in cl.INVARIANTS] == sorted(int(i[1:]) for i in cl.INVARIANTS)

    # THE REGISTRY MUST EQUAL WHAT THE LINT EMITS. Not a subset — equality, because both directions
    # have already been wrong here.
    #
    # The docstring is a registry of every id ever issued: I7 is RETIRED and I9 is FOLDED INTO I13
    # (its trigger is a strict subset of I13's, so I13 owns the emission and merely explains the
    # approved case in its own message). Counting them gave 17, then 16, when 15 fire.
    #
    # The previous version of THIS assertion scanned `errors.append` bodies for any `I\d+` and so
    # matched the literal "I9" inside I13's explanatory string — it confirmed the wrong number. An
    # emission is an id at the START of the message, after the optional `{tag}` / `[{vid}]` prefix.
    body = (REPO / "platform" / "tools" / "contract_lint.py").read_text(encoding="utf-8")
    emitted = set(re.findall(r'errors\.append\(\s*f?"(?:\{tag\}\s*|\[\{vid\}\]\s*)?(I\d+)\b', body))
    assert emitted, "no emissions found — has the error-message shape changed?"
    assert set(cl.INVARIANTS) == emitted, (
        f"the registry and the emissions disagree — declared not emitted: "
        f"{sorted(set(cl.INVARIANTS) - emitted)}; emitted not declared: {sorted(emitted - set(cl.INVARIANTS))}")

    # and the two reasons an id is in the docstring but inactive must both still be honoured
    doc = cl.__doc__
    assert "RETIRED" in doc and "FOLDED INTO" in doc, "the inactive markers this parses are gone"
    assert "I7" not in cl.INVARIANTS and "I9" not in cl.INVARIANTS, cl.INVARIANTS
    # No prose count may restate it — that is how the note went stale in the first place.
    src = (REPO / "platform" / "tools" / "contract_lint.py").read_text(encoding="utf-8")
    stale = re.findall(r"\b(?:all\s+)?(?:\d+|seventeen|sixteen|fifteen)\s+(?:schema\s+)?invariants?\b",
                       src, re.I)
    assert not stale, f"contract_lint restates its own invariant count: {stale}"


def test_an_unreadable_maturity_file_FAILS_the_gate():
    """An unreadable summary is a FAILURE, not an empty one — asserted through the CLI, not a helper.

    This tool has now fail-opened twice on the same file, and the second time got past the first
    test because that test only asked whether `claim_text()` mentioned UNREADABLE. It did. But
    `claim_errors()` then ran the numeric-claim regexes over the parser's error message, found no
    number in it, and the CLI printed "OK — every stated summary matches the evidence" and exited 0
    on a pack whose summary it could not read.

    So this asserts the OUTCOME a user sees — a non-zero exit — and not an intermediate value. A test
    on the helper cannot see a fail-open that happens after the helper returns.
    """
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack(tmp, note="1 records.")
        Path(d, "handoff", "MATURITY.yaml").write_text("- not\n- a mapping\n", encoding="utf-8")

        errs = finalize.claim_errors(d)
        assert errs and any("cannot be read" in e for e in errs), errs

        r = subprocess.run([sys.executable, str(REPO / "platform" / "tools" / "finalize.py"),
                            d, "--check"], capture_output=True, text=True)
        assert r.returncode != 0, f"the gate passed an unreadable MATURITY.yaml:\n{r.stdout}"
        assert "OK —" not in r.stdout, r.stdout

    # and the note of a READABLE file must actually reach the checker
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack(tmp, note="99 records.")
        assert any("99 records" in text for _, text in finalize.claim_text(d)), \
            "the maturity note was not read — the tuple-unpacking regression is back"
        assert finalize.claim_errors(d), "a readable, WRONG note produced no error"


def test_a_config_that_declares_no_sources_is_not_treated_as_pre_config():
    """A pack with no config is exempt by design. Deleting the `sources:` block from a config that
    DOES exist is the cheapest way to buy that exemption, so it is refused separately."""
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(_pack(tmp))
        (d / "config").mkdir()
        (d / "config" / "data_product.yaml").write_text("refresh: 2026m06\n", encoding="utf-8")
        errs = finalize.claim_errors(str(d))
        assert errs and any("no `sources:` block" in e for e in errs), errs


def _pack_with_config(tmp, sources, source_cell, decision=""):
    d = Path(_pack(tmp))
    (d / "config").mkdir()
    (d / "config" / "data_product.yaml").write_text(
        "sources:\n" + "".join(f"  {s}: t_{s}\n" for s in sources), encoding="utf-8")
    f = d / "handoff" / "FUNCTIONAL_CONTRACT.md"
    t = f.read_text(encoding="utf-8")
    cols = list(cl.TABLE_COLUMNS)
    row = t.strip().splitlines()[-1].split(" | ")
    row[cols.index("source")] = source_cell
    row[cols.index("decision_ids")] = decision or "[]"
    f.write_text("\n".join(t.strip().splitlines()[:-1] + [" | ".join(row)]), encoding="utf-8")
    return str(d)


def test_a_source_key_config_does_not_declare_must_be_flagged_as_open():
    """An invented alias reads exactly like a resolved one. `psmapet` / `psma_pet` are the same vendor
    table spelled two ways across two versions of one product, and neither pack declares either."""
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack_with_config(tmp, ["demographics"],
                              "{kind: vendor, inputs: {psmapet: {date: scandate}}}")
        errs = finalize.claim_errors(d)
        assert len(errs) == 1 and "psmapet" in errs[0], errs

    # Naming the open question is the whole escape hatch — this is I17's shape one layer down.
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack_with_config(tmp, ["demographics"],
                              "{kind: vendor, inputs: {psmapet: {date: scandate}}}", "[SOME-DECISION]")
        assert finalize.claim_errors(d) == [], finalize.claim_errors(d)

    # A declared key is simply fine.
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack_with_config(tmp, ["demographics", "psmapet"],
                              "{kind: vendor, inputs: {psmapet: {date: scandate}}}")
        assert finalize.claim_errors(d) == [], finalize.claim_errors(d)


def test_source_keys_come_from_the_canonical_parser_not_a_private_regex():
    """`source_check.parse_sources` owns this field — its own docstring says a caller holding the file
    "asks this parser instead of writing another set of regexes against the same field". A private
    regex was written anyway, and this is the case that proves it was not merely redundant:

        inputs: {psma-pet: {date: scandate}}

    The canonical parser YAML-loads it and returns `psma-pet`. The regex `(\\w+):\\s*\\{` cannot match a
    hyphen, so it returned `pet` — a source name that does not exist, reported against the wrong key
    and silently correct-looking. A hyphenless fixture cannot tell the two apart, which is why the
    first version of this suite passed under both.
    """
    with tempfile.TemporaryDirectory() as tmp:
        d = _pack_with_config(tmp, ["demographics"],
                              "{kind: vendor, inputs: {psma-pet: {date: scandate}}}")
        errs = finalize.claim_errors(d)
        assert len(errs) == 1, errs
        assert "psma-pet" in errs[0], f"the source name was misread: {errs[0]}"
        assert "pet," not in errs[0] and "source(s) pet" not in errs[0], errs[0]


def test_a_pack_with_no_config_is_not_required_to_resolve_sources():
    """The workflow authors the contract BEFORE config exists. Demanding resolution there would fail
    every new tumour by construction, which is how a check gets switched off instead of obeyed."""
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(_pack(tmp))
        f = d / "handoff" / "FUNCTIONAL_CONTRACT.md"
        t = f.read_text(encoding="utf-8")
        cols = list(cl.TABLE_COLUMNS)
        row = t.strip().splitlines()[-1].split(" | ")
        row[cols.index("source")] = "{kind: vendor, inputs: {invented_alias: {a: b}}}"
        f.write_text("\n".join(t.strip().splitlines()[:-1] + [" | ".join(row)]), encoding="utf-8")
        assert not os.path.exists(d / "config")
        assert finalize.claim_errors(str(d)) == [], finalize.claim_errors(str(d))


def test_the_skills_worked_examples_actually_PASS_the_lint_they_describe():
    """The skill drifted from the code twice in two commits, and phrase-matching did not catch it.

    Both times the prose stayed plausible while the rule under it changed: it demanded a `gap_ids`
    entry on `pending_mapping` after I18 stopped requiring one (recreating the onboarding failure that
    change existed to remove), and it called `implementation_refs` optional after I19 made it
    mandatory. A test searching for phrases cannot see either, because the phrases were still there —
    they had simply become false.

    So this RUNS them. Every ```yaml block in the skill that looks like a contract record is linted
    with the real invariants. A claim the skill makes about what passes is then a claim the lint
    agrees with, or the test fails.
    """
    # ACROSS THE SKILL, not one file. The skill is SKILL.md (what governs a run) + REFERENCE.md (what
    # you look up while drafting) + EVAL_RATIONALE.md (the evidence for the rules); the worked shapes
    # live in the second. A test pinned to SKILL.md would read the split as the example being deleted.
    skill_dir = REPO / ".claude" / "skills" / "draft-contract-record"
    if not skill_dir.exists():
        return
    text = "\n".join(f.read_text(encoding="utf-8") for f in sorted(skill_dir.glob("*.md")))

    # The `pending_mapping` example, assembled into a complete record and linted for real.
    import re as _re
    m = _re.search(r"```yaml\n(source: \{kind: pending_mapping.*?)```", text, _re.S)
    assert m, "the skill no longer shows a pending_mapping example — has the state been removed?"
    example = {ln.split(":", 1)[0]: ln.split(":", 1)[1].strip()
               for ln in m.group(1).splitlines() if ":" in ln and not ln.startswith(" ")}
    assert "gap_ids" in example, "the example dropped gap_ids entirely; it should show the empty form"
    assert example["gap_ids"] == "[]", \
        (f"the skill's pending_mapping example cites {example['gap_ids']} — I18 does NOT require a "
         f"gap, and the starter pack has no ENGINE_GAPS.md for one to resolve against")
    assert example.get("implementation_refs") == "[none]", example.get("implementation_refs")

    # ...and the two rules those examples rest on, asserted against the LINT rather than the prose.
    import contract_lint as _cl
    src = (REPO / "platform" / "tools" / "contract_lint.py").read_text(encoding="utf-8")
    i18 = src[src.index("I18 `source.kind: pending_mapping`"):]
    assert "gap_ids" not in i18[:i18.index("I19")], \
        "I18 mentions gap_ids again — if it now requires one, the skill and its example must say so"
    assert _cl.PENDING_MAPPING in _cl.SOURCE_KINDS
    assert "I19" in _cl.INVARIANTS, "I19 was retired; the skill still calls the field mandatory"

    # The skill must not describe the mandatory field as optional. Checked as a CLAIM, not a phrase:
    # if the section header says conditional/optional while I19 is active, they disagree.
    head = [ln for ln in text.splitlines()
            if (ln.startswith("###") or ln.startswith("| `implementation_refs`"))
            and "implementation_refs" in ln]
    assert head, "the skill no longer documents implementation_refs"
    assert not any(w in head[0].lower() for w in ("conditional", "optional")), \
        f"I19 makes implementation_refs mandatory, but the skill says: {head[0]}"


def test_the_skill_teaches_the_no_config_rule_the_tool_enforces():
    """The tool can only enforce this once a pack declares sources. Before that — every new tumour —
    the only thing standing between a drafter and an invented alias is the skill saying not to."""
    skill_dir = REPO / ".claude" / "skills" / "draft-contract-record"
    if not skill_dir.exists():
        return
    text = "\n".join(f.read_text(encoding="utf-8") for f in sorted(skill_dir.glob("*.md")))
    assert "config/` does not exist" in text or "no `config/` yet" in text, \
        "the skill does not cover the no-config case at all"
    for cue in ("psmapet", "psma_pet",              # the evidence that it has already gone wrong
                "physical_name: TODO",              # the naming half of the rule
                "name_status: undecided"):
        assert cue in text, f"the no-config rule no longer states {cue!r}"


def test_the_frozen_run_still_fails_every_way_it_documented():
    """Real-data guard. The snapshot is kept precisely because it demonstrates these failures; if the
    check stops reporting them, the check broke, not the snapshot."""
    if not FROZEN.exists():
        return
    errs = finalize.claim_errors(str(FROZEN))
    joined = " | ".join(errs)
    for expect in ("0 undispositioned", "47 dispositions", "scope 'demographics' only"):
        assert expect in joined, f"the frozen run no longer reports {expect!r}: {errs}"
    # The snapshot's "all 15 invariants" was CORRECT when it was frozen and is stale now: I18 and I19
    # were added afterwards, so 17 fire. The specimen is deliberately not regenerated — rewriting its
    # note would destroy the thing it exists to be — so this asserts the CURRENT truth, which is that
    # finalize reports the drift. What must never happen is finalize reporting a number that matches.
    assert f"but the pack has {len(cl.INVARIANTS)} invariants" in joined, (
        f"finalize no longer notices the frozen note's invariant count going stale: {errs}")
    assert "all 15 invariants" not in joined.split("says")[0], "the wrong number is being reported"


def test_every_governed_pack_agrees_with_its_own_evidence():
    """The sweep. Asserts non-empty discovery, because `products()` derives its root from the CWD and
    a discovery-based test can pass from one directory and be silently vacuous from the other."""
    import product_gates as pg

    # `products()` derives its root from the CWD, and CI runs this suite from `platform/` where it
    # finds nothing. Discovering from the repo root explicitly is what makes the sweep mean the same
    # thing from either directory; the emptiness assertion below is what caught it being vacuous.
    here = os.getcwd()
    try:
        os.chdir(REPO)
        packs = [os.path.join(REPO, p) for p in pg.products()
                 if os.path.exists(os.path.join(p, "handoff", "FUNCTIONAL_CONTRACT.md"))]
    finally:
        os.chdir(here)
    assert packs, "no pack with a contract was discovered — this test is running vacuously"
    for p in packs:
        assert finalize.claim_errors(p) == [], f"{p}: {finalize.claim_errors(p)}"


if __name__ == "__main__":
    import traceback
    failed = 0
    for _name, _fn in sorted(globals().items()):
        if _name.startswith("test_") and callable(_fn):
            try:
                _fn()
                print(f"  ok   {_name}")
            except BaseException:                     # noqa: BLE001
                failed += 1
                print(f"  FAIL {_name}")
                traceback.print_exc()
    print(f"\n{'FAILED' if failed else 'OK'} — {failed} failure(s)")
    sys.exit(1 if failed else 0)
