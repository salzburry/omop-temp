"""The HTML view must stay a VIEW, and must never render restricted output.

`platform/tools/render_html.py` draws one governed stage as a page. Two ways that goes wrong, and
both are worse here than in a terminal tool:

  * IT COMPUTES SOMETHING. A page that disagrees with `worksheet.py` is the one that gets believed,
    because it is the one with the colours on it. Every number must come from the stage tool that
    owns it, through `worksheet.model` — the shared derivation, so the ranking cannot differ.
  * IT RENDERS RESTRICTED CONTENT. A profile TSV carries per-column top values and date ranges with
    no small-cell floor; a schema report names physical vendor tables. Putting either into an HTML
    file — the one artifact shaped to be opened and shared — is worse than committing it.
    `repo_hygiene` already refuses a committed `*.html` for exactly that reason.

Run: python3 tests/test_render_html.py (or pytest).
"""
import ast
import os
import sys
from pathlib import Path

FRAMEWORK = Path(__file__).resolve().parent.parent
TOOLS = FRAMEWORK / "tools"
REPO = FRAMEWORK.parent
sys.path.insert(0, str(TOOLS))

import product_gates  # noqa: E402
import render_html    # noqa: E402
import worksheet      # noqa: E402

# Anything that reads delivered data, or a report derived from it. A view importing one of these has
# a path from a vendor column value to a shareable page.
RESTRICTED_READERS = ("profile_io", "profile_facts", "run_product_profile",
                      "run_product_schema_check", "source_check", "source_preflight")


def _packs_with_contract():
    out = [p for p in sorted(product_gates.products(str(REPO)))
           if os.path.exists(os.path.join(str(REPO), p, "handoff", "FUNCTIONAL_CONTRACT.md"))]
    assert out, "no pack has a contract — these tests would prove nothing"
    return out


def test_the_page_and_the_terminal_read_ONE_derivation():
    """The same function OBJECT, not two readers that agree today.

    `worksheet.render` orders decisions by how many records each unblocks; that ordering IS the
    tool's value. A renderer sorting them again would be a second opinion about which decision
    matters most, and nothing would go red when the two diverged.
    """
    src = ast.parse((TOOLS / "render_html.py").read_text(encoding="utf-8"))
    called = {n.func.attr for n in ast.walk(src)
              if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
              and isinstance(n.func.value, ast.Name) and n.func.value.id == "worksheet"}
    assert "model" in called, "render_html does not read worksheet.model — it derives its own state"

    # ...and the page presents that order unchanged.
    for pack in _packs_with_contract():
        m = worksheet.model(pack)
        if not m or not m["decisions"]:
            continue
        html = render_html.page("worksheet", pack)
        shown = [d["id"] for d in m["decisions"][:worksheet.TOP_DECISIONS]]
        at = [html.index(f">{d}<") for d in shown if f">{d}<" in html]
        assert len(at) == len(shown), f"{pack}: the page drops a ranked decision"
        assert at == sorted(at), f"{pack}: the page re-orders the ranking"
        return
    raise AssertionError("no pack has a blocking decision — this test would prove nothing")


def test_neither_rendering_drops_what_the_other_shows():
    """SPLITTING THE MODEL WAS SUPPOSED TO PREVENT EXACTLY THIS, AND DID NOT.

    `worksheet.model` gained `unranked` (the output decisions blast radius cannot rank) and
    `surface_notes` (the 67-emitted / 13-published gap). The terminal renderer grew both sections.
    The HTML one did not — so the page kept saying "all 38 governed blocks are claimed" as though
    that were the whole Gate 4 answer, one renderer after the shared derivation was introduced to
    stop that.

    One derivation is not enough on its own: what makes the two agree is that every field carrying
    a REFUSAL or an OPEN ITEM must reach both. Asserted by content, on the live packs.
    """
    for pack in _packs_with_contract():
        m = worksheet.model(pack)
        if not m:
            continue
        text, html = worksheet.render(pack), render_html.page("worksheet", pack)
        for did in m["unranked"]:
            assert did in text, f"{pack}: the terminal worksheet drops open decision {did}"
            assert did in html, f"{pack}: the HTML worksheet drops open decision {did}"
        for note in m["surface_notes"]:
            probe = " ".join(note.split())[:60]
            assert probe in " ".join(text.split()), f"{pack}: the terminal drops a surface note"
            assert probe in " ".join(render_html._e(html).split()) or probe in " ".join(
                html.split()), f"{pack}: the HTML worksheet drops a surface note"


def test_the_synthetic_stage_value_looks_like_a_delivered_SUB_STAGE():
    """WHAT THE DEMO CELL MEANS DEPENDS ENTIRELY ON THIS VALUE.

    `stage=CHECK/99` is shown on a page and explained as G-STAGE-PREFIX — a delivered sub-stage the
    configuration cannot classify because `from_prefixes` is exact `IN`. That reading is only true
    if the fixture supplies something a reader recognises as a stage. It has been wrong twice: a
    generic "1" (proves the fallthrough and nothing else), then `0B1`, because prostate lists a `0`
    group first — arithmetically the same demonstration and visually junk, which a reader dismisses
    as bad data rather than seeing the gap.

    Asserted against the live packs: the value must extend one of the pack's own configured tokens,
    and must not be the bare numeric one.
    """
    sys.path.insert(0, str(FRAMEWORK / "tests" / "fixtures"))
    import synthetic_sources
    from engine.config import load_config
    from engine.stages.clinical import _stage_case
    checked = 0
    for pack in _packs_with_contract():
        cfg_path = os.path.join(str(REPO), pack, "config", "data_product.yaml")
        if not os.path.exists(cfg_path):
            continue
        groups = ((load_config(cfg_path).pack("clinical") or {}).get("staging") or {}).get("groups")
        if not groups:
            continue
        checked += 1
        # THE FIXTURE'S OWN FUNCTION, not this test's copy of its arithmetic. The first version
        # re-derived the token selection here and asserted on its own result, which passes whatever
        # the fixture actually feeds `groupstage`.
        value = synthetic_sources.stage_probe(groups)
        tokens = [str(v).strip() for g in groups
                  for v in (g.get("from_prefixes") or g.get("from_startswith_ci") or [])
                  if str(v).strip()]
        assert value, f"{pack}: the fixture supplies no stage value at all"
        stem = next((v for v in tokens if value.startswith(v)), None)
        assert stem, f"{pack}: {value!r} extends no token the config declares"
        assert any(c.isalpha() for c in stem) or not any(
            any(c.isalpha() for c in v) for v in tokens), \
            f"{pack}: the fixture stage value {value!r} reads as junk, not as a stage"
        # ...and it must actually EXERCISE the classifier rather than sit outside it. Compiling the
        # pack's own CASE and checking the value is not one of the exact tokens is what makes the
        # CHECK/99 cell mean "unclassifiable sub-stage" rather than "value nobody configured".
        assert value not in tokens, \
            f"{pack}: {value!r} is itself a configured token, so it demonstrates nothing"
        assert _stage_case(groups, "groupstage", "label"), f"{pack}: staging compiles to nothing"
    assert checked, "no pack configures staging groups — this test would prove nothing"


def test_no_physical_vendor_TABLE_NAME_reaches_the_page():
    """THE BOUNDARY IS WHAT REACHES THE PAGE, NOT THE IMPORT GRAPH.

    A transitive-import check was the first thing written here and it was wrong: `worksheet` reaches
    `source_check` and `profile_io` through the tools it summarises, and that is FINE — those tools
    hand it verdicts and counts, and WORKFLOW.md's boundary is exactly that verdicts cross while
    contents do not. Asserting on imports would have failed a correct design while proving nothing
    about the artifact people actually forward.

    So this asserts the artifact. A pack's `sources:` map holds the physical stems the engine
    resolves tables from — `t_enh_prostate_biomarker` and its kind — and none of them may appear in
    a page whose entire purpose is to be opened and shared.
    """
    checked = 0
    for pack in _packs_with_contract():
        cfg_path = os.path.join(str(REPO), pack, "config", "data_product.yaml")
        if not os.path.exists(cfg_path):
            continue
        stems = {str(v) for v in ((product_gates.read_yaml(cfg_path)[0] or {})
                                  .get("sources") or {}).values() if str(v).strip()}
        if not stems:
            continue
        checked += 1
        html = render_html.page("worksheet", pack)
        leaked = sorted(s for s in stems if s in html)
        assert not leaked, f"{pack}: the page names physical vendor table(s) {leaked}"
    assert checked, "no pack declares physical sources — this test would prove nothing"


def test_render_html_itself_imports_no_reader_of_delivered_data():
    """The weaker companion to the check above, and worth keeping for a different reason.

    It says nothing about `worksheet`, which is allowed to summarise those tools. It says this
    module must not grow its OWN path to one — the shape a "just add the profile numbers too" change
    takes, where the page stops being a view over sanitized state and starts reading the TSV.
    """
    tree = ast.parse((TOOLS / "render_html.py").read_text(encoding="utf-8"))
    direct = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            direct |= {a.name.split(".")[0] for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            direct.add(node.module.split(".")[0])
    bad = sorted(direct & set(RESTRICTED_READERS))
    assert not bad, (f"render_html imports {bad} directly — a page is the one artifact shaped to be "
                     f"opened and shared, and those read delivered values and physical table names")


def test_every_renderable_stage_is_declared():
    """`STAGES` is an allowlist, not a lookup that falls back. A stage nobody vetted must not become
    renderable by being spelled correctly on the command line."""
    assert render_html.STAGES, "no stage is renderable — this test would prove nothing"
    try:
        render_html.main(["profile", str(REPO / _packs_with_contract()[0]), "--out",
                          "/tmp/x.html"])
    except SystemExit as exc:
        assert "not a renderable stage" in str(exc), exc
    else:
        raise AssertionError("an undeclared stage was accepted")
    try:
        render_html.page("profile", _packs_with_contract()[0])
    except KeyError:
        pass
    else:
        raise AssertionError("an undeclared stage rendered a page")


def test_an_unrecognised_body_raises_rather_than_drawing_a_blank_section():
    """AN EMPTY SECTION READS AS A CLEAN RESULT — the rule this repo has now written six times.

    A renderer that returned "" for a body shape it did not know would draw the heading, draw
    nothing under it, and look exactly like a section with nothing to report.
    """
    try:
        render_html._body({"kind": "something_nobody_wrote"})
    except ValueError:
        return
    raise AssertionError("an unknown body kind rendered as an empty section")


def test_a_pack_with_no_contract_is_told_so_rather_than_shown_zeroes():
    """Same rule as the terminal worksheet: a worklist of zeroes reads as 'nothing to do' rather
    than 'nothing to read'."""
    without = [p for p in sorted(product_gates.products(str(REPO)))
               if not os.path.exists(os.path.join(str(REPO), p, "handoff",
                                                  "FUNCTIONAL_CONTRACT.md"))]
    if not without:
        return
    html = render_html.page("worksheet", without[0])
    assert "Nothing to order yet" in html
    assert "no handoff/FUNCTIONAL_CONTRACT.md" in html, \
        "the page does not say WHY there is nothing to order"


def test_the_page_escapes_what_it_renders():
    """Register text is human prose and reaches the page verbatim. Unescaped, a `<` in a question
    silently swallows the rest of a section — and the section still looks finished."""
    assert render_html._e("a < b & c") == "a &lt; b &amp; c"
    assert "<script>" not in render_html._e("<script>")


def test_the_flow_reads_each_gate_from_the_tool_that_owns_it():
    """Six panels, six owners. The page adds the ORDER and nothing else.

    Asserted against `status.gates`, which is where the gate states and their blockers live —
    including the OWNER map, which `status.py` says in as many words no other module may hold.
    """
    sys.path.insert(0, str(TOOLS))
    import status as status_tool
    pack = _packs_with_contract()[0]
    html = render_html.page("flow", pack)
    six = status_tool.gates(str(REPO), pack)
    assert len(six) == 6, six
    for n, title, state, _why in six:
        assert f">{state}<" in html, f"gate {n}: the page does not show its state {state!r}"
        # ESCAPED, because that is what reaches the page — OWNER[5] carries an apostrophe.
        assert render_html._e(status_tool.OWNER[n]) in html, \
            f"gate {n}: the page does not name its owner"
    # ...and every state it can draw has a style, or a real state renders unlabelled.
    assert set(s for _n, _t, s, _w in six) <= set(render_html.STATE_CLASS), \
        f"a gate state has no styling: {set(s for _n, _t, s, _w in six)}"


def test_an_absent_synthetic_build_is_not_shown_as_a_build_that_produced_nothing():
    """THE RULE AGAIN, in the one panel where a zero would be most convincing.

    A "0 rows / 0 columns" line under "synthetic build" reads as a build that ran and produced
    nothing. Nobody ran it. The page has to say which.
    """
    pack = _packs_with_contract()[0]
    bare = render_html.page("flow", pack)
    assert "nobody ran" in bare, "an unbuilt pack is not told that no build is attached"
    assert "synthetic ADS rows" not in bare, "the page shows build counts with no build attached"

    # THE WHOLE DOCUMENT, which is what the CLI passes. The builder used to receive only the
    # nested `gate5` summary, so `effective_run_bindings` — recorded at the top level, and the one
    # thing the caption exists to name — never reached it and the page said "(synthetic)".
    ev = {"pack": pack, "source_mode": "synthetic", "git_commit": "abc123",
          "effective_run_bindings": {"refresh": "synthetic", "source_schema": "synthetic"},
          "gate5": {"rows": 21, "columns": 187, "cohorts": ["C1", "C2"], "spark": "4.2.0",
                    "sample_cols": ["patientid", "cohort"], "sample": [["p1", "C1"], ["p2", "C2"]]}}
    built = render_html.page("flow", pack, ev)
    assert "synthetic ADS rows" in built and ">21<" in built
    assert "nobody ran" not in built
    # ...and the bindings are NAMED, not summarised into the word they are all set to.
    assert "refresh=synthetic" in built and "source_schema=synthetic" in built, \
        "the caption does not name the effective run bindings the evidence carries"


def test_the_evidence_file_must_actually_carry_a_build():
    """An evidence file with no `gate5` block is not a build of zero rows. Refused, not rendered."""
    import json
    import tempfile as _tf
    p = os.path.join(_tf.mkdtemp(), "empty.json")
    with open(p, "w", encoding="utf-8") as fh:
        json.dump({"pack": "x"}, fh)
    try:
        render_html.main(["flow", str(REPO / _packs_with_contract()[0]),
                          "--out", "/tmp/x.html", "--evidence", p])
    except SystemExit as exc:
        assert "no `gate5` build summary" in str(exc), exc
    else:
        raise AssertionError("an evidence file with no build was accepted")


def test_the_caption_is_a_CHECKED_claim_about_whose_build_it_is():
    """THE PANEL SAYS "the same configuration above, on SYNTHETIC sources". Every clause of that is
    falsifiable, and the page used to print it over any non-empty `gate5` block.

    Another tumour's build, an older configuration, or — the one that matters — a REAL-data run
    would each have been captioned that way. Each clause is verified against the checkout the page
    is drawn from, and unstated is never a pass: only the producer knows the source mode, so
    silence there is exactly the case that must not render.
    """
    sys.path.insert(0, str(TOOLS))
    import local_smoke
    pack = _packs_with_contract()[0]
    # BUILT BY THE PRODUCER, not spelled here. A hand-written record is a second opinion about what
    # the evidence contains, and it drifted the first time the producer gained a field: the test
    # kept passing while a real file from local_smoke would have been refused.
    good = {**local_smoke.binding(os.path.join(str(REPO), pack)),
            # The tree is dirty during development; this test is about the CHECKER, not the tree.
            "git_clean": True,
            "gate5": {"rows": 4, "columns": 187, "cohorts": ["A"], "spark": "4.2.0",
                      "sample_cols": ["patientid"], "sample": [["p1"]]}}
    assert render_html.evidence_errors(good, pack) == [], render_html.evidence_errors(good, pack)

    for field, value, expect in (
            ("pack", "products/oncology/somewhere/else", "it was built for"),
            ("source_mode", "live", "source_mode is live"),
            ("source_mode", None, "(unstated)"),
            ("science_digest", "deadbeef", "science_digest"),
            ("committed_delivery_digest", "deadbeef", "committed_delivery_digest"),
            # THE ENGINE, not only the config: a build from older code with untouched YAML matches
            # every digest and is not the build the page is drawn from.
            # A different commit is only a problem when its CONTENT differs — a merge of the
            # very branch that produced the build has an identical tree, and refusing that made
            # the evidence stale the moment it landed.
            ("git_commit", "0" * 40, "whose content differs"),
            ("git_clean", False, "DIRTY checkout"),
            ("platform_version", "0.0.1", "platform 0.0.1")):
        bad = {**good, field: value}
        why = render_html.evidence_errors(bad, pack)
        assert why, f"{field}={value!r} was accepted"
        assert any(expect in w for w in why), (field, value, why)

    # A build with no gate5 block is still refused, and for its own reason.
    assert any("no `gate5`" in w for w in render_html.evidence_errors({**good, "gate5": {}}, pack))


def test_a_placeholder_delivery_is_shown_as_unbound():
    """`REPLACE_ME` is a truthy string, so `if v` printed it under "delivery bound to" — while the
    gate treats it as unstated and refuses a --complete verdict over it. The page said bound, the
    tool said unbound, and the page is the one a reader believes."""
    sys.path.insert(0, str(TOOLS))
    import product_gates as pg
    from engine import config as ecfg
    checked = 0
    for pack in _packs_with_contract():
        cfg = os.path.join(str(REPO), pack, "config", "data_product.yaml")
        if not os.path.exists(cfg):
            continue
        bindings = ecfg.delivery_bindings(ecfg.merged_raw(cfg))
        if not any(pg.unstated(v) for v in bindings.values()):
            continue
        checked += 1
        html = render_html.page("flow", pack)
        assert ">unbound<" in html, f"{pack}: placeholder bindings are shown as a delivery"
        assert "REPLACE_ME" not in html or "not set" in html, \
            f"{pack}: a placeholder is printed as if it were a value"
    assert checked, "no pack has an unbound delivery — this test would prove nothing"


def test_gate_3_reads_its_state_not_the_presence_of_a_file():
    """`os.path.exists(SOURCE_VERDICTS.md)` said "accepted verdict: yes" for a verdict that had
    failed, gone stale, named another cut or carried no reviewer. Existence is not acceptance."""
    src = (TOOLS / "render_html.py").read_text(encoding="utf-8")
    code = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
    assert "SOURCE_VERDICTS.md\")) else" not in code and "accepted verdict" not in code, \
        "the flow still reports a verdict by asking whether the file exists"


def test_it_writes_outside_the_checkout_through_the_one_guard():
    """`repo_hygiene` refuses a committed `*.html` — a saved page is how a vendor documentation
    portal gets captured, and the rule says a generated report belongs outside the repository. The
    refusal is `pack_run.restricted_dir`, the same guard the profiler uses; a second copy here would
    be free to disagree about what counts as inside."""
    import pack_run
    assert render_html.pack_run.restricted_dir is pack_run.restricted_dir

    src = (TOOLS / "render_html.py").read_text(encoding="utf-8")
    code = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
    assert "restricted_dir(" in code, "--out is not routed through the outside-the-checkout guard"

    try:
        render_html.main(["worksheet", str(REPO / _packs_with_contract()[0]), "--out",
                          str(REPO / "leaked.html")])
    except SystemExit as exc:
        assert "inside the checkout" in str(exc), exc
    else:
        raise AssertionError("a page was written into the checkout")
    assert not (REPO / "leaked.html").exists()


def test_out_is_required():
    """No default path. A view that wrote somewhere convenient would eventually write somewhere
    tracked, and the extension is the one `repo_hygiene` refuses."""
    try:
        render_html.main(["worksheet", str(REPO / _packs_with_contract()[0])])
    except SystemExit as exc:
        assert "--out is required" in str(exc), exc
    else:
        raise AssertionError("the renderer chose an output path for itself")


def test_it_is_not_deployed_to_production():
    """A drafting view has no business in the workspace: `runtime_tools` derives the deployed set
    from what platform/databricks/ imports, and nothing there imports this."""
    import deploy_tree
    assert "render_html.py" not in set(deploy_tree.runtime_tools(str(REPO)))
    assert not any("render_html" in str(f) for f in deploy_tree.ROOT_FILES)


def test_the_page_is_self_contained():
    """A strict CSP and an offline reviewer both need this: no external stylesheet, script, font or
    image. The page has to render from its own bytes."""
    html = render_html.page("worksheet", _packs_with_contract()[0])
    for external in ("http://", "https://", "<script", "@import", "src="):
        assert external not in html, f"the page reaches outside itself ({external!r})"


def test_both_themes_are_styled():
    """It renders in the reader's theme, and the toggle must win in both directions."""
    html = render_html.page("worksheet", _packs_with_contract()[0])
    for needed in ("prefers-color-scheme:dark", '[data-theme="dark"]', '[data-theme="light"]'):
        assert needed in html, f"missing {needed}"


if __name__ == "__main__":
    os.chdir(FRAMEWORK)
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")
