# Reference — vocabularies, field meanings, worked records

Looked up while drafting, not read start to finish. `SKILL.md` is what governs a run; this is what it
points at. Nothing here is a second source of truth: where a definition lives in code, this says which
module owns it and stops.

---

## The record shape

`variable_id`, then the canonical fields, then `implementation_refs`. **`TABLE_COLUMNS` in
`platform/tools/contract_lint.py` is the authority.** Do not count fields off this file — a count
written down here is a second definition of the schema and is wrong for some pack the moment it is
written.

```
variable_id · spec_refs · spec_digest · required_rule · source · grain · anchor · window
record_selection · tie_break · derivation · cohort_applicability · missing · units · depends_on
output · status · decision_ids · gap_ids · publish · acceptance · notes · implementation_refs
```

Irrelevant fields are `n/a` or `[]` — never omitted, because an absent field is indistinguishable from
an overlooked one.

**Every governed contract table is `TABLE_COLUMNS` — one shape, no exceptions.**
`contract_lint.table_shape_errors` rejects a non-canonical header, a missing or unknown column, the
right columns in the wrong order, and any row whose width disagrees with its header, in both
directions.

`handoff/FUNCTIONAL_CONTRACT.md` stores records as rows of one **markdown table**. A fenced ```yaml
block is the LEGACY form: the reader accepts it only when a file has no table, and where both appear
the table wins and the fenced records are **not read at all**. A block pasted under a table is a record
nobody will ever enforce.

---

## What each field is answering

| Field | What it must capture |
|---|---|
| `spec_refs` | **machine-owned** — the `<domain>:<row>` citation, supplied by `--item` |
| `spec_digest` | **machine-owned** — binds the record to the TEXT of the cited rows, not just their numbers. What catches RWB editing a rule in place after the record was written |
| `required_rule` | **machine-owned** — the spec's own Definition cell. Not a field you write, and not one you qualify: an interpretation that is not literally in the source ("approximate", "assumed", "probably") belongs in `notes`, where a reviewer can see it is yours |
| `source` | `kind` + `inputs` (or `parameters`) — **proposed only** |
| `grain` | the row identity the variable is defined at |
| `anchor` | the date everything is measured from |
| `window` | the interval, with bounds exactly as the spec words them |
| `record_selection` | which record wins when several qualify |
| `tie_break` | how a tie resolves — without this the output is non-reproducible |
| `derivation` | the executable rule; an exact expression where the spec gives one |
| `missing` | `no_record` vs `present_null` behaviour — two different situations |
| `depends_on` | other variables this needs, which sets build order |
| `acceptance` | a concrete worked example with real values, so it can become a test |
| `notes` | caveats, preserved spec typos, naming divergences |
| `implementation_refs` | REQUIRED on every record. `[none]` when nothing implements it yet; blank and `TODO` both fail (I19) |

---

## Controlled vocabularies

The lint enforces these, so a wrong guess is caught.

- `status.requirement` — `approved` · `draft` · `decision_required`
- `status.source` — `verified` · `dictionary_only` · `unverified` · `unavailable` (the COARSE axis, for
  a product before Gate 3). A product at Gate 3 replaces it with all four finer axes, and Gate 4
  requires them:
  - `status.source_mapping` — `proposed` · `human_confirmed`
  - `status.dictionary_check` — `not_run` · `passed` · `failed` · `not_available` (no dictionary ships
    with this feed — accepted only beside a passed live schema check and an accepted profile check)
  - `status.live_schema_check` — `not_run` · `passed` · `failed`
  - `status.data_profile_check` — `not_run` · `reviewed` · `issue_open` · `accepted`

  Carry EITHER the coarse axis OR all four; a mix fails I6. Draft every check at `not_run` and
  `source_mapping: proposed`.
- `status.implementation` — `implemented` · `partial` · `config_gap` · `engine_gap` · `not_implemented` · `not_derivable`
- `status.validation` — `not_run` · `passed_test` · `passed_live` · `failed`
- `output.role` — `published` · `internal` · `metadata` · `excluded`
- `output.name_status` — `aligned` · `undecided` (only two, and `undecided` is the honest one wherever
  the spec does not establish a physical name — see `pending_mapping` below)
- `publish.{ads,dictionary,dashboard,tfl}` — `configured` · `required` · `proposed` · `excluded` · `undecided`

**Never write `passed`, `accepted`, `human_confirmed`, `verified`, `passed_live`, or
`requirement: approved`.** Those are human transitions backed by evidence.

---

## The invariants, and what each one asks of a drafter

**`platform/tools/contract_lint.py`'s module docstring is the authority** — it states what each
invariant CHECKS, in the code that runs it. This table states what each one asks of the person or
model writing the record, which is a different question and the one you need while drafting. Retired
ids (I7, I9) are absent because the lint no longer defines them.

`--product` runs all of these against the pack before your record reaches a governed file, so this is
a list of failures you can avoid rather than a list you must memorise. The ones with teeth for a fresh
Gate 2 draft are **I17**, **I19**, **I18** and **I11**.

| | Asks of you |
|---|---|
| **I1** | One record per `variable_id`. Revise the record that already cites your row — the slice hands it to you in full — rather than adding a second |
| **I2** | Every id in `decision_ids` / `gap_ids` must already EXIST. Raising a decision means adding the register entry too (APPLY) or reporting the entry you would add (REVIEW/DRAFT); a record citing an id nobody created fails |
| **I3** | Only vocabulary values above. Not "TBD", not a sentence, not a value from a sibling framework |
| **I4** | `output.role: published` obliges `physical_name`, `type`, `nullable`. If the spec does not establish a physical name, the record is not published-with-a-TODO-name — it is `name_status: undecided` with `physical_name: TODO`, and I10 then keeps it off `approved` |
| **I5** | `publish.dashboard: configured` claims the variable is ALREADY in `dashboard_vars.yaml`. You are drafting a requirement, not a deployment: `required` or `proposed` is what a spec row supports |
| **I6** | Every canonical key present. `n/a` and `[]` are answers; omission is not |
| **I8** | Every `<domain>:<row>` must resolve to a captured row. `--item` supplies these, which is the point — a citation you typed is a citation that can be wrong |
| **I10** | An `approved` requirement carries no `TODO` anywhere. You never write `approved`, so this bites in one direction only: leaving a TODO is correct and safe, and it is the flip to `approved` — a human act — that the TODO blocks |
| **I11** | `requirement: decision_required` **if and only if** the record cites an OPEN requirement-level decision. Both directions fail: blocked-on-nothing, and citing an open decision without saying you are blocked. A RESOLVED id may stay on the record as the trace of what settled it |
| **I12** | The axes must agree with each other. A record cannot be validated further than it is built, or built further than its requirement is settled. `INITIAL_STATUS` is consistent by construction — this bites when you revise one axis of an existing record and leave the others behind |
| **I13** | A SHORTFALL — `config_gap`, `engine_gap`, `partial`, `not_derivable` — must name a gap. An ordinary fresh draft is `not_implemented`, which is not a shortfall and needs no gap (see §"Is it a gap, or is it config?" in SKILL.md before you claim `engine_gap`) |
| **I14** | Pack-level, at `contract: approved`: no record still being written, no decision-blocked record claiming to be built. You cannot reach it and cannot break it; it is why an honest `draft` costs nothing |
| **I15** | The record is bound to the TEXT it was written from. Machine-owned — and the reason retyping `spec_digest` is refused rather than tolerated |
| **I16** | One record per spec row, at `coverage_complete` and above. A range like `clinical:17-46` on one record is what this refuses |
| **I17** | A record over an UNSETTLED row leaves a TODO on a REQUIREMENT field, or names a decision/gap. Not the source axis, not the naming axis — a requirement field. The one invariant aimed at a **plausible answer filled into a row the spec leaves open**: I3 catches an invented enum, I8 a fabricated citation, I2 a made-up decision id, but each of those is wrong in SHAPE. I17 is what stands against a value wrong only in FACT, so treat a pass here as the thing you were actually checked on |
| **I18** | `pending_mapping` is legal only while the pack has no `sources:` registry, must carry the spec's own identifiers verbatim, and can never be approved, source-verified or implemented |
| **I19** | `implementation_refs` is ANSWERED. `[none]` for a fresh draft; blank and `TODO` both fail |
| **I20** | Inline `{...}` cells must have balancing braces. Every other check finds a field by scanning for its token, so a dropped `}` can put `role` inside `codes` and pass nineteen invariants. The tool renders your YAML, so this is one you get for free by not hand-typing rows |

---

## Is the rule expressible? The named vocabularies

**`platform/engine/stages/clinical.py` owns these; `governance/RECORD_SELECTION_VOCABULARY.md` is the
open proposal for the contract-layer half.** They are listed here for ONE decision: whether a rule the
spec states is something the framework can already express, or a genuine shortfall that needs a gap.
`platform/tests/test_skill_currency.py` fails if this list falls behind the engine.

They are not a menu to pick from. The spec states the rule; you record it. What this list changes is
`status.implementation` and whether `gap_ids` gets an entry — and a false `engine_gap` is expensive,
because it is triaged, scheduled and closed as a duplicate by someone who had to go and read the code.

### The order to work through — the engine is the LAST thing to suspect

A rule that no operator below expresses is not therefore an engine shortfall. Stop at the first
answer that fits:

1. **Is the clinical rule settled?** If the spec is silent, truncated or self-contradictory →
   `requirement: decision_required` and a decision id. Nothing is buildable yet, and filing it as an
   engine gap sends RWDE a question only RWB can answer.
2. **Does the feed supply what the rule needs?** A field that is not delivered →
   `implementation: not_derivable` with a gap naming the missing input (I13). The engine is not at
   fault for a column nobody ships.
3. **Does it need governed reference material** — an external terminology, code table or crosswalk?
   That is a Gate 1 material for someone to register, not an operator for someone to add.
4. **Only then**: the rule is clear, the data is there, and no named operator can express it →
   `engine_gap` and a gap id. That entry is worth opening, because it names something that genuinely
   does not exist.

**Which DATE a source record is measured on** — `date_basis`, and it is BLOCK-level only (`BLOCK_ONLY`),
never per item:

| | |
|---|---|
| `column` | the single named date column (the default) |
| `later_of` | the greatest of several date columns, ignoring nulls |
| `earlier_of` | the least of several date columns, ignoring nulls |

**Which ROW wins once the window is applied** — `pick`:

| | |
|---|---|
| `nearest` | closest to the anchor (the default) |
| `earliest` | the earliest record in the window |
| `latest` | the latest record in the window |
| `priority` | the best status by the item's `priority` label order, across ALL in-window rows |

**How a TIE resolves** — `tie_break`: `prior` (the earlier record, the default) · `later`.

A record whose `record_selection` and `tie_break` land inside those three registries is CONFIG work:
`implementation: not_implemented`, no gap. One that does not — a rule needing a new operator — is a
real `engine_gap` and gets one.

**How a group claims a raw value** — `VALUE_MATCHERS`, for any value-to-group map (stage groupings,
grade, histology, TNM, biomarker status):

| | |
|---|---|
| `from_prefixes` | exact match on any listed value, case-SENSITIVE (the legacy spelling — the name says prefix and the operator does not) |
| `from_equals_ci` | case-insensitive equality |
| `from_startswith_ci` | case-insensitive prefix; the LONGEST matching prefix wins, whatever order the groups are written in |
| `from_contains_ci` | case-insensitive substring |
| `from_regex` | a Java/Spark regular expression, applied VERBATIM and case-SENSITIVELY — `(?i)` for case-insensitive |

`from_regex` is the escape hatch and reads like one. The other four name their rule, so a reviewer
reads the group and knows what it claims; a regex is a small program in a YAML cell, and checking it
is a different and harder act. It earns its place only where none of the four can express the rule —
anchoring, alternation, or tolerance of whitespace and punctuation the feed varies (`3+4=7` beside
`3 + 4 = 7`). If the spec's rule is an enumeration or a prefix collapse, the named operator is the
right answer and the regex is not.

Plus two reserved MARKERS, which are not matchers and match by position: `when: fallthrough` is the
ELSE, `when: missing` fires on NULL. **They are different answers.** A record whose stage is null is
not the same fact as a record whose stage is a word nobody mapped, so a `missing` rule and a
fallthrough rule are two things for a spec to state and two things for a record to carry — collapsing
them into one is a recorded gap on a live pack, not a hypothetical.

The reason this matters at drafting time: a spec saying a delivered sub-stage collapses to its parent
stage is **`from_startswith_ci`**, which exists. Writing that up as an engine shortfall raises a gap
for a capability that shipped. Conversely, a spec asking for something none of these express — a
numeric comparison on a text field, a lookup against an external clinical vocabulary — is a
shortfall, and saying so is the useful thing you do.

---

## `source` shapes

```yaml
source: {kind: vendor, inputs: {lot: {line_start: startdate}, mortality: {death: dateofdeath}}}
source: {kind: derived}
source: {kind: parameter, parameters: [study.index_start]}
source: {kind: constant}
source: {kind: unavailable}
source: {kind: pending_mapping, spec_identifiers: [Demographics.BirthYear]}
```

**One input per source, and every column under the source it comes from.** `death: dateofdeath` under
`mortality` says which table to look in, so Gate 3 can prove the mapping instead of finding the name in
whichever of the record's tables happens to carry it.

Each key under `inputs` must exist in that pack's `config/data_product.yaml` `sources:` block — config
owns the physical name, and it changes with the tumour AND with the delivery format. A name it does not
define is a Gate 3 `unknown_source` failure; the fix is a config entry or a recorded gap, never a
guessed table.

Column values must be **atomic column names**. A formula (`max(a, b)`), a sentence, or another
variable's name belongs in `derivation`, `record_selection` or `depends_on`.

Set `physical_stem` ONLY when the spec itself names a physical table — then it is registered evidence
and `stem_drift` checks config still agrees with it. Otherwise omit it: an inferred stem looks like
stand-in and is not.

The older shape — `logical_table` prose plus one flat `columns` map — still parses, because records
written before the migration carry it. Do not write new ones in it.

### `pending_mapping`, in full

Legal ONLY while the pack has no `sources:` registry (I18). Once one exists, a record still saying
`pending_mapping` is a mapping nobody did.

```yaml
source: {kind: pending_mapping, spec_identifiers: [Demographics.BirthYear]}
status: {requirement: draft, source: unverified, implementation: not_implemented, validation: not_run}
gap_ids: []
implementation_refs: [none]
notes: "Logical source registry not yet authored. Identifier copied exactly from the specification."
```

* `spec_identifiers` carries the spec's OWN identifiers, **verbatim**, and may not hold a placeholder.
  That is what lets someone who never read the workbook finish the mapping.
* It can never be `requirement: approved`, never `source:` anything but `unverified`, never
  `implementation: implemented`. It cannot pass Gate 3, Gate 4 or approval.
* **No gap is required, and do not invent one.**
* **It does NOT make the record `decision_required`.** The requirement axis and the source-mapping axis
  are separate: a rule RWB has fully specified does not become an open scientific question because RWP
  has not yet chosen an alias. Marking it so buries the rows that genuinely need RWB.
* **Never lowercase or reshape a spec name into a physical one.** Where the spec does not establish a
  physical output name: `physical_name: TODO`, `target_published_name:` the spec's own variable name,
  `name_status: undecided`. Lowercasing `PSMA_SCANDT` to `psma_scandt` is an inferred naming decision
  wearing stand-in's clothes.

`platform/tools/finalize.py` enforces the machine-checkable half: once a pack DOES declare sources, a
record naming a key outside that set must cite a decision or a gap.

---

## A worked record

From the demographics tab, source coordinate 9 (an Excel row here; a file line for a per-tab input) — *"AGE | YEAR(INDEXDT) - birthyear"*.

**The judgment file** — what a drafter writes. Note what is NOT here: `spec_refs`, `spec_digest` and
`required_rule` come from `--item demographics:9`, and supplying them is an error.

```yaml
variable_id: AGE
source: {kind: vendor, inputs: {demographics: {birth_year: birthyear}}}
grain: [patientid, index_date, cohortn]
anchor: index_date
window: n/a
record_selection: n/a
tie_break: {equidistant: n/a, same_day: n/a}
derivation: "year(index_date) - cast(birthyear as int)"
cohort_applicability: all cohorts (varies per cohort index date)
missing: {no_record: n/a, present_null: "birthyear null → AGE null (→ AGEGR1N Unknown)"}
units: years
depends_on: [INDEXDT]
output: {physical_name: age, target_published_name: AGE, name_status: aligned, type: integer, nullable: true, codes: n/a, role: published}
status: {requirement: draft, source: unverified, implementation: implemented, validation: not_run}
implementation_refs: [variables/demographics.yaml#/age, engine:_age_at_index]
decision_ids: []
gap_ids: []
publish: {ads: configured, dictionary: configured, dashboard: undecided, tfl: undecided}
acceptance: "index_date=2026-01-01, birthyear=1954 → AGE=72"
notes: Approximate (year-only DOB) — note in the dictionary. The band child AGEGR1/agegrl is its own record.
```

Render it:

```bash
python3 platform/tools/contract_record.py age.yaml --product <pack> --item demographics:9
```

**`<pack>` and the row number are both YOURS to establish, and neither transfers.** The same variable
in another tumour is another row — `AGE` is `demographics:9` in one pack and `demographics:6` in
another — so a command copied off this page runs against the wrong extraction. It will not quietly
succeed: `--item` refuses an id the pack does not have and names the ones that exist. That refusal is
the check, and it only fires if you passed the pack you were actually asked about.

The rendered row is deliberately NOT reproduced here. Keeping a hand-maintained copy of generated
output beside the generator is the duplicate the tool exists to remove: the two agree only while
someone remembers to update both, and the row is the half nobody reads carefully.

This record is **mature** — it is already built, so it carries `implementation: implemented` and real
`implementation_refs`. A fresh Gate 2 draft from a spec row is not: `implementation: not_implemented`
and `implementation_refs: [none]`. **Do not copy this record's implementation state onto a new draft.**

Note what it does: carries the spec's own column name rather than a guess; states the year-only
approximation in `notes` instead of hiding it; gives an `acceptance` case with real numbers a test can
assert; and leaves `source: unverified` because no human has yet confirmed the mapping.

---

## LEGACY MIGRATION ONLY — a pack that has `config/` but no `handoff/`

**This is not the new-tumour path, and reading it as one inverts the workflow.** A governed new tumour
goes contract-first: the pack has `handoff/` and no `config/` — that is `pending_mapping` above. A pack
with the OPPOSITE shape — config and variables already built, no contract, no decision register, no
lint — is a product implemented before this framework existed, being documented backwards.

Several steps have nothing to write to. Do not let that turn into silent omission:

- Draft the records anyway, and **name the decision and gap IDs you would have opened**, stating in the
  report that they resolve to nothing yet and must be created. An ID that points nowhere is honest; a
  record with no `decision_ids` because the file was missing is not.
- **Invariant I8 cannot run** — nothing verifies that your `spec_refs` point at real rows, and `--item`
  has no extraction to read, so `--format-only` is the honest flag. That check is what normally catches
  a hallucinated citation, so compensate: say exactly how you established each row number, and flag any
  part you inferred rather than read.
- Hand-check the invariants you can (uniqueness, legal enums, the full key set, inline dicts) and report
  which ones you could not run rather than implying a clean pass.

---

## Why `status` is the tool's field and not yours

`contract_record` settles `status`: a NEW record gets `INITIAL_STATUS`, a REVISION keeps what the
existing record already holds, and a draft that writes one is refused.

This is the third attempt and the first that is the right shape. It began as `HUMAN_ONLY`, a blacklist
of seven values a drafter must not set — which fails OPEN on the one event most likely to happen, the
lint gaining an eighth. `FINE_SOURCE_AXES` arrived after the coarse `source` axis, and
`data_profile_check: reviewed` after that; each time a blacklist would have kept passing while a new
human verdict quietly became assertable.

So it became `DRAFTABLE`, an allowlist per axis, which fails closed on a new value. Better, and still
wrong: `failed`, `passed_test`, `passed_synthetic`, `issue_open` and `dictionary_only` all sat inside
it, and every one of them is an EVIDENCE CLAIM — a statement that a check ran and returned a
particular answer. A drafter has read a specification row. It has not run a test, opened a data
dictionary or reviewed a profile, and no allowlist can make writing those honest.

`DRAFTABLE` remains as the vocabulary check `test_contract_lint` holds against `contract_lint` — every
status value sits on exactly one side of the line, so adding one to the lint fails a test until
somebody decides which side. But nothing model-facing consults it any more, because nothing
model-facing writes a status.

`--actor` is gone with it. It declared who was authoring and could not establish it: the same caller
that would misreport it also passed it, so it read as an authorization check while being a string.
What governs a status transition is that it lands in `FUNCTIONAL_CONTRACT.md`, a governed file
CODEOWNERS routes for review — and now the drafting path cannot reach one at all.
