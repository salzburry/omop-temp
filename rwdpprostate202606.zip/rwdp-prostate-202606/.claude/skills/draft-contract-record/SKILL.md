---
name: draft-contract-record
description: >
  Draft or revise RWP functional-contract records from RWB program-specification rows for a data
  product under products/, for any tumour. Produces the canonical contract table row,
  proposes the source mapping
  only from identifiers the spec names, and raises a decision instead of inventing anything the spec
  leaves open. Use this whenever the work touches FUNCTIONAL_CONTRACT.md or the spec behind it —
  converting a spec row or tab into contract records, adding or changing a variable, revising a
  record after a spec revision, working through decision_required records, or auditing whether the
  contract still matches the spec. Operates in REVIEW / DRAFT / APPLY modes, chosen from the user's
  instruction and defaulting to REVIEW when unclear, so an audit never writes to a governed file.
  Reach for it even when the user does not say "contract record":
  phrasings like "add AGE to the product", "the spec changed, update it", "convert the demos tab",
  "why is this variable blocked", or "does the contract match the spec" are all this skill.
---

# Drafting a functional-contract record

Three files. **This one governs the run.** `REFERENCE.md` holds the vocabularies, field meanings and
worked records you look things up in. `EVAL_RATIONALE.md` holds the measurements behind the rules —
read it to judge whether a rule is worth following, never to find out what to do. Counts live there
because a count embedded in an instruction goes stale silently, and one already did.

## Before anything else: which mode are you in?

This skill covers both **auditing** a contract and **authoring** one, and those need different
permissions. Decide the mode from the user's instruction, and say which one you picked in your first
sentence. Never infer permission to write from the fact that you are able to.

**The permission is about the REPOSITORY, not about whether any file is written at all.** Writing a
report into an output directory the user named is harmless; editing `DECISIONS.md` during a review is
not. Those are different acts and only the second one is what a mode restricts.

| Mode | The repository | The output location the user named |
|---|---|---|
| **REVIEW** | **read-only** — no edit to the contract, `DECISIONS.md`, `SPEC_QC_FINDINGS.md`, `spec_dispositions.yaml`, `MATURITY.yaml`, `spec_pipeline/out/` or `config/` | may write the report you were asked for |
| **DRAFT** | **read-only**, same list | may write proposed records, decision entries and findings |
| **APPLY** | the named pack is writable | as DRAFT — but never a maturity level, never marking a decision RESOLVED, never any human-only status |

**Prove it, do not assert it.** In REVIEW and DRAFT, run this before you start and again before you
report, and put the result in your report:

```bash
git status --porcelain <pack>          # must be byte-identical, before and after
```

That is the whole check, and it is why it is here rather than in prose about intentions. A mode
recorded only in a first sentence is a claim; an empty `git status` is evidence.

**Choosing:**

- The user asks to check, audit, review, compare, or "look at" something → REVIEW.
- The user asks for a record or a draft to be produced → DRAFT.
- The user explicitly asks to add, update, convert or fix something **in the pack** → APPLY.
- **Unclear → REVIEW, and say so.** Producing a report when the user wanted a commit costs one
  message. Writing to a governed file when the user wanted a report costs a governed file.

**"Do not make changes" outranks everything else.** It selects REVIEW even alongside a phrase that
would otherwise read as APPLY, and being asked to write your report to a named file does NOT promote
a review into DRAFT — the report is the deliverable, not a change to the pack.

"Review this in detail" is REVIEW **even when you find something obviously worth fixing.** Report the
fix; do not make it. A found problem is not a mandate.

Every instruction below that says to WRITE something — add a decision entry, record a QC finding,
paste a record into the contract — is an APPLY-mode instruction. In REVIEW you report what you would
have written; in DRAFT you write it to the output location instead of the pack.

Read only what the assigned scope needs, and only what is AI-eligible — the boundary in
`governance/WORKFLOW.md` §"Eligibility" applies in every mode, and REVIEW is not a licence to open
vendor material.

## The authority model, because it explains every rule below

```
approved RWB specification  →  FUNCTIONAL_CONTRACT.md  →  config/ + variables/  →  engine
        (evidence)                 (the requirement)        (the implementation)
```

The spec is **evidence**, not a build input. The contract states **what must be true**. The YAML is
**what runs**. You are working in the middle layer, so two things follow: never edit a record to match
what the code happens to do, and never let a record assert something the spec did not say.

The functional contract is the **governed requirement**: one record per row of the approved RWB
specification, each traceable back to its numbered row. It is the artifact RWB and RWP sign, and the
instruction set RWDE builds from. Read `governance/WORKFLOW.md` for the full process; this skill is
its Gate 2 drafting step.

Your job is to draft records **faithfully** — and, just as importantly, to leave visible everything the
specification does not actually answer. A record that quietly fills a gap looks finished and is worse
than one that is honestly blocked, because nobody will ever go back and check it.

## Start from a slice, not the whole pack

```bash
python3 platform/tools/spec_slice.py <pack> --domain <domain> [--variable <VAR>]
python3 platform/tools/spec_slice.py <pack> --domain clinical --item clinical:61
python3 platform/tools/spec_slice.py <pack> --domain clinical --item clinical:61-108
```

`--item` is repeatable and takes a single row or a range, parsed by the same expander the contract lint
uses. Prefer it on clinical and treatment, where `--domain` alone is too wide and `--variable` too
narrow — and where a name can match several rows, which the slicer refuses rather than guessing at.

That is the intended starting context for one drafting unit. It gives you, for that domain only: the
spec rows with their fields resolved, the deterministic lint findings for exactly those rows, the
scaffold's starting point, a compact index of the pack's decisions, **the QC findings recorded against
your rows**, **the gaps cited by the records on them**, the declared config source keys (or the
statement that there are none), **the records that already cite those rows in full**, and **each row's
disposition** so you can see whether a row is already mapped or deliberately excluded.

It also carries the workbook columns this framework has no canonical field for — `Origin`, `Status`,
`Owner`, `Evidence`, `Open decision`, a per-revision delta column — printed under the row as
*(unmapped column)*. That is often where the spec records that a rule is still `first-pass [verify]`
or `ADDITIVE (not in prior spec)`. Which columns exist differs per workbook, so read the ones your
slice shows rather than looking for a fixed set.

**Read the three indexes before raising anything.** A question already in `DECISIONS.md`, a defect
already in `SPEC_QC_FINDINGS.md`, a shortfall already in `ENGINE_GAPS.md` — reuse the id. Two ids for
one thing is invisible to any single reviewer, because both entries look correct.

The slice also reports **register citations that resolve nowhere**: a `Spec ref` naming a sheet this
pack's extraction does not contain. That is a defect in the REGISTER, and it means a recorded finding
is attached to no row at all. Report it; do not guess which row was meant.

The slice REFUSES to run unless the pack passes full Gate 1, its three pipeline artifacts carry one
matching extraction fingerprint, they are current against the source, **and the pack's SANITIZED
EXTRACTION is registered and approved for AI use.**

That last one is the whole gate, and it is not the classification on the SOURCE. What you read is
`spec_pipeline/out/extracted.json` — a derived artifact from which vendor documentation has been
redacted. It is registered in `source_refs.yaml` as `material_type: ai_extraction`, at
`status: reviewed`, classified and approved by a named person, and bound to the exact bytes, the
extraction run, the redaction policy and the counts a reviewer was shown. The class recorded on the
workbook or its stand-in says nothing about that file: a sponsor-authored specification can quote a
vendor's documentation, and the packs this check was built against had inputs recorded
`sponsor_ai_eligible` while demonstrably containing vendor prose (`EVAL_RATIONALE.md` §2 has the
count).

**No tool may grant that approval** — giving it is a person's act, and `--register-ai-extraction`
prints the block to sign rather than filling it in. Some packs carry one and some do not, so never
assume either: run the slice and read what it says. A pack without the approval is refused and told
why; a pack with one slices normally. `source_manifest.py --ai-boundary <pack>` lists any vendor
documentation still in the file.

**Vendor TABLE and COLUMN names are not what this checks.** Naming
`Enhanced_MetProstate.MetDiagnosisDate` is what a contract is FOR, and "From Flatiron, we receive the
earliest date of evidence" is a sponsor verdict about the feed — verdicts cross the boundary, contents
do not. What is refused is reproducing the vendor's own prose: `Per Knowledge Center, (see Article
"…") TestResultCleaned is provided when…`. If you hit this, do not paraphrase the vendor more
carefully — state the sponsor's conclusion and cite the restricted evidence by reference, or raise it
for reclassification. There is no override flag: a task instruction is not an approval mechanism.

For STYLE, `--style-records N` gives neighbouring records as REDACTED SKELETONS — field order,
container shape and punctuation, every answer-bearing value replaced by `…`. Off by default, and
structural rather than a rule you have to follow.

The records that already cite YOUR rows arrive in full under "Records already citing these rows". Those
are the subject of the work: revise them, do not duplicate them. If a row shows `disposition: mapped`,
drafting a second record for it is an error.

**The slice is a starting point, not a guarantee of sufficiency.** If the record you draft names a
dependency whose DEFINITION lives in another domain — an index date, a cohort, a follow-up endpoint —
say so and ask for that domain. Do not reconstruct it from the name.

## Before drafting: read the actual spec row

Every record cites its source rows as `spec_refs`, in the form `<domain>:<row>`, where the number is
the **source coordinate** — the Excel row for a workbook, the file line for a per-tab `.md` or `.tsv`.
Either way it is a place a person can open and count to, which is the property that makes a citation
checkable.

**Cite the canonical DOMAIN, never the workbook's tab label.** Tab labels differ per product and per
revision — two packs' demographics sheets are spelled differently in `governance/spec_sheet_map.yaml`
today — which is why the extraction maps every sheet to one of six stable domains:

    study_period · study_population · demographics · clinical · treatment · outcomes

`spec_pipeline/out/extracted.json` contains those domains and nothing else, so a tab label resolves
nowhere. Read the tab to understand the row; cite it as `demographics:<row>`.

The same file's `ignored:` block names the sheets that carry NO requirements — cover, change log,
review decisions, source register, **worked examples**, **vendor reference**. They are dropped
deliberately, not overlooked, and listing them is what makes an UNKNOWN sheet detectable. So being
pointed at a worked example or a review-decisions tab is being pointed at something no record can
cite: use it to understand a rule, cite the requirement row that states the rule, and if the rule
exists only on an ignored sheet, that is a finding rather than a citation.
`governance/SPEC_DOMAINS.md` is the authority on which sheet maps to which domain, and
`spec_sheet_map.yaml` is the mapping itself — read your pack's entry rather than assuming a spelling.

**The ROW NUMBER does not transfer either.** The same variable sits at a different coordinate in
every pack, so an item id carried over from another product is wrong even when the domain is right.
`--item` refuses an id the pack does not have and lists the ones that exist, which is a check only if
you are pointing it at the pack you were actually asked about.

Read the row before writing anything, and watch for `(cut off...)`, `(fragment...)`, `[verify]`,
bracketed placeholders and impossible values. **A truncated cell is unknown, never "not required."**

**How much of this applies depends on what the pack's registered input actually is** — check
`source_refs.yaml` rather than assuming. A pack extracting the approved `.xlsx` carries the workbook's
own defects and nothing else. A pack whose registered input is a per-tab stand-in for the workbook may
also fall short of it — a rule the stand-in does not carry, or one it states less precisely than the
workbook would — because nobody has attested the stand-in matches the approved specification. For those
packs, treat "the spec says nothing about X" with suspicion; for a workbook-backed pack, that
suspicion is unfounded and raising it as a finding wastes an RWB round-trip.

## The rows the spec does not settle are already marked — read the marks

**This is the single largest source of bad records, measured** — see `EVAL_RATIONALE.md` §1 for the
count and how it was obtained.

A deterministic pass (`spec_lint`) marks every row it cannot read as settled. You see the marks in
`spec_pipeline/out/SPEC_FINDINGS.txt` and in the scaffold's row notes, printed under the record you are
drafting.

### The four kinds that mean "the specification does not contain the answer"

| Kind | What it means |
|---|---|
| `VERIFY_MARKER` | the spec author left an explicit confirm/verify marker on this row |
| `PLACEHOLDER` | prose sits where a rule should be — `[verify exact figures]`, `[masked in the source]` |
| `TRUNCATED` | the cell is cut off in the source; the rest of the rule is not recoverable from this document |
| `NO_TERMINAL_ELSE` | an if/else-if chain with no final else, so some input is left undefined |

`contract_lint.UNSETTLED` is the authority for that set.

**Judge by KIND, never by severity.** `VERIFY_MARKER` and `PLACEHOLDER` carry severity INFO and still
mean the answer is absent; `UNBALANCED` and `OUTLIER_IN_LIST` are HIGH and mean the row looks
internally inconsistent, not that the spec is silent. Reading severity as the question is what produced
the measured failures.

### The rule, which the CI lint enforces as I17

> A record citing a row flagged with one of those four kinds must leave the unresolved field `TODO`,
> **or** name a `decision_ids` / `gap_ids` entry. Answering it with neither is a hard failure.

There is no third option, and "the answer is obvious from the sibling row" is not one of them.

### A flagged row is often PARTLY settled — split it, do not refuse it

The most common wrong response after inventing is over-refusing. A row can state some things clearly
and leave others open, and the record should follow that split exactly.

Worked example — a real `study_period` row defining `DAYS_PER_MONTH`, flagged `PLACEHOLDER`, its two
halves reproduced as the extraction gives them:

```
Days to months conversion: assuming 30.4375 days per month. 3 months = 91 days,
6 months = 183 days, [9] months = 365 days
(cont. right half) 3 months = 91 days, 6 months = 183 days, 9 months = 274 days, 12 [months]
[verify exact figures]
```

* **Stated, so carry it:** `30.4375`, `3 months = 91 days`, `6 months = 183 days` — both halves agree.
* **Open, so refuse it:** 9 months (`365` against `274`) and 12 months (cut off in both halves).

The record carries the three settled values, leaves the two open ones out of its asserted rule, sets
`status.requirement: decision_required` and cites the decision. Carrying all five would be invention;
refusing all five would discard requirements the spec does state.

## How a record is produced

**You write the JUDGMENT fields. You do not write the row, and you do not write the evidence.**

```bash
python3 platform/tools/contract_record.py judgment.yaml \
    --product <pack> --item <domain:row>
```

Three things that used to be yours are now the tool's:

1. **The row.** Field ORDER, escaping a literal `|`, folding embedded newlines, and producing exactly
   the right number of cells. Every field is re-parsed out of the rendered row through the same parser
   every gate uses and compared byte-for-byte with what you supplied.
2. **The evidence.** `--item` supplies `spec_refs`, `spec_digest` and `required_rule` from the pack's
   extraction. **Putting any of them in your judgment file is an ERROR**, not an override — the tool
   refuses and names them. Retyping a digest fails I15 loudly; tidying `required_rule` into better
   English fails nothing at all and quietly replaces the spec's words with a paraphrase. Only one of
   those two is survivable, which is why neither is yours to write.
3. **The invariants.** `--product` runs the real lint against that pack, so a record that would fail
   Gate 2 — I8, I15, I17, the I2 decision and gap references — says so before it reaches a governed
   file. All eighteen are in `REFERENCE.md` §"The invariants", with what each asks of a drafter
   rather than what it checks; the four that shape a fresh draft are **I17** (an unsettled row stays
   visibly unresolved), **I19** (`implementation_refs` is answered), **I18** (`pending_mapping`) and
   **I11** (`decision_required` iff an open decision).

`--product` AND `--item` are both REQUIRED for any pack that has an extraction. Leaving `--item`
optional left the whole evidence boundary opt-in: `--product` alone accepted a hand-written
`required_rule`, and only a wrong DIGEST would have failed. `--format-only` renders without a pack and
skips every check; `--legacy-no-extraction` is the named path for a pack that genuinely has none, and
is refused for a pack that does.

**Two more things the tool now refuses, so they are no longer yours to remember:**

* **`status` — do not write one.** The tool settles it: a NEW record gets
  `contract_record.INITIAL_STATUS` (`requirement: draft, source: unverified, implementation:
  not_implemented, validation: not_run`), and a REVISION keeps whatever the existing record holds. A
  draft carrying a `status` is refused, not silently overwritten. Every value you might have wanted
  to write is an evidence claim — that a test ran, a dictionary was read, a profile was reviewed —
  and you have read a specification row, not run any of those (REFERENCE.md).
* **A row flagged `VENDOR_REDACTED`** — its rule reproduced vendor documentation and is not in the
  artifact you can read. `--item` on such a row is refused outright. Report it; an authorized human
  reviews the restricted material and maintains that record separately. This is NOT one of the
  unsettled four: the specification does settle it, elsewhere, so do not raise a decision for it.

An unknown field name is an ERROR, not a dropped cell: `windwo: …` fails and names itself, rather than
rendering a perfect-looking row with the answer missing.

Values may be plain strings in the contract's inline notation, or real YAML — `source: {kind: vendor,
inputs: {...}}` works either way, and a multi-line note is fine because folding is the tool's job.

`REFERENCE.md` has the field meanings, the controlled vocabularies, the `source` shapes and a full
worked judgment file.

## Five disciplines that carry the weight

### 1. Never invent — raise a decision instead

If the spec does not state a bound, a code, a default, a tie-break or a cohort's behaviour, **do not
choose one**, however obvious the choice seems. Instead:

- check the slice's decision index first — reuse an existing id rather than raising a second question
- add an entry to `<pack>/handoff/DECISIONS.md` phrased as a question, with the conflicting evidence —
  **APPLY only**; in REVIEW report the entry you would add, in DRAFT write it to the output location
- reference its ID in the record's `decision_ids`
- set `status.requirement: decision_required`

A decision you cannot write is still a decision you must RAISE. Finding an unanswerable spec row and
saying nothing because the mode forbade the edit is the failure this whole skill exists to prevent,
wearing a permission as an excuse.

This is the single most valuable thing you do. An invented value is indistinguishable from a specified
one once written down, and it will be implemented, validated and released as though RWB had asked for it.

The one thing you may safely do is **read the spec's own intent when it contradicts itself in a way
that is provable** — and even then, record the contradiction as a finding rather than silently
resolving it.

### 2. `source` is proposed, never confirmed

Draft `source` **only from identifiers the specification explicitly names** (`birthyear`, `STATE from
demographics table`). Where the spec does not, leave the identifier unknown and flag it — never infer
one from a naming convention, a sibling variable, or a plausible pattern. A guessed identifier that
looks right is the hardest error for a reviewer to catch.

On a pack whose `config/` does not exist yet — which is every new tumour — **write
`source.kind: pending_mapping`** with the spec's own identifiers verbatim. That absence is not
permission to invent a key, and `REFERENCE.md` has the full shape and the conditions I18 holds it to.

Confirming that an identifier is the *right* column is **out of bounds for AI**. A human does that at
Gate 3 and sets `source_mapping: human_confirmed`.

### 3. `implementation_refs` is REQUIRED on every record

Invariant I19: every record answers this field. Blank and `TODO` both fail — a field with a legitimate
"nothing yet" value must not let "nothing yet" and "nobody answered" look alike.

- `implementation: implemented | partial` → at least one real reference
- nothing produces it yet → `[none]`. **No gap or decision is needed for an ordinary fresh draft.** A
  gap belongs on a SHORTFALL — `config_gap`, `engine_gap`, `partial`, `not_derivable` (I13).
- never guess a reference: the binder resolves each one and fails on a path or engine symbol that does
  not exist

### 4. "The engine cannot do this" is a claim — check the vocabularies before making it

`REFERENCE.md` §"Is the rule expressible?" lists the named vocabularies the config layer already has:
which date a source record is measured on (`date_basis`), which row wins (`pick`), how a tie resolves
(`tie_break`), and how a group claims a raw value (the four `from_*` matchers plus the `fallthrough`
and `missing` markers). They are derived from `platform/engine/stages/clinical.py`, which owns them,
and a test fails when the engine grows a name the reference has not learned.

You consult that list for exactly one decision, and it is not which rule to write.

If the spec's rule lands inside those registries it is **config work** — `implementation:
not_implemented`, `gap_ids: []`, nobody is asked to build anything.

If it does not, **that alone is not an `engine_gap`.** The engine is the LAST thing to suspect: an
unsettled rule is `decision_required`, an undelivered field is `not_derivable`, an external code
table is a Gate 1 material to register. Only a rule that is clear, whose data is there, and which no
operator can express is a shortfall. `REFERENCE.md` §"Is the rule expressible?" has the order to work
through.

Both errors cost. Raising a gap for a capability that shipped puts a phantom on a roadmap and burns a
reviewer's afternoon proving it is already there. Writing a rule as though it were already configured
when no operator expresses it hides the shortfall completely: the record reads finished, and the
variable quietly is not built.

**Naming the operator is not your job and picking one is inventing.** The record states the rule the
spec states; the vocabulary tells you whether that rule is buildable today. Where the spec's words map
onto a named operator unambiguously, say so in `notes` as your reading — not in `derivation` as the
requirement.

### 5. Summarize in the contract; enumerate in the YAML

Where a rule involves a long value set — a state-to-region map, a drug category list, a lab panel — the
contract's `derivation` **names the rule** and the YAML **carries the values**: `"STATE→region map
(codes 1-5, PR→Other region); state null→6"` in the record, the fifty states in `variables/*.yaml` or
`codelists/*.yaml`. This keeps the signed document readable and one rule in one place.

That is the *values*, not the *records*. Write **one record per spec row** — `spec_refs` names exactly
one row (I16). Where thirty lab rows share a rule, each still gets its own record carrying that rule,
its own tie-break, its own units and its own approval; a range like `clinical:17-46` on one record is
what I16 refuses at `contract: approved`, because a family record is a list, and a list is where the
next tumour's new analyte goes missing.

## Recording what the spec got wrong

Drafting is also the specification QC pass. Both registers below are governed files, so **writing to
either is APPLY only**; in REVIEW you report the entries, in DRAFT you write them to the output
location. What never changes with the mode is that you FOUND it and said so.

- **`DECISIONS.md`** — open *questions*. The spec is silent or ambiguous; someone must decide.
- **`SPEC_QC_FINDINGS.md`** — *defects in RWB's document*. Impossible values, internal contradictions,
  wrong-tumour table references, bracketed placeholders, duplicated variable IDs.

Check the slice's indexes before adding to either. Findings that trace to the stand-in rather than to
RWB — something the stand-in omits or states less precisely than the approved workbook would — belong
in the findings register too, but marked as such: they resolve by extracting the approved workbook,
with no RWB round-trip. They can only arise on a pack whose registered input is a stand-in; a
workbook-backed pack has no such class.

A **workaround is not a correction**. If you read `4/31/2026` as `2026-04-30` to unblock a build, the
finding stays open, because re-extraction will reintroduce it.

## What this skill does not do

- **Never read vendor material** — data dictionaries, delivered data, schema dumps, profiling output.
  Scripts and humans may; AI may not. Draft from the sponsor's spec only.
- **Never flip a status to a confirmed value.** Initialize `requirement: draft` (or
  `decision_required`), `source: unverified`, `validation: not_run`.
- **Never answer a methodology question** — study windows, index rules, outcome definitions,
  tie-breaks, clinical grouping. Detect and phrase them; let RWB/BIO decide.
- **Never rename** a published or physical name; naming is a governed decision.

## Verify before you finish

```bash
python3 products/<area>/<tumor>/<version>/handoff/tests/test_functional_contract.py
git status --porcelain <pack>        # REVIEW/DRAFT: must be empty
```

The shared lint (`platform/tools/contract_lint.py`) enforces every invariant it currently defines. The
citation checks (I8, I15) are the ones that catch a hallucinated or stale reference, so treat a failure
there as a real signal rather than a formatting nit.

Then report plainly: the mode you selected, what you drafted, **what the tool said**, what you could
not resolve and why, and any spec defects found.
