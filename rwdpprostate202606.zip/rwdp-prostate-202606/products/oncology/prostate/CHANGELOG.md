# Prostate RWDP — changelog

Spec lineage for the `mcrpc` data product. Each version is a governed contract; the data refresh
(`{snapshot}`) is orthogonal (same spec, new Flatiron cut). See `registry.yaml` for the machine lineage.

## 202606 — mHSPC + mCRPC dual-setting expansion  *(current)*

The 7-cohort expansion of the original mCRPC-only product, on the Flatiron Prostate **Panoramic** feed.

- **Cohorts (COHORTN 1–7):** Overall mHSPC, Overall mCRPC, L1+ mHSPC, L1+ mCRPC, L2+/L3+/L4+ mCRPC —
  with per-setting treated/untreated `COHORTU`/`COHORTUN`. mHSPC cohorts anchor on `hspc_diagnosis_date`;
  mCRPC cohorts on `advanced_diagnosis_date` (= `pmax(metastatic, CRPC)`).
- **Configured variable set** (provisional — not yet live-validated; several RWB-required outputs + decisions still pending, see `202606/handoff/` and `202606/handoff/ENGINE_GAPS.md`): HRR/BRCA biomarkers (priority aggregation, gene- or summary-level via `match_any`),
  closest-to-index labs (`Present/Unknown/Missing`), metastatic-site flags, PSA timepoints + PSA50/undetectable
  response, the diagnosis **year/duration family** (`indexyr`, `inityr`, `mcrpcddyr`, `mpcddyr`, `pinddur`,
  `fudur`, `pfudur`, `mcrpcdd`), BSA, rwPFS (clinic-note-gated) + TSST, prior-treatment + conmed exposure
  flags, and per-line LOT detail (`lot{i}` … `lot{i}dur`/`lot{i}cat`).
- **Categorical fallback code = `99` (CODE-ALIGN — set by RWP; RWB to confirm).** The **demos-tab** categorical
  `fallthrough` bucket is standardized to code `99`: `AGEGR1N` (Unknown), `REGION1N` (Unknown/unmapped
  non-null state), `RACEN`, `ETHN` (`PRACTICN` was already `99`). `99` means the **categorical fallback —
  unknown / missing / unmapped / out-of-range** (a `fallthrough` is a general ELSE, not null-only). These are
  config-inferred because the demos-tab "Values" columns were hidden (not ), so they are an RWP
  standardization to be RWB-confirmed. **Corrected — NOT 99:** the clinvars-tab codes are present in the spec,
  so `BMIGR1N` Missing = `5` and `HRR_INDEXN` / `BRCA_INDEXN` Unknown/Not documented = `4` (`clinvars.md` rows
  62 / 71 / 75) — the engine now uses those. **Left distinct by design:** `REGION1N` null-state `Missing = 6`;
  `ECOGN` documented `Unknown = 6` / `Missing = 7`; `STAGEN` `CHECK = 99` (QC surfacer, not missing).
  **Continuous** variables keep missing as `null` (never `99`). Differs from 202603, which retains the
  pre-alignment codes (8/7/5/3/4) — versioned packs preserve prior contracts.
- **Configured output table:** `rwdp_pros_pano_202606` (not yet a governed release).  **Supersedes:** 202603.
- Governed source of the contract is the 202606 program-spec (the approved RWB workbook — see `202606/source_refs.yaml`); the reference R script (`rdap.pdf`) is the prior implementation that derivations were cross-checked against, not the authority.

## 202603 — original mCRPC product  *(superseded)*

- mCRPC-only: Overall + L1/L2/L3 mCRPC line cohorts, anchored on `advanceddiagnosisdate`.
- Configured output table: `rwdp_pros_pano_202603`.
- Reference: the original RDAP R script in the original prostate RDAP script
  (`coh_list = c("overall","lot1","lot2","lot3")`) + `prostate_rdap.py`.
- **Now a FAITHFUL buildable pack** at `202603/` (reconstructed from the 202606 pack + `prostate_rdap.py`):
  cohorts/index/output = the authentic v1 contract, and the variable packs are pruned to the pre-expansion
  scope — **76** emitted variables vs **153** in 202606; the 202606-added families (HRR/BRCA, labs, PSA
  timepoints, metastatic sites, year/duration, BSA, rwPFS/TSST, conmed, generic prior-treatment,
  setting-suffixed LOT) are removed. Build with `--var spec_version=202603`; coexists with 202606
  (separate table + spec-versioned ledger). Like 202606, needs the real-data smoke + verify-vs-source.
