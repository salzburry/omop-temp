# Prostate RWDP — spec-versioned (v1 `202603` · v2 `202606`)

A **locked PySpark engine + YAML config**, runnable on Databricks. This product keeps **one config pack
per spec version**, so each contract is independently buildable, diffable, and auditable:

- **`202606/`** — **v2, current/active**: the 7-cohort **mHSPC + mCRPC** dual-setting expansion → `rwdp_pros_pano_202606`.
- **`202603/`** — **v1, superseded but buildable**: the **original mCRPC-only** product (Overall + L1/L2/L3) → `rwdp_pros_pano_202603`.

See `CHANGELOG.md` (lineage) + `../../registry.yaml` (`current_spec_version`, lineage). *Code locked, config
driven* — what an analyst tunes lives in each version's `config/`, `variables/`, `codelists/`; every change
is a reviewed Git diff.

## Layout (trace & audit by version)

```
README.md  CHANGELOG.md           product-level: overview + version lineage (span all versions)
prostate_rdap.R / .py            the original R-script reconstruction (the v1 derivation reference)
202606/                           v2 — the CURRENT contract (resolver default)
  config/data_product.yaml        run params, study window, 7 cohorts, source-table map
  variables/  codelists/          tunable derivation params + the lotcat 17-way classifier
  source_refs.yaml  DEV_SMOKE.md  per-version provenance + the dev-smoke runbook
202603/                           v1 — the original mCRPC-only contract (4 cohorts), same shape
  config/  variables/  codelists/  source_refs.yaml  README.md

# The engine + Databricks bundle + tests are SHARED across tumors (../../../platform/, ../../../databricks.yml).
# Build a specific version:  --var spec_version=202606   (or 202603 for v1) on job rwdp_build_prostate
# The engine resolves the version folder from `current_spec_version` (registry) unless you pass spec_version.
```

> **Trace/audit:** each version is a separate config folder (diff `202603/` vs `202606/`), with its own
> `source_refs.yaml`, its own `refreshes/oncology/mcrpc/<spec_version>/…` manifest ledger and
> `releases/…/<build_id>/` evidence, its own row `spec_version` stamp + output table, and its
> `registry.yaml` lineage entry. "Go back to v1" = `--var spec_version=202603`.

## What maps to what (R → here)

| R script | Here |
|---|---|
| `refresh`, `dbname`, `personal_schema`, output table | `config/data_product.yaml` → `run:` |
| `index_start` / `index_end` | `study:` |
| the original `coh_list = c("overall","lot1","lot2","lot3")` → 202606's 7 cohorts (overall/L1+ mHSPC; overall/L1+/L2+/L3+/L4+ mCRPC) | `cohorts:` |
| `pmax(MetastaticDiagnosisDate, CRPCDate)` | `index_dates.advanced_diagnosis_date` |
| the 16 `t_*` table reads | `sources:` (resolved to `{schema}.<stem>_<refresh>`) |
| age bands, region/race/practice maps | `variables/demographics.yaml` |
| ECOG window, BMI/BSA, stage, death imputation | `variables/clinical.yaml` |
| `lotcat`/`lotcatn` 17-way `case_when` | `codelists/treatment_categories.yaml` |
| `id3mosfu`/`vis120`/OS/TTD/TTNT | `variables/outcomes.yaml` |
| `index_lot_cohort`, `demographics_variable_addn`, `clin_char_master`, `trt_var_creation`, `outcomes_tbl_var`, `overall_ads_creation` | `../../../platform/engine/stages/*.py` (locked, shared) |

## Run it

Local (no Spark needed) — engine + tests live in the shared framework; install PyYAML and use
`python3`:

```bash
pip install -r ../../../platform/requirements.txt
python3 ../../../platform/engine/validate.py 202606/config/data_product.yaml   # lint v2 (or 202603/… for v1)
python3 ../../../platform/tests/test_config.py     # engine vs the reference tumor (prostate, current spec)
python3 ../../../platform/tests/test_registry.py   # every spec-version pack lints clean
```

On Databricks: each product has its OWN generated job (`rwdp_build_prostate`) with its own schedule,
schemas and activation state — there is no shared `rwdp_build` job and no `tumor_slug` variable any
more, because one job parameterised by a slug is not a portfolio.

**The deployment sequence is written down once, in the header of `../../../databricks.yml`.** Deploy
from the tree `platform/tools/deploy_tree.py` generates, not from the checkout: a prod run without
that tree's `RELEASE_EVIDENCE.yaml` refuses to publish.

```bash
databricks bundle run rwdp_build_prostate -t dev \
    --var prostate_refresh=2026q1 \
    --var prostate_source_schema=... --var prostate_output_schema=...
```

A new snapshot is `--var prostate_refresh=2026q2`; a different product is its own job.

Side-by-side on the **R engine** (same config, for the R-proficient team) — a *validation* path, not
the governed lifecycle: it writes directly, so target a **separate `_r` schema**, then golden-compare
against the Python ADS. From a Spark-connected R session (Databricks, or Domino→Databricks via sparklyr):

```bash
Rscript ../../../platform/engine-r/run_rwdp.R --allow_direct_write=true \
    --config_path=202606/config/data_product.yaml \
    --refresh=2026q1 --source_schema=... --output_schema=..._r
```

Golden-compare by re-running the Python build with `--var reference_table=<the _r table>`. Full
Domino→Databricks (sparklyr) detail + caveats: `../../../platform/engine-r/README.md`.

## Status

**`active`** in `registry.yaml` and this config (and the variable packs + codelist) — the reference
pack the engine is validated against (config + dotted overrides, the codelist→Spark-SQL compiler with
R↔Python parity, the validator + source preflight, the orchestration, all green). It produces the
**configured ADS end-to-end** (synthetic data) (7 cohorts; demographics, baseline ECOG/BMI/BSA, stage/Gleason, HRR/BRCA,
metastatic sites, labs, PSA timepoints + response, diagnosis year/duration family, death/follow-up
anchors, the LOT line model + categories, prior-treatment + conmed flags, OS/rwPFS/TSST, …). Several RWB-required outputs + methodology decisions remain pending — see `202606/handoff/`. It has
**not yet been executed on a cluster**, so the FIRST run should be a dev
**smoke test**, then a **governed prod release** once you have a golden reference — **which
cannot currently complete**: a prod run stops at Gate 6 awaiting a named approval of that build,
and no promotion-only path resumes an approved candidate. See `products/OPERATIONS.md`.

```bash
# dev smoke test (golden may skip; deliverables optional)
databricks bundle run rwdp_build_prostate -t dev \
  --var prostate_refresh=<snap> --var prostate_source_schema=<src> --var prostate_output_schema=<out>

# governed prod release — deployed from build/deploy (see databricks.yml). git_commit must be the SHA
# deploy_tree.py stamped the tree with; git_commit + reference_table are REQUIRED (or a waiver, which
# cannot publish).
databricks bundle run rwdp_build_prostate -t prod \
  --var prostate_refresh=<snap> --var prostate_source_schema=<src> \
  --var prostate_output_schema=<out> \
  --var git_commit=<the tree's commit> --var prostate_reference_table=<known-good ADS>
```

- Wired and tested (no Spark): config + dotted overrides, the codelist→Spark-SQL compiler, the
  validator + source preflight (`../../../platform/engine/validate.py`, run before every build), the orchestration.
- Wired + Spark tests (exercised by local synthetic Spark smoke; real Databricks/Panoramic still required): sources, the shared LOT stage
  (`new_lot_n`), index/cohort, baseline ECOG (incl. "Unknown" vs "Missing"), the full death-date +
  follow-up-end anchors (`dthdt/dthfl/fued/dthfufl/dth_before_fued`, mortality reduced to one row
  per patient via a config-selectable conflict policy, year-level deaths imputed index-aware so
  they can't precede the index), OS, demographics (age/race/ethnicity **+ region, practice, SES**),
  **stage** grouping, **BMI/BSA** (vitals), treatment categorization, the treated/untreated split,
  the spec stamp. The Databricks job declares PyYAML as a cluster library so config parsing can't
  fail on a bare runtime.
- **Wired** — lot banding, mCRPC flag, PSA, Gleason; **vis120 / TTD / TTNT / trtdis** (`outcomes.py`,
  config `line_outcomes:`); and **prior_tax_mcrpc** (`treatment.py`, cohort-aware) — all proven
  byte-identical to the R in `tests/test_r_parity.py` — that test compares the config→SQL
  COMPILERS, not the stage dataflow (reads, joins, windows, aggregations), which is not
  compared. These add columns; they don't gate the build.
  `prior_tax_pre_mcrpc` is engine-ready but emitted only once the pre-mCRPC line source is declared
  (`prior_taxane.pre_mcrpc_source`). OS is optional — omit `overall_survival` to skip it.

`REPLACE_ME` in `config/data_product.yaml` and `../../../databricks.yml` are the only environment-specific
values to fill; the validator (strict mode) rejects a run while they remain.

Spark in-memory tests (`../../../platform/tests/test_stages_spark.py`) cover the treated/untreated split,
deterministic `new_lot_n`, index windowing, baseline-ECOG Unknown/Missing, the death/follow-up
anchors (incl. mortality dedup + `dthfufl`), treatment categorisation, OS and the spec stamp. The
registry-driven `test_smoke_spark.py` also builds the configured ADS (incl. the production
`build_from_sources` union path) for every tumor on synthetic data. **Local synthetic Spark smoke is
supported and has been run** (pyspark in a venv); the real Databricks/Panoramic smoke is still required.

The source **preflight** (table + required-column existence, run before the build) is wired into
`../../../platform/engine/validate.py` and the notebook. It is a schema gate only — it does not check semantic
compatibility.

Now built on top of it (pure-Python cores tested; Spark execution is cluster-only):

- a **semantic QC layer + publish gate** (`../../../platform/engine/qc.py`): date-castability,
  mortality granularity + duplicate-conflict counts, unmapped stage values, unmatched treatment
  names, and null-rates — gating publish via temp-then-swap (a bad refresh never overwrites the ADS);
- a **golden-comparison harness + gate** (`../../../platform/engine/golden.py`) against the original R
  ADS for a known refresh (row/cohort counts, `lotcat`/stage/ecog/race distributions, OS summaries,
  column-set diff);
- production bundle hardening (`../../../databricks.yml`: per-env schemas, notifications, retries, cluster
  policy, Unity Catalog, write-to-temp-then-swap). NOTE: `databricks bundle validate` + the first
  cluster run still need the Databricks CLI on a real workspace — they can't be run in this sandbox.
