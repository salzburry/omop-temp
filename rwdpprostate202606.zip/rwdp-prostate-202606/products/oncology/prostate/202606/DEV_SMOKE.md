# Prostate 202606 — Databricks dev-smoke runbook

The point of this run: move prostate from **asserted** (unit tests + R-parity pass; never executed on a
cluster) to **verified** (a real ADS builds end-to-end on real Flatiron/Panoramic tables). Static review
won't get there — this run is what does. Needs a Databricks workspace with the Panoramic source schema.

Identity for this product (from `config/data_product.yaml` + `../../../registry.yaml`):

| | |
|---|---|
| job | `rwdp_build_prostate` (generated from the registry; PAUSED until activated) |
| product | slug `prostate` · registry code `mcrpc` · family `oncology` |
| spec_version | `202606` (CalVer) · data cut = `--var prostate_refresh=…` |
| output ADS | `<output_schema>.rwdp_pros_pano_202606` |
| cohorts (7) | overall_mhspc · overall_mcrpc · lot1_mhspc · lot1_mcrpc · lot2_mcrpc · lot3_mcrpc · lot4_mcrpc |

---

## 0. Validate source naming FIRST (cheapest failure to hit)

The config runs on **EDM-normalized lowercase logical names**. If Panoramic ships different
physical names, the **preflight** fails fast (a schema gate, by design) — better to know before a
cluster spins up.

**Generate the SQL with every name already filled in** — no hand-substitution, and it prints what
the engine expects back so you can compare rather than eyeball:

```bash
python3 platform/tools/source_preflight.py products/oncology/prostate/202606 \
  --refresh <snapshot> --source-schema <catalog.schema>
```

It resolves through `cfg.source_fqns()`, so a pack with a `run.source_layout` override gets the
right names too; it REFUSES to emit anything while the three `run.*` bindings still hold their
unfilled placeholder, because a query against a schema of that name fails as "no such schema" and
reads like a finding about the delivery. Nothing is run and no vendor data is touched — it is a text generator.

The queries below are the same ones, with the placeholders left in, kept as the readable reference:

```sql
-- a) do the declared source stems exist for this refresh?
SHOW TABLES IN <source_schema> LIKE '*prostate*';   -- expect t_enh_prostate, _lot, _biomarker, _psa, _som, _prog_scled, _bsln_ecog, _drg_epsode, _orals, _alpbta_emt, _provenge, _psmapet
SHOW TABLES IN <source_schema> LIKE 't_lab*';       -- labs are t_lab (NOT t_enh_prostate_lab) per the June inventory
SHOW TABLES IN <source_schema> LIKE 't_mortality*';

-- b) the verify-vs-source VALUE strings the derivations branch on:
SELECT DISTINCT linesetting   FROM <source_schema>.t_enh_prostate_lot_<refresh>;     -- expect mHSPC / mCRPC spelling the config's line_setting + cohorts use
SELECT DISTINCT biomarkername FROM <source_schema>.t_enh_prostate_biomarker_<refresh>;-- HRR / BRCA names + status strings (clinical.yaml match_any)
SELECT DISTINCT testbasename  FROM <source_schema>.t_lab_<refresh>;                   -- the 10-lab panel names (June table is t_lab)
-- c) columns the engine expects as logical/EDM names:
DESCRIBE <source_schema>.t_enh_prostate_<refresh>;          -- metastaticdiagnosisdate, crpcdate, hspcdate (advanceddiagnosisdate is engine-DERIVED, not a physical column)
DESCRIBE <source_schema>.t_enh_prostate_psa_<refresh>;      -- PSA ScoreSerial column(s)
```

If physical names differ → add a `formats.Panoramic:` overlay (sources + column renames) to the config and
set `run.data_format: Panoramic`; the engine still only ever sees the logical names. **Do not guess** — set
the overlay from what these queries actually return.

## 1. Deploy + run the dev smoke

**From the repository root**, as in section 0 — these were repo-relative `../../../../` paths,
which assume you are inside the pack directory. Two adjacent sections with different working
directories is a failure a new analyst hits and an experienced one shrugs off.

```bash
# Deploy from the ALLOWLISTED tree, never the checkout — the full sequence is in the header of
# databricks.yml. A prod run without that tree's RELEASE_EVIDENCE.yaml cannot publish.
python3 platform/tools/deploy_tree.py --out build/deploy
cd build/deploy && databricks bundle deploy -t dev

databricks bundle run rwdp_build_prostate -t dev \
  --var spec_version=202606 \
  --var prostate_refresh=<snapshot> \
  --var prostate_source_schema=<panoramic_or_edm_source_schema> \
  --var prostate_output_schema=<dev_output_schema> \
  --var prostate_artifact_root=/Volumes/<catalog>/<schema>/<volume>/rwdp/artifacts
```

The bundle **provisions its own job cluster** (DBR 15.4 LTS, SINGLE_USER, 2 workers) — you don't need a
running cluster, only permission to create the configured one.

Dev is lenient on golden-compare (skips without `reference_table`) and deliverables, **but `artifact_root`
must be a real, writable location** — a placeholder only *warns up front*, then the pre-publish manifest/QC
write (`dbutils.fs.put`, `run_rwdp.py`) **raises**, so a bad `artifact_root` lets the expensive build run and
then fails before publish. Use a **dedicated disposable dev output schema**: the runner creates
staging/versioned tables and **swaps the public view even in dev**, and an existing *table* (not view) at the
public ADS name fails `_assert_swappable`. The job prints the resolved source FQNs, cohorts, and output FQN up
front — eyeball those before it builds.

## 2. Post-build ADS sanity — operator ACCEPTANCE checks

*(These confirm the run **structurally** completed — cohorts present, both settings fired, provenance
stamped. They are NOT proof the derivations are scientifically correct; that needs Packages 1–4 done + QC +
golden compare. Do not interpret the ADS scientifically off the first smoke.)*

```sql
-- 7 cohorts present, with rows
SELECT cohortn, cohort, count(*) FROM <output_schema>.rwdp_pros_pano_202606 GROUP BY cohortn, cohort ORDER BY cohortn;
-- expect cohortn 1..7; non-trivial counts for overall_mhspc (1) + overall_mcrpc (2)

-- BOTH settings' treated/untreated labels appear (the dual-setting split actually fired)
SELECT DISTINCT cohortu, cohortun FROM <output_schema>.rwdp_pros_pano_202606 ORDER BY cohortun;
-- expect: Untreated mCRPC=1, Treated mCRPC=2, Untreated mHSPC=3, Treated mHSPC=4

-- provenance stamps are correct (the audit contract)
SELECT DISTINCT data_product_id, spec_version, data_refresh FROM <output_schema>.rwdp_pros_pano_202606;
-- expect exactly: prostate_mcrpc_rwdp | 202606 | <snapshot>   (spec_version must NOT carry the snapshot)

-- spot-check the signature 202606 variables actually populate (not all-null)
SELECT
  count(hrr_index) hrr, count(brca_index) brca, count(tsst) tsst, count(eligpfs) eligpfs,
  count(os) os, count(pfs) pfs, count(pfsfl) pfsfl   -- rwPFS is emitted as pfs / pfsfl / pfsdt (not "rwpfs")
FROM <output_schema>.rwdp_pros_pano_202606;
```

Red flags: only mCRPC `cohortu` labels (the mHSPC path didn't fire); `spec_version` = `202606.<snap>`
(the two version axes duplicated); a signature column 100% null (a source/derivation gap).

## 2b. A PROD run now stops before the swap, awaiting a named approval

Gate 6 is checked after the candidate manifest is written and before any public view moves. A prod
run with no matching `handoff/RELEASE_APPROVAL.yaml` exits `awaiting_release_approval`, having
staged and QC'd everything and touched nothing public. It prints the two values the approval must
carry:

```
approved_build_id: <this run's build_id>
approved_manifest_sha256: <sha256 of the manifest just written>
```

A person reads that manifest and records those plus `approved_by` / `approval_date` /
`validated_by` / `validation_date`. The printed digest is **reproducible from the file**: the
candidate is serialized once and `<artifact_root>/manifest.yaml` is never rewritten after it is
hashed, so `sha256sum` on the artifact must return the value you are signing — if it does not, do not
sign it. The reason the run stopped is recorded beside it in `release_candidate.yaml`, not inside the
manifest, precisely so hashing stays possible. **Dev is unaffected** — it publishes without this,
deliberately, so a smoke test is worth running.

> **PROMOTION IS NOT YET IMPLEMENTED, and this is a block rather than a release flow.** `build_id`
> embeds the Databricks `{{job.run_id}}` and `built_at` moves with every execution, so a rerun mints
> a new build and a new manifest digest: an approval of build A can never be satisfied by run B, and
> there is no promotion-only task that resumes A without rebuilding. The consequence is deliberate
> and worth stating plainly — **a governed PROD release cannot currently complete.** The block is
> real and correct; the resume path is the remaining work:
>
>   candidate build -> IMMUTABLE candidate table + canonical persisted manifest, views untouched
>   approval bound to those persisted bytes and that build_id
>   promotion-only run: no rebuild, reads the candidate, verifies, swaps, stamps published_at
>
> Until that exists, prod runs stop at this gate. Dev is the working path.

## 3. Decisions this run forces (can't be settled from the repo)

Capture answers as you inspect §0/§2 — these gate the *governed* release, not the dev smoke:

- **LineSetting** exact spelling (mHSPC vs MHSPC vs Metastatic hormone-sensitive…) → may need a config value tweak.
- **HRR/BRCA** `biomarkername` + status strings → confirm `clinical.yaml` `match_any` lists match the feed.
- **Conmed flags** (`conmed_*`) — do they materialize (depend on `drug_episode.drugname`)? Required or conditional? (See `DECISIONS.md` CONMED-INCLUDE.)

*(No longer open — now specified requirements in `ENGINE_GAPS.md`, not smoke-time questions: **PSMA** is an RWB-required output; **PSADIAG_CRPC** is a required PSA-table derivation; **setting-suffixed LOT** is 2 mHSPC / 4 mCRPC. The smoke exercises the CURRENT implementation, which does not yet emit these.)*

## 4. Then: governed prod — WHICH CANNOT CURRENTLY COMPLETE

**Read §2b first.** A prod run reaching the release phase stops at Gate 6 awaiting a named approval
of that specific build, and there is no promotion-only path to resume the approved candidate — every
rerun mints a new `build_id`. The command below is therefore the *shape* of a governed run, and it
will stop before any public view moves. Nothing here is broken; the promotion step is unbuilt, and
`products/OPERATIONS.md` specifies exactly what it has to do.

Only after a clean dev smoke + a known-good **golden reference** ADS:

```bash
databricks bundle run rwdp_build_prostate -t prod \
  --var spec_version=202606 --var prostate_refresh=<snap> \
  --var prostate_source_schema=<src> --var prostate_output_schema=<out> \
  --var git_commit=<the commit deploy_tree.py stamped the tree with> \
  --var prostate_reference_table=<known-good ADS>
```

Prod is strict: `git_commit` + `reference_table` are required (or `--var allow_governed_waiver=true`), a
placeholder `artifact_root` HARD-fails, required deliverables (incl. the **enforced** TFL QC gate) block
publish on failure, and the released manifest must carry `published_at` + the release pointer +
`tfl_promotion.passed`. CODEOWNERS now routes every governed path to `@salzburry` (the sole owner); stand up
real GitHub teams + branch protection before relying on it for separation-of-duties review-gating.

## 5. (Optional) Cross-check with the R engine

The R engine builds the **same ADS from the same config** — a useful independent check for the
R-proficient team. It is **validation, not a governed run** (no QC/golden/release lifecycle; it writes
directly), so point it at a **separate `_r` schema**, never `<output_schema>`. On the same cluster (or
Domino→Databricks via sparklyr), from the repo root:

```bash
Rscript platform/engine-r/run_rwdp.R --allow_direct_write=true \
  --config_path=products/oncology/prostate/202606/config/data_product.yaml \
  --refresh=<snapshot> --source_schema=<src> --output_schema=<out>_r
```

Then **golden-compare** R vs the Python ADS by re-running the dev build with the R table as the
reference (the same gate §2 would use against a known-good ADS):

```bash
databricks bundle run rwdp_build_prostate -t dev --var spec_version=202606 \
  --var prostate_refresh=<snapshot> --var prostate_source_schema=<src> \
  --var prostate_output_schema=<out> \
  --var prostate_reference_table=<out>_r.rwdp_pros_pano_202606
```

`--allow_direct_write=true` is required (fail-closed); full Domino→Databricks connection detail is in
`../../../../platform/engine-r/README.md`.
