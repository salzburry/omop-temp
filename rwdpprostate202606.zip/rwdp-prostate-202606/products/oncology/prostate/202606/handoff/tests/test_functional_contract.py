#!/usr/bin/env python3
"""Prostate 202606 — the shared functional-contract lint, run against this product.

The shared invariants live in `platform/tools/contract_lint.py` and are product-agnostic. This file
supplies only what is genuinely this product's: where it is, and how much it currently has.

FLOORS are parser-regression guards. A silent parser break looks exactly like "the file got smaller",
so the numbers are stated rather than inferred. Raise them as the product grows; never lower one to
make a run pass — a drop is the signal.

Run: python3 test_functional_contract.py (or pytest).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PRODUCT = os.path.dirname(os.path.dirname(HERE))


def _repo_root(start):
    """Walk up to the checkout that carries platform/tools. Counting `..` levels instead breaks the
    moment a product sits at a different depth, and fails as a bare ModuleNotFoundError."""
    d = start
    while True:
        if os.path.isfile(os.path.join(d, "platform", "tools", "contract_lint.py")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise RuntimeError(f"no platform/tools/contract_lint.py above {start} — "
                               "this product is not inside an rwddataproduct checkout")
        d = parent


sys.path.insert(0, os.path.join(_repo_root(PRODUCT), "platform", "tools"))

from contract_lint import main, run                                       # noqa: E402

FLOORS = {"decisions": 15, "gaps": 25, "records": 40}


def test_functional_contract():
    errors, n = run(PRODUCT, FLOORS)
    assert not errors, "\n".join([f"{len(errors)} contract-lint violation(s):"] + errors)
    assert n >= FLOORS["records"], f"only {n} records parsed (expected the full crosswalk)"


if __name__ == "__main__":
    sys.exit(main(PRODUCT, FLOORS))
