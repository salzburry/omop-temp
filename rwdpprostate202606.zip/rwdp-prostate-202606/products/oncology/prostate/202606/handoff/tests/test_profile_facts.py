#!/usr/bin/env python3
"""Regression tests for profile_facts.py — stdlib only, run directly:

    python3 test_profile_facts.py        # exits non-zero on any failure

No pytest dependency, so CI invokes it the same way as platform/tests/test_*.py. Covers the required
column + value contract, duplicates, empty input, exact-vs-sampled coverage, mixed cuts, and
Markdown/HTML escaping of category values.
"""
import os, sys, subprocess, tempfile, importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
PRODUCT_DIR = os.path.normpath(os.path.join(HERE, "..", ".."))      # the 202606 product dir


def _repo_root(start):
    """Walk UP for `platform/tools` — the same marker every other tool in this pack uses, so this
    test does not care how deep the pack sits."""
    d = os.path.dirname(os.path.abspath(start))
    while True:
        if os.path.isdir(os.path.join(d, "platform", "tools")):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            raise SystemExit(f"{start}: no platform/tools above this file")
        d = parent


# The reporter is SHARED platform code, not a per-pack file. It is generic — it takes a product dir
# and a profile TSV and resolves everything through that pack's config — so a copy per tumour would
# have been the profiler's mistake repeated. This test stays with the pack because what it proves is
# per-pack: that the shared reporter works against THIS pack's real config.
_TOOLS = os.path.join(_repo_root(__file__), "platform", "tools")
PF_PATH = os.path.join(_TOOLS, "profile_facts.py")
sys.path.insert(0, _TOOLS)
import profile_io                                                            # noqa: E402
_spec = importlib.util.spec_from_file_location("profile_facts", PF_PATH)
pf = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(pf)

COLS = ["table", "table_base", "column", "kind", "sampled", "n_rows", "n_rows_total",
        "pct_missing", "distinct", "date_min", "date_max", "top_values"]
HDR = "\t".join(COLS) + "\n"


def row(tbl, col, sampled="FALSE", nr="100", nt="100", pm="0.5", tv="10:a|5:b", kind="categorical"):
    # CUT lives in profile_io, which OWNS the snapshot-suffix definition. It used to be reached as
    # pf.CUT, which only worked because profile_facts re-exported a name it never used itself.
    return "\t".join([tbl, profile_io.CUT.sub("", tbl), col, kind, sampled, nr, nt, pm, "3", "", "", tv]) + "\n"


def tmp_tsv(body, header=HDR):
    p = os.path.join(tempfile.mkdtemp(), "profile_2026m06.tsv")
    open(p, "w", encoding="utf-8").write(header + body)
    return p


def raises_exit(fn):
    try:
        fn()
        return False
    except SystemExit:
        return True


CHECKS = []
def check(name):
    def deco(f):
        CHECKS.append((name, f))
        return f
    return deco


@check("load ok + cut detection")
def _():
    tables, cuts = pf.load(tmp_tsv(row("t_x_2026m06", "c1")))
    assert "t_x" in tables and cuts == {"2026m06"}


@check("missing identity column rejected")
def _():
    hdr = HDR.replace("\ttable_base", "")
    assert raises_exit(lambda: pf.load(tmp_tsv("t_x_2026m06\tc\tcategorical\tFALSE\t1\t1\t0\t1\t\t\t\n", hdr)))


@check("missing required column rejected")
def _():
    hdr = HDR.replace("\tsampled", "")
    assert raises_exit(lambda: pf.load(tmp_tsv("t_x_2026m06\tt_x\tc\tcategorical\t1\t1\t0\t1\t\t\t\n", hdr)))


@check("non-boolean sampled rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="MAYBE"))))


@check("non-numeric n_rows rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="abc"))))


@check("n_rows > n_rows_total rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="200", nt="100"))))


@check("pct_missing out of range rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", pm="150"))))


@check("zero-row table with blank pct_missing loads")
def _():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="0", nt="0", pm="")))   # profiler NA -> ""
    assert "t_x" in tables


@check("NaN / inf counts rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="nan"))))
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nt="inf"))))


@check("non-integer n_rows rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c", nr="12.5"))))


@check("duplicate (table,column) rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv(row("t_x_2026m06", "c1") + row("t_x_2026m06", "c1"))))


@check("empty profile rejected")
def _():
    assert raises_exit(lambda: pf.load(tmp_tsv("")))


@check("coverage EXACT when not sampled")
def _():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="FALSE")))
    assert pf.sampling_status(tables).startswith("EXACT")


@check("coverage SAMPLED via flag")
def _():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="TRUE")))
    assert pf.sampling_status(tables).startswith("SAMPLED")


@check("coverage SAMPLED via count mismatch")
def _():
    tables, _ = pf.load(tmp_tsv(row("t_x_2026m06", "c", sampled="FALSE", nr="50", nt="100")))
    assert pf.sampling_status(tables).startswith("SAMPLED")


@check("mixed cuts rejected (CLI)")
def _():
    p = tmp_tsv(row("t_x_2026m06", "c") + row("t_y_2026m07", "c"))
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", p + ".md"],
                       capture_output=True, text=True)
    assert r.returncode != 0 and "mixes cuts" in r.stderr


@check("Markdown + HTML escaping (CLI)")
def _():
    p = tmp_tsv(row("t_demographics_2026m06", "state", tv="44:CA|36:<0.1|20:A & B"))
    out = p + ".md"
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", out],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    txt = open(out, encoding="utf-8").read()
    assert "<br>" in txt and "&lt;0.1" in txt and "&amp;" in txt and "EXACT_METRICS" in txt


@check("partial configured-table scope is labelled; no --strict -> exit 0 (CLI)")
def _():
    p = tmp_tsv(row("t_demographics_2026m06", "state"))     # 1 of ~20 configured stems -> partial
    out = p + ".md"
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", out],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    assert "PARTIAL CONFIGURED-TABLE SCOPE" in open(out, encoding="utf-8").read()


@check("--strict on a partial-scope profile -> exit nonzero (CLI)")
def _():
    p = tmp_tsv(row("t_demographics_2026m06", "state"))
    r = subprocess.run([sys.executable, PF_PATH, PRODUCT_DIR, p, "--out", p + ".md", "--strict"],
                       capture_output=True, text=True)
    assert r.returncode != 0 and "PARTIAL CONFIGURED-TABLE SCOPE" in r.stderr


def main():
    fails = 0
    for name, f in CHECKS:
        try:
            f()
            print(f"  ok  {name}")
        except Exception as e:                       # noqa: BLE001 - report and continue
            fails += 1
            print(f"FAIL  {name}: {e}")
    print(f"\n{len(CHECKS) - fails}/{len(CHECKS)} passed")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
