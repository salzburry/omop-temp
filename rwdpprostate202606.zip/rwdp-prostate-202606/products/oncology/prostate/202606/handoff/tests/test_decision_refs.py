#!/usr/bin/env python3
"""Decision-reference consistency test — kills the tab/index drift class.

Every OPEN decision ID in DECISIONS.md must be referenced in at least one handoff
tab (or README), so an unresolved row always points at its decision and the two
files can't silently drift apart. stdlib only; run with `python3`.
"""
import os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
HANDOFF = os.path.dirname(HERE)

DECISIONS = os.path.join(HANDOFF, "DECISIONS.md")
# Every OPEN decision must be referenced in the CANONICAL contract itself — not in README or a worked
# example. Searching those too would let a decision that silently disappeared from FUNCTIONAL_CONTRACT.md
# still pass (masked by a mention elsewhere). The per-tab prose and the bone worked-example were retired;
# their content is consolidated in FUNCTIONAL_CONTRACT.md, which references every decision.
TABS = ["FUNCTIONAL_CONTRACT.md"]

ID_RE = re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$")   # STUDY-WINDOW, MAXINDEX, OS-ID3MOSFU, …


def read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def decision_ids(text):
    """First-column IDs of the DECISIONS.md table rows with status OPEN."""
    ids = []
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 2:
            continue
        cid, status = cells[0], cells[-1]
        if status == "OPEN" and len(cid) >= 5 and ID_RE.match(cid):
            ids.append(cid)
    return ids


def main():
    ids = decision_ids(read(DECISIONS))
    assert ids, "no OPEN decision IDs parsed from DECISIONS.md — parser or table changed"
    corpus = "\n".join(read(os.path.join(HANDOFF, t)) for t in TABS if os.path.exists(os.path.join(HANDOFF, t)))

    missing = [cid for cid in ids if cid not in corpus]
    for cid in ids:
        print(f"  {'ok  ' if cid not in missing else 'MISS'} {cid}")
    if missing:
        print(f"\nFAIL: {len(missing)} OPEN decision(s) not referenced in any tab: {', '.join(missing)}")
        print("Add `⛔ <ID>` (or a mention) to the affected handoff row so the two files stay in sync.")
        sys.exit(1)
    print(f"\n{len(ids)}/{len(ids)} OPEN decisions referenced in a tab")


if __name__ == "__main__":
    main()
