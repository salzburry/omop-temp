# RWP → RWDE Handoff

**What it is:** the RWB Excel spec turned into a per-variable functional contract — the artifact **RWP works
from to maintain the product YAML**, and that **RWDE reads when a shared-engine capability or technical change
is needed**. No prostate or Flatiron knowledge required to read it.

**Why it exists:** RWP translates the RWB spec, profiles the data, resolves the functional details, and
maintains `config/` + `variables/` + `codelists/`. The unspoken answers RWP used to just *know* — which
column, what "missing" means, whether a boundary is inclusive — are written down here so nothing is inferred.

## The single contract — `FUNCTIONAL_CONTRACT.md`

[`FUNCTIONAL_CONTRACT.md`](./FUNCTIONAL_CONTRACT.md) is the whole functional contract as a **canonical
crosswalk**: **one fenced `yaml` record per output variable** across all six spec tabs (DataPrep · StudyPop ·
Demographics · Clinical · Treatment · Outcomes), every record in the same shape. It is the RWP authoring
artifact; the executable YAML is downstream of it. A CI lint
([`tests/test_functional_contract.py`](./tests/test_functional_contract.py)) enforces the shape — unique IDs,
resolvable decision/gap references, valid enums, published-field completeness — so it can't drift back into
contradictory prose.

### One record, every field
Each record carries: `variable_id`, `spec_refs`, `required_rule`, `source` (`{logical_table, physical_stem,
columns}`), `grain`, `anchor`, `window`, `record_selection`, `tie_break`, `derivation`, `missing`, `units`,
`depends_on`, `output` (`{physical_name, target_published_name, name_status, type, nullable, codes, role}`),
`status`, `decision_ids`, `gap_ids`, `publish`, `acceptance`, `notes`. The reference fields (`decision_ids` /
`gap_ids`) point INTO `DECISIONS.md` / `ENGINE_GAPS.md` — they are not copied. Section **A** is the
dataset-level contract; section **A2** carries the non-output source-preparation controls (date family,
LOT-duplicate alert, death-before-progression).

### Readiness = the controlled `status` axes (not an icon)
A record's readiness is its `status` dict — four controlled-vocabulary axes, not a `✅/⛔/🔍` glyph:
- **requirement** ∈ {approved · draft · decision_required} — is the requirement settled, or does a `decision_ids` entry gate it?
- **source** ∈ {verified · dictionary_only · unverified · unavailable} — is the physical source/column confirmed on the live cut? (schema presence alone is **not** `verified` — see `profile/`.)
- **implementation** ∈ {implemented · partial · config_gap · engine_gap · not_implemented · not_derivable} — what engine+config actually do (a gap names a `gap_ids` entry).
- **validation** ∈ {not_run · passed_test · passed_live · failed} — checked against synthetic/real data yet? (`passed_synthetic` is the legacy spelling of `passed_test`)

**RWDE readiness rule:** requirement `approved`, source `verified`, the output contract aligned, and
implementation explicitly `implemented` (or the remaining work classified as `config_gap` / `engine_gap`).

## Supporting indexes (NOT additional contracts)
- [`DECISIONS.md`](./DECISIONS.md) — every open decision in one table (what a human must answer). Referenced by `decision_ids`.
- [`ENGINE_GAPS.md`](./ENGINE_GAPS.md) — every config/engine deviation from the spec, with acceptance cases + bounded implementation packages. Referenced by `gap_ids`.
- [`WORKFLOW.md`](./WORKFLOW.md) — how a requirement travels RWB → RWP → RWDE, with the file at each step.

These INDEX the contract; the per-variable record is the single source of truth. A CI test
([`tests/test_decision_refs.py`](./tests/test_decision_refs.py)) requires every open decision to be
referenced in `FUNCTIONAL_CONTRACT.md` itself, so the index and the contract can't drift apart.

## Conventions & open policy
- **Categorical missing/unknown codes.** Demos-tab fallthroughs (`AGEGR1N`, `REGION1N`, `RACEN`, `ETHN`,
  `PRACTICN`) use `99` as a **config-inferred** code (their RWB "Values" columns weren't ) —
  flagged under `CODE-ALIGN`; those rows keep `requirement: decision_required` until it closes. The
  clinvars-tab codes ARE present and used as specified (`BMIGR1N` Missing = 5, `HRR_INDEXN`/`BRCA_INDEXN`
  Unknown = 4). Distinct by design: `ECOGN` Unknown 6 / Missing 7, `STAGEN` fallthrough 99 = CHECK (QC).
  Continuous missing stays `null`.
- **Authority.** The approved RWB spec + closed decisions govern the requirement; **this contract** records
  it; the executable YAML is the implementation downstream. Where they disagree the contract wins and the
  YAML is corrected — never the reverse.

## Replicating to another tumor or dataset
Copy the canonical record shape — one fenced `yaml` record per output variable, the same fields — and fill it
from that tumor's spec tabs. The record schema never changes; only the values do.

## Files
- `FUNCTIONAL_CONTRACT.md` — the canonical per-variable crosswalk (all six tabs; replaces the retired per-tab
  prose `dataprep/studypop/demographics/clinical/treatment/outcomes.md` AND the bone worked-example).
- `DECISIONS.md` — the open-decision index.
- `ENGINE_GAPS.md` — the config/engine-gap index (acceptance cases + bounded implementation packages).
- `WORKFLOW.md` — the RWB → RWP → RWDE workflow.
- `profile_facts.py` — the deterministic profile-facts reporter (below).

## Profile facts (deterministic reporter)
Read-only: turns a profiler TSV into a facts report RWP reads. **No AI. It does NOT edit the contract, flip
any `status`, or approve a source** — RWP reviews the facts and updates the YAML/status by hand.
1. `python3 platform/tools/run_product_profile.py <pack> --cut <cut> --schema <schema> --out-dir $OUT`
   over the configured sources → `$OUT/<data_product_id>/<schema>/<cut>/profile_<cut>.tsv`
   (see `profile/README.md`).
2. `python3 platform/tools/profile_facts.py <pack> "$PROFILE"` → `PROFILE_FACTS_<cut>.md` beside the TSV
   (per-source metrics + mechanical notes; stamped `EXACT_METRICS` or `SAMPLED_METRICS`).

Both the TSV and the facts report stay in `$OUT`, **outside the checkout** — they carry per-column top
values and date ranges with no small-cell floor. Neither is ever committed; `SOURCE_VERDICTS.md` from
`source_check.py` is the sanitized, commit-safe artifact.

**What it can't do** (needs targeted RWP queries): composite grain, duplicates, join coverage, same-day ties,
window coverage. Decisions are never touched — those need a human.

*The executable rules live only in `config/` + `variables/` + `codelists/` — RWP maintains those for
versioning. This handoff is what RWP works from; it is not itself run by the engine.*
