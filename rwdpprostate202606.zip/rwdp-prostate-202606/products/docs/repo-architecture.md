# RWD Data Products — Repository Architecture & Operating Model

> **⚠ SUPERSEDED by [`docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](../../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md)**
> (the repo-level, authoritative production-migration blueprint). This doc is kept for historical
> context until the migration completes; where the two differ, the repo-level doc wins.
> **Do not use the sections below for implementation planning** — they predate the CURRENT/TARGET split.

> Target-state schematic for scaling the platform: more tumors, more variables, recurring
> refreshes, many concurrent contributors, and governed spec / dashboard / TFL changes — all to an
> **audit-grade** standard (provenance, immutability, lineage, reproducibility, sign-off).
>
> It describes the destination and the **non-disruptive migration path** from where the repo is today.
> Decisions already locked in earlier review: **single living catalog**, **metadata versioning** (not
> duplicated source trees), **don't rename `prostate`/folders mid-stream**.

---

## 0. The needs this serves

| Need | The mechanism that serves it |
|---|---|
| Increase scope (variables, cohorts) | Config-driven packs + master catalog ledger; additive minor bumps |
| Add new tumors | One folder per tumor, scaffolded from a template; shared engine, no forks |
| Add variables to existing tumors | Pack YAML + catalog `introduced_in`; CI enforces cataloging; refresh `contract_delta` records it |
| Recurring refreshes | Two-level version (spec × snapshot); refresh manifest per cut; immutable versioned tables |
| Many concurrent users | Tumor isolation + `OWNERS` routing + CI gates; the catalog is the one coordination point |
| Spec / dashboard / TFL changes | Versioned shared contracts; manifests regenerated and stamped per build |
| Audit grade | Row-level provenance, immutable tables, ADS-anchored release swap, release records, lineage, sign-off |

---

## 1. Layering model (the big picture)

Five layers, each independently versioned and owned. Lower layers are shared; upper layers are
per-tumor and per-cut. Nothing above reaches around a layer below it.

```mermaid
flowchart TB
  subgraph L1[" 1 · SHARED ENGINE  (_framework) — one implementation, all tumors "]
    ENG[engine/ + engine-r parity + databricks runner + tests · VERSION-pinned]
  end
  subgraph L2[" 2 · SHARED CONTRACTS — cross-tumor, governed "]
    CAT[metadata/catalog.yaml · registry.yaml · dashboard · dictionary · tfl]
  end
  subgraph L3[" 3 · PER-TUMOR SPEC  (<tumor>/) — the data product definition "]
    SPEC[config + variables/*.yaml + codelists/*.yaml · spec_version]
  end
  subgraph L4[" 4 · PER-REFRESH  (refreshes/) — a spec run against a data cut "]
    REF[refreshes/<tumor>/<spec_version>/<refresh>.yaml · contract_delta]
  end
  subgraph L5[" 5 · PUBLISHED OUTPUTS — immutable + audited "]
    OUT[versioned ADS table · public view · dashboard manifest · dictionary · TFLs · release.json]
  end
  L1 --> L3 --> L4 --> L5
  L2 --> L3
  L2 --> L5
```

**Why this shape:** the engine never knows about a specific tumor (everything tumor-specific is config),
so onboarding a tumor or a variable is a **config + catalog** change, not an engine change — which is what
makes parallel work and audit review tractable.

---

## 2. Physical structure (directory tree)

`✚` = new vs today · everything else exists. The migration in §9 adds the `✚` pieces incrementally.

```
products/                                    # (rename of "current data products/" — cosmetic, deferred)
├── README.md                                # canonical entry: what this is, how to run, tumor index
├── GOVERNANCE.md                         ✚  # sign-off model, audit controls, change-control policy
├── docs/                                 ✚  # durable design/process docs (this file lives here)
│   ├── repo-architecture.md  ·  versioning.md
│   ├── onboarding-new-tumor.md  ·  adding-variables.md  ·  contributing.md
│
├── _framework/                              # SHARED ENGINE — one implementation, every tumor
│   ├── VERSION                           ✚  # engine semver; a tumor pins it for reproducibility
│   ├── engine/                              # config · validate · stages/ · assemble · qc · dashboard
│   │                                        #   · dictionary · refresh · release · codelists
│   ├── engine-r/                            # R parity (stages.R, cases.R) — byte-identical transforms
│   ├── databricks/run_rwdp.py              # the ONE runner; one generated job per product
│   └── tests/                               # pure-Python + Spark + R-parity suites (CI gate)
│
├── databricks.yml                           # Databricks Asset Bundle (root) — wires the runner as a job
├── registry.yaml                            # tumor registry + LINEAGE (current_spec_version, history)
├── metadata/catalog.yaml               # SINGLE living dictionary (introduced_in / deprecated_in)
├── dictionary/audiences.yaml                # audience projections (internal / partner / customer)
├── dashboard/dashboard_vars.yaml            # dashboard panel layout (shared exporter contract)
├── tfl/tfl_specs.yaml                       # TFL specs (shared)
│
├── <tumor>/                                 # ONE FOLDER PER TUMOR (prostate, oc, ec, sclc, …)
│   ├── README.md                            # cohorts, sources, verify-vs-source list, smoke checklist
│   ├── CHANGELOG.md                      ✚  # human-readable spec lineage (1.0 → 2.0 → …)
│   ├── OWNERS                            ✚  # code owners → review routing
│   ├── config/data_product.yaml             # cohorts · sources · windows · spec_version · run · release
│   ├── variables/*.yaml                      # demographics / clinical / treatment / outcomes
│   ├── codelists/*.yaml                       # treatment categories, biomarker maps, …
│   └── docs/                             ✚  # tumor-specific transition notes
│
├── refreshes/                               # VERSIONED manifests (today: flat → §9 migrates)
│   └── <tumor>/<spec_version>/<refresh>.yaml ✚  # snapshot stamp + auto-derived contract_delta
│
└── releases/                             ✚  # IMMUTABLE release records — the audit trail
    └── <tumor>/<spec_version>/<refresh>/release.json   # build_id · git_commit · table · QC · sign-off
```

**Key property — tumor isolation:** two teams editing `prostate/` and `sclc/` never touch the same files.
The only shared write surfaces are the catalog and registry, and those are append-structured (one line per
variable / tumor), so merges are trivial and conflicts are visible.

---

## 3. Two-level versioning (three axes, in fact)

Every published row answers four questions: *which product, which contract, which data, which code.*

| Axis | Example | Lives in | Bumps when |
|---|---|---|---|
| **Framework version** | `engine 3.2.0` | `platform/VERSION` | engine behaviour changes; tumors pin it for reproducibility |
| **Spec version** `major.minor` | `2.0` | `<tumor>/config` → `spec_version` | **major** = breaking; **minor** = additive (see below) |
| **Data refresh** (snapshot) | `2026q2` | refresh manifest + `run.refresh` | new Flatiron/COTA cut, same spec |

The config field stays `version: "<major>.<minor>.{snapshot}"` — e.g. `2.0.{snapshot}` resolves to
`2.0.2026q2`. The target is for every ADS row to carry the full provenance set:

```
spec_version · data_refresh          ← stamped TODAY (assemble.py)
data_product_id · framework_version · git_commit · build_id(run_id)   ← ✚ target (build_id/git_commit
                                       exist on the run + release record today; row-stamping is a migration step)
```

### Bump rules (enforced in CI — §6)

| Change | Example | Version action | `request_type` |
|---|---|---|---|
| Add a variable (additive) | `+ gleason_cat` | spec **minor** `2.0 → 2.1` | `refresh_with_change` |
| Add a cohort (additive) | `+ L5+ mCRPC` | spec **minor** | `refresh_with_change` |
| Rename / remove a variable | `advanceddiagnosisdate → setting_diagnosis_date` | spec **major** `1.0 → 2.0` | `refresh_with_change` |
| Change a derivation / cohort definition | mCRPC-only → mHSPC+mCRPC | spec **major** | `refresh_with_change` |
| New data cut only | `2026q1 → 2026q2` | snapshot only | `refresh_no_change` |
| New tumor | SCLC `1.0` | new spec lineage | `new_product` |

> **Rule of thumb:** if a downstream consumer's code could break, it's **major**. If they'd only *gain*
> columns, it's **minor**. If only the numbers move, it's a **snapshot**.

---

## 4. The master catalog as the variable ledger

`metadata/catalog.yaml` is the **single system-of-record** for "what variable exists, for which tumor,
since which spec version." Keep it singular (do not split per version) — tumors share most variables, and
`introduced_in` carries the version dimension without duplication.

```yaml
# one row per variable; the version metadata is additive
- code: gleason_cat
  category: "Clinical Chars"
  label: "Gleason grade category"
  applies_to: [mcrpc]
  type: categorical
  introduced_in: { mcrpc: "2.0" }        # ✚ when each tumor first emitted it
  deprecated_in: {}                       # ✚ set on retirement; never delete the row
```

- **Go-forward tagging:** new variables carry `introduced_in`; anything untagged is implicitly "since 1.0".
  No need to back-annotate the existing ~100 prostate rows.
- **Completeness is already enforced:** `validate.emitted_variables(cfg)` ⊆ catalog (test_catalog). A
  variable emitted without a catalog row fails CI — this is how `prior_tax_mcrpc` / `advanceddiagnosisdate`
  gaps were caught.
- **`contract_delta` is auto-derived,** not hand-maintained: diff the catalog's
  `introduced_in == current spec_version` against the prior version's frozen set → the refresh manifest's
  `added` / `removed` / `changed`. Drift becomes impossible.

---

## 5. The four change-flows

### A · Onboard a new tumor

```mermaid
flowchart LR
  T[scaffold sclc/ from template] --> R[registry.yaml entry · status: scaffold]
  R --> C[author config + variables + codelists]
  C --> K[catalog rows · introduced_in sclc 1.0]
  K --> G[CI green + golden reference built]
  G --> P[status: active · spec 1.0 · release]
```

Cost is bounded because the engine, runner, dashboard/dictionary/TFL exporters, release governance, and
versioning policy are **inherited**. SCLC defines only what is genuinely tumor-specific: cohorts, index
rules, source stems, codelists, biomarkers, outcomes, golden reference.

### B · Add a variable to an existing tumor  *(the common case)*

```mermaid
flowchart LR
  V[define in pack YAML] --> C[catalog row + introduced_in]
  C --> E[emitted_variables tracks it]
  E --> CI[CI: completeness · tests · Py≡R parity · preflight]
  CI --> B[spec minor bump 2.0 → 2.1 + CHANGELOG line]
  B --> D[refresh contract_delta: added]
  D --> M[dashboard + dictionary pick it up — column-aware]
```

Because dashboard **and** dictionary are now column-aware (filtered to actual ADS columns), an *optional*
new variable that doesn't materialize in a cut is simply not advertised — no false promises.

### C · Run a data refresh (same spec, new cut)

```mermaid
flowchart LR
  N[new manifest refreshes/<tumor>/<spec>/2026q2.yaml] --> PF[preflight: required columns present]
  PF --> RUN[run_rwdp: stages → assemble ADS]
  RUN --> QC[QC golden compare + counts]
  QC --> TFL[TFL promotion]
  TFL --> REL[release.json sign-off]
  REL --> SWAP[write IMMUTABLE versioned table → publish TFLs first, ADS view last]
```

### D · Spec / dashboard / TFL change

Edits to `dashboard_vars.yaml`, `tfl_specs.yaml`, or pack definitions regenerate the manifests from the
catalog at build time (the app never hard-codes metadata). A contract-affecting change trips the
version-bump CI gate (§6), so the dashboard/TFL contract version always tracks the spec it was built from.

---

## 6. Multi-user collaboration

```mermaid
flowchart LR
  BR[branch per change] --> PR[pull request]
  PR --> OWN[CODEOWNERS routes review]
  OWN --> GATES{CI gates}
  GATES -->|pass| MERGE[merge]
  GATES -->|fail| BR
```

**Review routing (`OWNERS` / CODEOWNERS):** `_framework/**` → engine owners (high bar, parity required);
`<tumor>/**` → that tumor's clinical/data owner; `metadata/`, `registry.yaml` → catalog steward.

**CI gates (the merge contract):**

1. `tests/` — pure-Python suite (catalog well-formed, dashboard/dictionary typing, validate, release…)
2. **Catalog completeness** — `emitted_variables ⊆ catalog` for every tumor
3. **Preflight dry-run** — every column the engine dereferences is declared on a source
4. **Python ≡ R parity** — the two engines produce identical transforms
5. **Byte-compile / lint**
6. **Version-bump check** ✚ — a contract change (catalog/cohort/derivation) without a `spec_version` bump
   **and** a `CHANGELOG.md` entry fails the build
7. *(release only)* QC golden + TFL promotion must be green

**Conflict avoidance:** tumor folders are independent; the catalog and registry are one-line-per-entry, so
parallel additions merge cleanly and any real collision (two people touching the same variable) is visible
in the diff.

---

## 7. Build → QC → Release pipeline (audit-grade)

```mermaid
flowchart TB
  SRC[(source tables · stems+snapshot)] --> PF[preflight: required_columns]
  PF --> ST[stages: index · clinical · treatment · outcomes · deterministic]
  ST --> AS[assemble ADS · stamp provenance columns]
  AS --> QC[QC: golden compare + row/cohort counts]
  QC -->|fail| STOP[BLOCK publish · record reason]
  QC -->|pass| STG[stage table]
  STG --> TFL[TFL promotion]
  TFL --> SIGN[release.json: build_id · git_commit · QC · approver · timestamp]
  SIGN -->|status: released| IMM[write IMMUTABLE versioned table]
  IMM --> VIEW[publish TFLs first, then swap ADS view last as the commit anchor]
  VIEW --> ART[dashboard_manifest · dictionary · TFLs → artifact_root]
```

The runner already implements the spine: a failed deliverable **blocks publish**, the staged ADS is the
byte-for-byte artifact that publishes, it is copied to an **immutable versioned table**, and the release
set is published **sequentially — TFLs first, the ADS view last as the commit anchor** (a single view
replacement is atomic, but the *set* is ADS-anchored so a half-published refresh can't be seen as complete;
see `OPERATIONS.md` / `release.py`). The `✚` additions formalise the release record and sign-off around it.

---

## 8. Audit & provenance model

| Control | How it's realised |
|---|---|
| **Immutability** | Each refresh writes a *new* versioned UC table, never overwritten; the public view is a pointer. The release set publishes sequentially (TFLs first, ADS view last as commit anchor) so a half-published refresh is never visible as complete. Prior versions are retained and queryable. |
| **Row-level provenance** | Every ADS row stamps `spec_version · data_refresh` **today**; the target adds `data_product_id · framework_version · git_commit · build_id` (these exist on the run + release record now — row-stamping them is a migration step, §9). Any row then traces to the exact code + spec + cut. |
| **Reproducibility** | `git_commit` + `platform/VERSION` + the refresh manifest fully determine a re-run; the engine is config-driven and deterministic (no arbitrary `dropDuplicates` — latest/earliest with stable tiebreaks). |
| **Lineage** | `registry.yaml` `lineage[]` (machine) + per-tumor `CHANGELOG.md` (human) + `releases/**/release.json` (per-build) — three views of the same history. |
| **Change control** | `request_type` + auto `contract_delta` + the version-bump CI gate: a contract can't change identity-silently. |
| **Sign-off / separation of duties** | `release.json` requires QC pass + TFL promotion + a **named approver** + timestamp before `status: released`; the view only swaps on a released record; approver ≠ author via CODEOWNERS. |
| **Traceability (bidirectional)** | spec line → catalog (`introduced_in`) → `emitted_variables` → ADS column → dashboard/dictionary/TFL. A delivered column traces back to the commit and spec version that introduced it, and forward to every artifact that exposes it. |
| **Forwarded data integrity** | dashboard **and** dictionary are column-aware, so published metadata can never advertise a column the ADS didn't emit. |

---

## 9. Migration path from today (non-disruptive, metadata-first)

Ordered so each step is independently shippable and reversible. None of this is the engine — it's structure
and metadata.

1. **Docs scaffold** — add `docs/` (this file + `versioning.md`) and `GOVERNANCE.md`. *(no runtime impact)*
2. **Registry lineage** — add `current_spec_version` + `lineage[]` to `registry.yaml`.
3. **Catalog ledger** — start tagging `introduced_in` on new variables (go-forward).
4. **Refresh path** — move manifests to `refreshes/<tumor>/<spec_version>/<refresh>.yaml`; teach `refresh.py`
   to emit auto `contract_delta`.
5. **Release records** — write `releases/<tumor>/<spec_version>/<refresh>/release.json` from the runner.
6. **CI gates** — add the version-bump/changelog check and wire CODEOWNERS.
7. **Full row provenance** — add `platform/VERSION`, then extend `assemble` to stamp the remaining
   provenance columns (`data_product_id`, `framework_version`, `git_commit`, `build_id`) on every ADS row
   alongside the `spec_version` / `data_refresh` it already stamps.
8. **(Per tumor, when ready) the v2 transition** — e.g. prostate: `spec_version 2.0`, `rwdp_pros_pano_v2`,
   `CHANGELOG.md`, explicit `setting_diagnosis_date` (legacy alias), README/pack-name refresh, tag
   `spec/mcrpc/1.0` for recoverability.

Steps 1–7 are tumor-agnostic platform plumbing and can land before any single tumor's v2 cutover (step 8),
which is deliberately the last and most visible move.

---

### One-line summary

> **Shared deterministic engine + a single versioned variable ledger + per-tumor config + per-refresh
> manifests + immutable signed releases** — so scope grows by adding *config and catalog rows*, not code,
> and every published number is reproducible, attributable, and reviewable end to end.
