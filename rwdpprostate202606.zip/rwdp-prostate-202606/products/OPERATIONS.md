# Operations: refresh lifecycle, QC, and TFLs

How an RWDP goes from a new data cut to a signed-off, delivered set of tables — and how git tracks
all of it. Complements `ROADMAP.md` (the build framework) with the **delivery + governance** layer.

## The lifecycle (per tumor, per refresh)

```
  new refresh (data cut)                       e.g. 2026q1 -> 2026q2
        │
        ▼
  build STAGING    databricks bundle run rwdp_build_<slug> --var <slug>_refresh=…
        │          (shared engine: validate -> preflight -> build; rows stamped spec_version+data_refresh)
        ▼
  semantic QC      engine/qc.run_qc(staged) -> engine/qc.qc_gate(report, thresholds)
        │          (null-rates, treatment catch-all rate, unmapped-stage rate, date-castability)
        ▼
  golden compare   engine/golden.run_golden(staged, reference_ads) -> golden_gate
        │          (row/cohort deltas, lotcat distributions, OS summary; either gate fails -> no publish)
        ▼
  deliverables     engine/tfl.generate(staged,…) + engine/dictionary (.md + .xlsx) + engine/dashboard
        │          (the dashboard MANIFEST contract; a REQUIRED one failing blocks publish)
        ▼
  durable ledger   engine/refresh.build_manifest(...) -> artifact_root manifest + QC  (BEFORE publish, fail-loud)
        │          (spec_version, git_commit, counts, qc+golden gates, per-deliverable status, release pointer)
        ▼
  publish          versioned + view pointer: write IMMUTABLE {final}__{refresh}__{build_id}[ __tfl_<id>]
        │          (build_id = git sha + run id/timestamp, UNIQUE PER RUN -> a rerun mints a NEW version,
        │          never overwriting a live one; a versioned-table collision fails loud). All versioned
        │          writes first, THEN swap public VIEWS — TFLs first, ADS LAST (the commit anchor);
        │          staging dropped only after; published_at only after the swap (engine/release.py). Not a
        │          single-transaction set swap: CONSUMERS SHOULD ANCHOR ON THE ADS VIEW (swapped last) —
        │          a direct TFL reader could momentarily see a new TFL before the ADS view flips.
        │
        ▼
  release          promote manifest -> refreshes/<family>/<product>/<spec_version>/<refresh>.yaml (COMMIT); status: released + sign-off; tag
```

> **Consuming a release.** Read the ADS through its public view (the commit anchor, swapped last) and
> TFLs through `release.tfls` in the manifest — not by globbing `{final}__tfl_*` directly. A TFL that a
> later spec stops producing leaves its old public view live (the runner records these as `retired_tfls`
> and warns); retire it manually — the engine never auto-drops a consumer-readable view. A manifest with
> `status: released` is guaranteed to carry `published_at` + a valid `release` block (validated).

## Git architecture (refreshes tracked)

- **Spec/engine changes** → feature branch → PR → `main` (reviewed config diff; CI lints every
  tumor config + runs the pure-Python tests).
- **A refresh** (data cut only, no code change) → a `--var refresh=…` run + a committed
  `refreshes/<family>/<product>/<spec_version>/<refresh>.yaml` manifest. The manifest's `git_commit` pins the exact
  engine + spec, so the ADS is **reproducible**: checkout the tag, re-run the same config.
- **Release tag**: `release/<registry_code>/<spec_version>/<refresh>` (e.g. `release/mcrpc/202606/2026q1`) — the
  `spec_version` segment avoids cross-version collisions (see `../docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md` §G);
  none cut yet. The ADS rows carry matching `spec_version` + `data_refresh` stamps (added in `assemble`).
- **Audit**: git history of `refreshes/` is the ledger — who built/QC'd/released what, when, from
  which commit. Superseded refreshes are kept (`status: superseded`).

See `../refreshes/README.md` (+ `REFRESH_TEMPLATE.yaml`) for the manifest, and `_reporting/tfl/README.md` for TFLs.

## Side-by-side R validation (optional — NOT a governed run)

The R engine (`../platform/engine-r/`) reads the **same config** and builds the same ADS, for the
R-proficient team to cross-check the Python build. It is a **validation aid, not part of the lifecycle
above**: it has no source-QC/golden/release gates, no manifest, and no view swap — it writes the table
**directly**, so it must target a **separate `_r` schema**, never the governed `output_schema`. On a
Databricks cluster (or Domino→Databricks via sparklyr), from the repo root:

```bash
Rscript platform/engine-r/run_rwdp.R --allow_direct_write=true \
  --config_path=products/oncology/<product>/<spec_version>/config/data_product.yaml \
  --refresh=<cut> --source_schema=<src> --output_schema=<out>_r
```

Then close the loop with the **same `engine/golden.py` gate** the lifecycle uses: re-run the Python
build pointing `--var reference_table=<out>_r.<ads_table>`, so the R ADS is golden-compared against the
governed Python ADS (row/cohort counts, lotcat distribution, OS summary, column diff). `--allow_direct_write=true`
is required (fail-closed); full Domino→Databricks connection detail + caveats: `../platform/engine-r/README.md`.

## Gate 6: the promotion path, SPECIFIED AND NOT BUILT

**A governed PROD release cannot currently complete.** Stating that first because everything else
here is about how to fix it, and because a release flow that looks finished and silently cannot
finish is discovered at the worst possible moment.

**What works.** `run_rwdp.py` blocks: a prod run reaching the release phase without a matching
`handoff/RELEASE_APPROVAL.yaml` stops after staging and QC, touches no public view, and prints the
`build_id` and candidate-manifest digest an approval must carry. That block is real and correct.

**Why it cannot complete.** `build_id` is `{commit}_{job.run_id}` and `built_at` is stamped per
execution, so every run has a new identity and a new manifest digest. An approval naming build A is
therefore unsatisfiable by run B, and there is no path that resumes A. The runner always rebuilds.

**What has to be built.** Three properties, none of them a new framework:

| | requirement |
|---|---|
| 1 | The candidate must SURVIVE the run. Today the run exits leaving only staging, which is written with overwrite semantics — it is not the immutable object an approval can point at. Write the versioned release table BEFORE the exit, and leave the public views alone. |
| 2 | **DONE.** The approval must bind to the PERSISTED bytes. The digest used to be taken over the manifest *before* a `release_approval` block was added and the file put again — so `manifest.yaml` on disk did not hash to the value the approver was told to sign, and a promotion step verifying the file would have rejected the build the approval named. The candidate is now serialized ONCE into `_persisted`, written and hashed from that same string, and never rewritten: the stop is recorded in a sibling `release_candidate.yaml`. Held by `test_the_approved_digest_and_the_persisted_candidate_are_the_same_bytes`, which reads the runner through `ast` rather than by substring — the block explains this failure in a comment, so a text scan would be satisfied by the description of the bug. |
| 3 | Promotion must not rebuild. Add a `promote_build_id` widget: when set, the run reads the existing candidate and its persisted manifest, verifies the approval against them, swaps, stamps `published_at` and copies approver/validator into `sign_off` — and mints nothing. |
| 4 | The approval must be READABLE from where the run executes. **The deployment half is DONE**; the sequencing half is not. `publish_approval_errors(root, rel, …)` opens `<runtime root>/<pack>/handoff/RELEASE_APPROVAL.yaml`, and under `--evidence-out DIR` the whole audit bundle — that file included — used to land in DIR and never enter the tree, so the runner looked where the file was not. `deploy_tree.RUNTIME_EVIDENCE` now deploys it into the tree either way (and still archives it), which is safe unlike the rest of the bundle because it holds no source-provenance prose: six fields, each a name, a date, a build id or a digest. What remains is operational and follows from a tree being digest-bound: the approval names a build produced by a run OF that deployment, so it cannot exist when the deployment is packaged. The sequence has to be **candidate run → sign in the repo and commit → REDEPLOY (new `tree_sha256`) → promotion run**, and the promotion task must accept that its tree digest differs from the candidate's. Either adopt that sequence explicitly, or have the promotion step read the approval from `artifact_root` beside `manifest.yaml`. Not chosen yet. |

Two constraints that are easy to get wrong, and were:

- **Gates 1–4 come from `RELEASE_EVIDENCE.yaml` in prod, not from a live `releasable()`.** The
  allowlisted tree deliberately omits the Gate 1 material a live evaluation needs, so re-deriving
  fails for the reason the packaging exists to create.
- **The manifest status must stay inside `engine.refresh.STATUSES`.** `validate_manifest` rejects
  anything else, and it already requires `sign_off.released_by` for `status: released` — the
  vocabulary for a named releaser has existed all along.

`handoff/RELEASE_APPROVAL.yaml` is in `deploy_tree.PACK_EVIDENCE`, so once written it reaches the
audit bundle — which is where it lands, not necessarily where it is read; see requirement 4.
`source_manifest.publish_approval_errors` is the check and is tested offline; what is untested is the
Databricks control flow, which is exactly the part that needs building.

## What's built vs next

- **Built + tested (pure-Python cores):** refresh manifest build/validate/**write** + `artifacts`
  (`engine/refresh.py`); the **source QC gate** + ADS QC gate + thresholds + **QC report**
  (`engine/qc.py`, `engine/qc_report.py`); the **data dictionary** per neutral audience —
  internal/partner/customer, `partner` replacing the old "sales", with PII drop + `.xlsx`
  (`engine/dictionary.py`); the TFL spec + producibility planner + **product-limit KM** table
  (`engine/tfl.py`); all with catalog cross-checks.
- **R cross-validation engine** (`engine-r/`): a side-by-side R implementation on the **same
  config/YAML**, for the R-proficient team to validate logic and cross-check the build. The
  config→Spark-SQL compilers are **proven byte-identical** to PySpark in CI
  (`tests/test_r_parity.py`); the sparklyr build is review-only and its **acceptance gate is the
  golden-compare** of the R ADS vs the Python ADS (`engine/golden.py`). See `engine-r/README.md`.
- **Runner wired end-to-end** (`databricks/run_rwdp.py`, Spark/cluster-only): preflight →
  **source-QC gate** → build → staging → **ADS QC gate + golden gate** (either failing keeps
  staging, no publish) → **required deliverables** (dictionary + TFLs, each required/optional/skip
  per the config `deliverables:` block; a **required** one that fails blocks publish, status
  recorded) → **durable release ledger** (manifest + QC report written to `artifact_root`,
  **fail-loud**) → **temp-then-swap publish**. The ledger is written BEFORE the swap so a publish
  can never happen without a durable record; `artifact_root` is **writability-probed up front**
  (hard-fail in prod, warn in dev). The pre-swap manifest carries `published_at: null`; it is stamped
  with `published_at` and re-written only AFTER a successful swap, so a null `published_at` can never
  be mistaken for a successful publish. The manifest carries the full source-QC **report + gate**, the
  **golden gate**, and per-deliverable status. A **promote** step commits the manifest from
  `artifact_root` into `refreshes/` (a job can't push to git). Spark execution
  (`run_qc`/`run_golden`/`tfl.generate`/stages) is cluster-only.
- **Next (a lot more):**
  - confirm a first end-to-end cluster run (the bundle has notifications + UC + temp-swap; retries are
    disabled — deterministic QC/golden/source-QC gate failures should not be re-run blindly);
  - figures (KM curve render) + listings export in `tfl.generate`; per-tumor TFL overlays;
  - extend proven R↔Python parity to the inline clinical/OS SQL (death imputation, OS anchor) — see
    `engine-r/README.md` "Next";
  - tumor-class modules (heme Ann Arbor/IPI/Lugano-EFS) — `ROADMAP.md` Phase 7;
  - access control / PII suppression on dashboard + listings.
