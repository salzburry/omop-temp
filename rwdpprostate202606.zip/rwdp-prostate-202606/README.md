# RWD Data Products — GSK Oncology

Real-world oncology **analytic data products (RWDPs)** built on a **locked PySpark engine + per-product
YAML config**. One config-driven engine turns a tumor's `config/` + `variables/` + `codelists/` into a
patient-level analytic dataset (ADS), its data dictionary, and its dashboard / TFL contracts — runnable on
Databricks, governed by a refresh-manifest ledger and a QC + golden-compare publish gate. *Code is locked;
what an analyst tunes is reviewed YAML.*

## Who are you?

**Most people who touch this product never touch this repository.** One RWP operator runs the tooling
and keeps the governed files; everyone else reviews a prepared packet and gives an answer. If you have
been sent here to "update DECISIONS.md and open a pull request", that is the wrong ask — say so, and
ask RWP for the packet instead.

| I am… | What I do | Where |
|---|---|---|
| **Scientific owner (RWB/methodology)** | Answer the questions the specification does not settle, and approve the requirements. You get a **decision packet** — question, evidence, what it blocks, room for the answer. You do not edit YAML, and no tool may fill your answer in. | `decision_packet.py <pack>` — RWP runs it and sends you the output |
| **RWP analyst** | Own the product: run the gates, draft the contract, record the answers, author and approve the configuration. **This is the operator role the tooling assumes.** | `TUMOR_TEMPLATE/NEW_TUMOUR.md`, then `worksheet.py <pack>` for what to do next |
| **RWDE engineer** | Own the shared engine: implement the gaps a product cannot configure around, review the technical execution. | `platform/README.md`, `handoff/ENGINE_GAPS.md` on any pack |
| **QC reviewer / validator** | Review one build's evidence — QC, golden comparison, counts, deliverables — and decide whether it stands. Recorded as `validated_by` on the release approval. | the build's `qc_report.md` + `manifest.yaml`; RWP prepares the summary |
| **Release approver** | Approve one specific build to move the public views, against a build id and a manifest digest you verify yourself. | `TUMOR_TEMPLATE/handoff/RELEASE_APPROVAL.example.yaml` |
| **Stakeholder / manager** | See what the product is, where it stands and what it is waiting on. | `status.py <pack>` — six gates, who owns each, and the next action; ask for the demo below, which you should watch rather than run |
| **Repository maintainer** | Everything else. | `docs/ENGINEERING.md`, then `HANDOVER.md` |

What each gate needs from a human, and who supplies it, is one table in
[`platform/TUMOR_TEMPLATE/NEW_TUMOUR.md`](<platform/TUMOR_TEMPLATE/NEW_TUMOUR.md>).

## Start here

Watch the governed lifecycle happen, read-only, in one command:

```bash
python3 platform/tools/status.py                                   # every product, one line each
python3 platform/tools/status.py products/oncology/prostate/202606 # where it stands, who acts next
python3 platform/tools/demo.py products/oncology/prostate/202606   # the six gates, run end to end
```

It needs Python 3, git and a checkout — so it is a **presenter-led** demo. A stakeholder should watch
it, not be asked to install anything.

The runnable, governed system is **`platform/`** (the shared engine) + **`products/`** (the governed
product configs).

| To… | Read |
|---|---|
| **See it work**, then get the plan + status | [`HANDOVER.md`](./HANDOVER.md) |
| Understand the repo + the **target production structure** | [`docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](./docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md) |
| **Start a new tumor** — the governed sequence, Gate 1 first | [`platform/TUMOR_TEMPLATE/NEW_TUMOUR.md`](<platform/TUMOR_TEMPLATE/NEW_TUMOUR.md>) |
| Author its configuration — Gate 4, *after* the contract exists | [`platform/README.md`](<platform/README.md>) |
| Roadmap / way-forward (phases, onboarding — *historical plan*) | [`products/ROADMAP.md`](<products/ROADMAP.md>) |
| Run / release a refresh (lifecycle, QC, publish, ledger) | [`products/OPERATIONS.md`](<products/OPERATIONS.md>) |
| The **reference product** — prostate 202606 (mHSPC + mCRPC) | [`products/oncology/prostate/README.md`](<products/oncology/prostate/README.md>) |

## Architecture — locked engine, config-driven

```
rwddataproduct/
├── platform/                     the locked, tumor-agnostic engine (shared by every product)
│   ├── VERSION                   the engine SemVer a product pins
│   ├── engine/                   PySpark stages (sources → … → assemble) + validate/QC/golden/release/audit
│   ├── engine-r/                 a side-by-side R (sparklyr/dbplyr) engine on the SAME YAML; its config→SQL
│   │                             COMPILERS are byte-identical in CI — the stage dataflow is not compared
│   ├── databricks/run_rwdp.py    the one tumor-agnostic job entry point
│   └── tests/                    pure-Python suite (CI) + synthetic-Spark + R-parity + governance
├── products/
│   ├── registry.yaml             tumor registry + per-product spec-version lineage
│   ├── metadata/catalog.yaml     cross-tumor master variable catalog (completeness-enforced in CI)
│   ├── _reporting/               shared dashboard / dictionary / tfl contracts
│   ├── oncology/<tumor>/         prostate / oc / endometrial / dlbcl — config + variables + codelists
│   └── OPERATIONS.md · ROADMAP.md   lifecycle + build-framework docs
├── refreshes/                    one committed manifest per (family, product, spec_version, refresh) — the audit ledger
├── releases/                     immutable per-build evidence bundles
├── governance/                   ADR-001 · VERSIONING.md · JSON schemas (the operating contract)
└── databricks.yml                the Asset Bundle; one GENERATED job per product, all paused
```

- **Two version axes** — `spec_version` is the **contract** (CalVer `YYYYMM`, e.g. `202606`); `data_refresh`
  is the **data cut** (e.g. `2026q1`). Every ADS row + manifest is stamped with both.
- **Governed release** — preflight → source-QC → build → ADS-QC + golden-compare → deliverables → durable
  manifest → **Gate 6: a named approval of this build** → immutable versioned tables → sequential view
  swap (TFLs first, ADS last). A released manifest requires `published_at`, a release pointer, and
  `tfl_promotion.passed`.
  **Gate 6 currently BLOCKS and cannot complete:** every run mints a new `build_id`, so an approval of
  one candidate cannot authorise a later run, and no promotion-only path resumes the approved one. The
  prevention works; the promotion does not exist yet. `products/OPERATIONS.md` specifies what to build.
- **Reproducible** — a refresh manifest pins the exact `git_commit`; checkout the tag, re-run the config.

Switch tumor by pointing the job at another `config/`; switch data cut via `--var refresh=…`. No code change.

## Portfolio

Status mirrors [`products/registry.yaml`](<products/registry.yaml>) (test-enforced).

| Family | Product | Source | Registry status |
|---|---|---|---|
| Prostate | **Prostate (mHSPC + mCRPC)** | Flatiron | **active** — reference product, spec `202606` |
| Gynecologic | Ovarian | Flatiron | scaffold |
| Gynecologic | Endometrial | Flatiron | scaffold |
| Lymphoma | DLBCL | COTA | scaffold |
| Lung | NSCLC · SCLC | Flatiron | planned |
| GI / rare solid | mCRC · GIST · HNSCC | Flatiron | planned |
| Myeloid | **MDS** | COTA | scaffold |
| Myeloid | CLL | COTA | planned |

The job is to migrate these existing R-coded products onto the one shared, config-driven engine — not to
rebuild them. Prostate is the most-built pack and the one the engine is validated against — several
RWB-required outputs and methodology decisions still remain (see its
[`202606/handoff/`](<products/oncology/prostate/202606/handoff/>)); the next step is a Databricks dev
smoke on real Flatiron/Panoramic tables.

> **The structure + how it got here:** [`docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md`](./docs/REPO_STRUCTURE_AND_PROD_MIGRATION.md).
