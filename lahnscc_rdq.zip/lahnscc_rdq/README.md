# LA-HNSCC RDQ: how representative is Flatiron?

| | |
|---|---|
| Request | Descriptive characteristics of LA-HNSCC patients in Flatiron (VeevaRIO 338681) |
| Purpose | Describe the Flatiron LA HNSCC custom data **as delivered**, in the same layout as the SEER RDQ Table 1, to judge how representative Flatiron is of the US LA-HNSCC population |
| Asset / TA | 61431, Dostarlimab (GSK4057190), JADE HNSCC |
| Requestor | Vicky Tribble (Epidemiology, Oncology) |
| RWB lead / analyst | Julia Moore / Shirley Liao |
| Data | Flatiron "GSK Dostarlimab Locally Advanced Head & Neck Custom Data", `clnprw_flatiron_la_hnc_use`, July 2026 delivery, data cut-off Dec 2025 |
| Output | Table 1: number of cases in the Flatiron database, 2019 to 2025, split into Overall, Unresected, Resected and Unknown, and its comparison with SEER |

## Running it

```r
setwd("<project root>")
source("run_all.R")
```

* **Connection:** ODBC, DSN `DATABRICKS_DSN` (default `RWDE`) with `DATABRICKS_PWD`, then `USE CATALOG` `DATABRICKS_CATALOG` (default `hive_metastore`). A live ODBC connection already in the session (`con`) is reused.
* **Finding the tables:** tables are renamed on load (a `t_` prefix, `enh` for Enhanced, abbreviations such as `drg_epsode`). `00_setup.R` therefore finds each table by a name pattern (`tbl_patterns`) in `SHOW TABLES` for refresh `RDQ_REFRESH`, and prints the tables it picked.
  * It stops if a required pattern matches zero tables, or more than one.
  * To pin a table by exact name, set `RDQ_TBL_<KEY>`, for example `RDQ_TBL_DRUGEP=t_enh_lahnc_drg_epsode`.
  * The two recurrence tables are optional. If either is missing, the run warns and carries on.
* **Outputs** go to `RDQ_OUT_DIR` (default `/mnt/artifacts/results/`). The program checks that the folder is writable before it starts.

| File | Content |
|---|---|
| `TFL_HNSCC_FI_RDQ_v0.1_<DDMONYYYY>.xlsx` | `Table 1`, `Attrition`, `SEER comparison` and `Representativeness` (when a SEER table is supplied), `Run metadata` |
| `..._table1_long.csv`, `..._ads.rds` | Table 1 in long form and the patient-level dataset, for the independent QC |
| `..._sessionInfo.txt` | R and package versions |

| File | Content |
|---|---|
| `R/00_setup.R` | Parameters, dictionary code lists, connection, table lookup |
| `R/01_cohort.R` | Study population and attrition |
| `R/02_derive.R` | One row per patient, with every Table 1 variable; checks every coded field against the dictionary |
| `R/03_table1.R` | Table in the shell layout, footnotes, Table 1 and Attrition sheets |
| `R/04_seer_compare.R` | Flatiron vs SEER: standardized differences and representativeness rating |
| `R/05_output.R` | Run metadata; writes the outputs |
| `inputs/seer_table1_TEMPLATE.csv` | Template to fill with the SEER RDQ's Table 1 |

## Source tables (Flatiron data dictionary)

| Key | Dictionary table | Fields used |
|---|---|---|
| cohort | Enhanced_LAHNC | PatientID, DiagnosisDate, AdvancedDiagnosisDate, GroupStage, HPVStatus |
| surgery | Enhanced_LAHNC_PrimarySurgery | SurgeryType |
| radiation | Enhanced_LAHNC_RadiationTherapy | RTStartDate, RTStartDateGranularity, RTSite |
| drugep | DrugEpisode | LineSetting, DrugName, DetailedDrugCategory; DrugCategory, EpisodeDate and EnhancedCohort if present |
| localrec (optional) | Enhanced_LAHNC_LocalRecurrence | LocalRecurDate |
| metrec (optional) | Enhanced_LAHNC_MetRecurrence | DistantMetDate |
| diagnosis | Diagnosis | DiagnosisCode, DiagnosisCodeSystem |
| demo | Demographics | BirthYear, BirthSex, Race, Ethnicity |
| practice | Practice | PracticeType |

The program prints the frequency of every coded field it uses. It warns when a value is outside the dictionary coding, so a spelling it does not expect never falls silently into "Unknown". Comparisons ignore case and spacing.

## Study population

The dataset is described as delivered. Flatiron has already applied the LA-HNSCC criteria. The program then:

1. Takes every patient in `Enhanced_LAHNC`, which has one row per patient.
2. Excludes patients with any ICD-10 C11.x or C12.x diagnosis, or the ICD-9 equivalents 147.x and 148.1. This is the exclusion added in the RDQ.
   * ICD-10 codes start with a letter and ICD-9 codes do not, so the program recognises the code system from the code itself.
   * A row with a null `DiagnosisCodeSystem` (allowed by the dictionary) is therefore still checked.

The diagnosis years are not a filter (`restrict_dx_window = FALSE`). Any patient diagnosed outside 2019–2025 appears in an "Outside 2019-2025" row.

## Variable derivations

| Table row | Derivation |
|---|---|
| Surgery group (columns) | Uses `SurgeryType`. **Resected**: "Primary tumor resection only" or "Primary tumor resection and lymph node dissection". **Unresected**: "Lymph node dissection only". **Unknown**: "Unknown/not specified". Other values, such as the dictionary's example "Endoscopic mucosal resection", are mapped by keyword and raise a warning. When a patient has several records, the precedence is Resected > Unknown > Unresected. Patients with no primary-surgery record are counted as Unresected, which matches SEER's "no surgery" code 00 (`no_surgery_group`). Salvage surgery is not used. |
| Sex | `BirthSex` F/M; otherwise Unknown, a row added beyond the shell |
| Age at diagnosis | Year of `DiagnosisDate` minus `BirthYear`. Mean (SD) and median [IQR], both to 1 decimal. |
| Age group | <18, 18-39, 40-64, 65-74, 75+; an Unknown row appears if a birth year is missing |
| Race/ethnicity | Hispanic (all races) if `Race` or `Ethnicity` is "Hispanic or Latino". Otherwise White becomes non-Hispanic (NH) White, "Black or African American" becomes NH Black, and Asian becomes NH Asian or Pacific Islander. AIAN and NHPI values are mapped to the SEER rows if they occur. Other Race and missing go to **Other/Unknown**, a row added beyond the shell. The footnote says whether AIAN/NHPI values occurred. |
| Year of diagnosis | Calendar year of `DiagnosisDate` |
| Stage at diagnosis | `GroupStage` collapsed to 0, I, II, III or IV (IVA/IVB/IVC become IV), otherwise Unknown. Inclusion is stage III/IV, so the 0, I and II rows are 0; they are kept to match the shell. |
| HPV status | `HPVStatus`: "HPV positive" becomes Positive and "HPV negative" becomes Negative. Equivocal, indeterminate, pending, unknown and missing become Other/Unknown. |
| Receipt of chemotherapy (1L) | SEER **first course**. **Yes** if a `DrugEpisode` row has `LineSetting` in NEOADJUVANT, INDUCTION CHEMO, CONCURRENT, ADJUVANT, EARLY or RADIATION THERAPY, and the drug counts as chemotherapy. The therapy class comes from **`DetailedDrugCategory`**; `DrugCategory` is the broad pharmacological class. `chemo_definition` sets what counts: `seer` (default) is DetailedDrugCategory chemotherapy plus cetuximab; `cytotoxic` is chemotherapy only; `any_systemic` is any antineoplastic, not supportive care. Excluded settings: ADVANCED and LOCOREGIONAL (recurrence), OFF SYSTEMIC THERAPY, and a missing setting. Chemotherapy in excluded settings is counted in the log. The run stops if first-course drug rows exist but none is classed as chemotherapy. The `EnhancedCohort` values are printed, and several values stop the run until `drug_cohorts` is set. |
| Receipt of radiation (1L) | **Yes** if an `Enhanced_LAHNC_RadiationTherapy` course meets all of these: `RTSite` is the primary site (including regional lymph nodes) or unknown/missing; it starts no earlier than 30 days before diagnosis; and it starts before the end of first course. First course ends at the earliest of first locoregional recurrence (`LocalRecurDate`), distant recurrence (`DistantMetDate`) and `AdvancedDiagnosisDate`. A start date known only to the month or year (`RTStartDateGranularity`) counts when its whole possible range lies inside the window (`rt_coarse_rule = "within"`; `"overlap"` is the lenient alternative). Primary-site courses with no start date are counted in the log, not in the table. |
| Type of reporting source | `Practice.PracticeType`: Academic only, Community only, Both, or Unknown |

Percentages are column percentages within each surgery group. The "Overall" row gives each group's share of the whole cohort. The table follows the shell, with Male and Female directly under Overall. Rows added beyond the shell are named in a footnote.

## SEER comparison: is Flatiron representative?

1. Take the template. The supplied `inputs/seer_table1_TEMPLATE.csv` has every shell row. A run without a SEER table also writes `seer_table1_TEMPLATE_generated.csv` to the output folder, which adds any data-dependent rows for that delivery.
2. Fill it from the SEER RDQ output and save it as CSV.
   * `inputs/seer_table1.csv` is the default path. To keep it elsewhere (for example on a Domino dataset), point `RDQ_SEER_TABLE` to it.
   * `RDQ_REQUIRE_SEER=1` turns a missing file into an error instead of a warning.
3. For each surgery group SEER reports (Overall, Unresected, Resected, Unknown), each row needs:
   * `n` (SEER count; "1,440" is accepted) or `pct` (column %; on the Incidence row, each group's **share of the whole cohort**);
   * `mean` and `sd` on the age "Mean (sd)" row.

   Groups SEER doesn't report can be left out. SEER suppression marks ("<16", "^", "*") are read as suppressed. Any other non-numeric value stops the run, as do duplicated rows and unknown group names. Excel's "CSV UTF-8" (with BOM) is fine.
4. Re-run `run_all.R`. The workbook gains:
   * **SEER comparison:** one row per category. Shows Flatiron % vs SEER % (as entered and as compared), the difference in percentage points, and the standardized difference (SMD).
   * **Representativeness:** one row per variable and surgery group. Shows one SMD and a rating, the category with the largest gap, the Flatiron share in categories SEER doesn't report, and notes.

**How the comparison works**
* **Not-reported categories:** a category with neither n nor pct is treated as *not reported*, for example the Flatiron-only rows Sex Unknown and Race Other/Unknown. It is left out on **both** sides, and both sides are re-normalised. The Flatiron share in such categories is shown, so a difference in missingness stays visible. Enter 0 for a true SEER zero.
* **Counts and percentages:** reported categories use n when all have n, pct when all have pct, and a mix otherwise. In a mix, n is converted to a % of the SEER group N from the Incidence row.
* **Statistics:**
  * Categorical variables use the multi-category SMD (Yang & Dalton 2012). Age uses the difference in means divided by the pooled SD. Complete separation shows as `Inf`.
  * Ratings: |SMD| < 0.1 is **Similar**, 0.1 to < 0.2 is **Small difference**, and 0.2 or more is **Meaningful difference**.
  * Standardized differences are used instead of p-values, because SEER is so large that any test comes out "significant".
* **Surgery split:** compared as "Surgery group (share of cohort)".

Flatiron can never be *exactly* representative. The output shows which characteristics match SEER, which don't, and by how much.

## Run record

The **Run metadata** sheet records:
* the code fingerprint (MD5 of `R/*.R` and `run_all.R`);
* the connection (DSN, catalog);
* the source schema, refresh and tables picked;
* every parameter;
* the SEER file's path and MD5, and the groups compared.

## Settings from the environment

A variable that is set but blank counts as unset.

| Variable | Default |
|---|---|
| `DATABRICKS_PWD` | required |
| `DATABRICKS_DSN` | `RWDE` |
| `DATABRICKS_CATALOG` | `hive_metastore` |
| `RDQ_SOURCE_SCHEMA` | `clnprw_flatiron_la_hnc_use` (bare schema name, or `<DATABRICKS_CATALOG>.<schema>`) |
| `RDQ_REFRESH` | `2026m07` |
| `RDQ_OUT_DIR` | `/mnt/artifacts/results/` |
| `RDQ_SEER_TABLE` | `inputs/seer_table1.csv` |
| `RDQ_REQUIRE_SEER` | unset (set `1` to require the SEER table) |
| `RDQ_TBL_<KEY>` | unset (exact table name for a key: COHORT, SURGERY, RADIATION, DRUGEP, DIAGNOSIS, DEMO, PRACTICE, LOCALREC, METREC) |

## Open questions

1. **Table names.** Confirm the tables printed on the first run. If one is missed, set `RDQ_TBL_<KEY>`.
2. **Patients with no surgery.** These are counted as Unresected, to match SEER code 00. Confirm this against the SEER RDQ.
3. **Chemotherapy definition.** Does SEER count cetuximab as chemotherapy? Check SEER*Rx. Should EARLY and RADIATION THERAPY line settings count as first course? Check the `DetailedDrugCategory` and `EnhancedCohort` values printed on the first run.
4. **Radiation.** Is "before the earliest of first locoregional recurrence, distant recurrence and advanced diagnosis" the right end of first course? Should radiation to an unknown or missing RT site count? Which rule for month/year-only dates?
5. **C11/C12 exclusion.** Currently excludes on any such code. The alternative is to exclude only when it is the primary site.
6. **Reporting source.** SEER's "Type of Reporting Source" (hospital, radiation centre, and so on) is a different concept from Flatiron's academic/community split.
7. **Stage edition.** Is Flatiron's `GroupStage` for HPV+ oropharynx AJCC 7th or 8th edition? This affects comparability with SEER.
8. **rw-TTD.** Mentioned in the RDQ description but not in the shell. Not implemented.
9. **SEER comparison.** Before reading the ratings, check that SEER's LA definition and treatment variables match the definitions used here; see items 2, 3, 4 and 7.
