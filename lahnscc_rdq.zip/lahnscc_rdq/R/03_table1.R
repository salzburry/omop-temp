# =============================================================================
# 03_table1.R : Table 1 in the layout of the table shell, and the Table 1 /
#               Attrition sheets
# =============================================================================
# Columns : Overall | Unresected | Resected | Unknown  (n, %)
# Percent : column % within each surgery group; the "Overall" row gives each
#           group's share of the whole cohort.
# The workbook `wb` (Table 1, Attrition; SEER and Run metadata sheets are added
# later) is saved in 05_output.R.
# =============================================================================

groups <- c("Overall", levels(ads$surg_group))
grp_data <- c(list(Overall = ads), split(ads, ads$surg_group))

fmt_pct <- function(n, d) if (d > 0) sprintf("%.1f", 100 * n / d) else rep("-", length(n))

# One categorical block -> rows with n / % per group. A missing value is an
# "Unknown" row (added only when it occurs).
cat_block <- function(var, header) {
  lv <- levels(ads[[var]])
  has_missing <- anyNA(ads[[var]])
  labels <- c(lv, if (has_missing) "Unknown")
  rows <- lapply(groups, function(g) {
    d <- grp_data[[g]]
    x <- as.character(d[[var]]); x[is.na(x)] <- "Unknown"
    n <- vapply(labels, function(l) sum(x == l), numeric(1))
    tibble(label = labels, group = g, n_num = n, n = as.character(n),
           pct = fmt_pct(n_num, nrow(d)))
  })
  bind_rows(tibble(label = header, group = groups, n = "", n_num = NA, pct = "",
                   is_header = TRUE),
            bind_rows(rows) %>% mutate(is_header = FALSE))
}

# Mean (sd) and median [IQR], both to one decimal. `pop` = patients with a
# known value, the population behind the statistic.
cont_block <- function(var, header) {
  rows <- lapply(groups, function(g) {
    x <- grp_data[[g]][[var]]
    if (sum(!is.na(x)) == 0) {
      return(tibble(label = c("Mean (sd)", "Median [IQR]"), group = g, pop = 0,
                    n = "-", n_num = NA, pct = ""))
    }
    q <- quantile(x, c(.25, .5, .75), na.rm = TRUE)
    s <- sd(x, na.rm = TRUE)
    tibble(label = c("Mean (sd)", "Median [IQR]"), group = g, pop = sum(!is.na(x)),
           n = c(sprintf("%.1f (%s)", mean(x, na.rm = TRUE),
                         if (is.na(s)) "-" else sprintf("%.1f", s)),
                 sprintf("%.1f [%.1f, %.1f]", q[2], q[1], q[3])),
           n_num = NA, pct = "")
  })
  bind_rows(tibble(label = header, group = groups, n = "", n_num = NA, pct = "",
                   is_header = TRUE),
            bind_rows(rows) %>% mutate(is_header = FALSE))
}

overall_block <- function() {
  N <- nrow(ads)
  rows <- lapply(groups, function(g) {
    n <- nrow(grp_data[[g]])
    tibble(label = "Overall", group = g, n_num = n, n = as.character(n),
           pct = fmt_pct(n_num, N))
  })
  bind_rows(tibble(label = "Incidence of Head and Neck Squamous Cell Carcinoma",
                   group = groups, n = "", n_num = NA, pct = "", is_header = TRUE),
            bind_rows(rows) %>% mutate(is_header = FALSE))
}

blocks <- list(
  overall_block(),
  cat_block("sex",       "Sex"),
  cont_block("age",      "Age at diagnosis (years)"),
  cat_block("age_cat",   "Age at diagnosis (categorical)"),
  cat_block("race_eth",  "Race/Ethnicity"),
  cat_block("dx_year",   "Year of Diagnosis"),
  cat_block("stage",     "Stage at diagnosis"),
  cat_block("hpv",       "HPV status"),
  cat_block("chemo",     "Receipt of chemotherapy (1L)"),
  cat_block("radiation", "Receipt of radiation (1L)"),
  cat_block("reporting", "Type of Reporting Source")
)

long <- bind_rows(lapply(seq_along(blocks), function(i)
  blocks[[i]] %>% mutate(block = i,
                         section = label[is_header][1],
                         row = match(paste(label, is_header),
                                     unique(paste(label, is_header))))))
if (!"pop" %in% names(long)) long$pop <- NA_real_

to_wide <- function(df) {
  df %>%
    select(block, row, section, label, is_header, group, n, pct) %>%
    pivot_wider(names_from = group, values_from = c(n, pct), names_vary = "slowest") %>%
    arrange(block, row) %>%
    select(section, label, is_header, all_of(as.vector(rbind(paste0("n_", groups),
                                                             paste0("pct_", groups)))))
}

table1 <- to_wide(long)

# =============================================================================
# Footnotes, built from the parameters so they always describe the run
# =============================================================================
chemo_txt <- switch(chemo_definition,
  seer         = paste0("a drug with DetailedDrugCategory chemotherapy, or ",
                        paste(seer_extra_chemo, collapse = "/"), " (coded as chemotherapy in SEER*Rx)"),
  cytotoxic    = "a drug with DetailedDrugCategory chemotherapy",
  any_systemic = "any systemic drug (including immunotherapy and targeted therapy)")
rt_txt <- paste0("an RT course to ",
                 paste(sub(" \\(.*", "", rt_sites_first_course), collapse = " or "),
                 if (any(grepl("^Unknown", rt_sites_first_course))) " (including a missing site)" else "",
                 " starting no earlier than ", rt_lookback_days, " days before diagnosis and before the ",
                 "earliest of first locoregional recurrence, distant recurrence and advanced diagnosis",
                 if (rt_coarse_rule == "within") "; a start date known only to the month/year must fall wholly inside that window"
                 else "; a start date known only to the month/year counts if any part falls inside that window")
footnotes <- c(
  paste0("Source: Flatiron GSK Dostarlimab LA Head & Neck custom data (", dbname, ", refresh ", refresh,
         "); data cut-off ", format(datacut, "%d%b%Y"), "."),
  "Percentages are column percentages within each surgery group; the Overall row shows each group's share of the cohort.",
  paste0("Surgery type re-categorised to SEER definitions: Resected = primary tumour resection +/- lymph node dissection; ",
         "Unresected = lymph node dissection only; Unknown = unknown/not specified; patients with no primary-surgery record are counted as ",
         no_surgery_group, ". Salvage surgery is not used."),
  "Age = year of diagnosis - birth year (Flatiron provides birth year only).",
  paste0("Receipt of chemotherapy (1L) = first course (SEER): ", chemo_txt, " in a ",
         paste(first_course_settings, collapse = ", "), " line."),
  paste0("Receipt of radiation (1L) = first course (SEER): ", rt_txt, "."),
  paste0("Rows not in the SEER shell, so each block adds up to its group N: Sex Unknown (BirthSex missing), ",
         "Race/Ethnicity Other/Unknown (Other Race or missing)",
         "; an 'Unknown' age or year row appears only when birth year or diagnosis date is missing",
         if (any(grepl("^Outside", long$label))) paste0("; 'Outside ", min(dx_years), "-", max(dx_years), "' counts diagnoses outside the reporting years") else "",
         "."),
  if (aian_nhpi_present)
    "Race: American Indian/Alaska Native and Native Hawaiian/Pacific Islander values occur in this delivery and are mapped to the SEER rows."
  else
    "Race: the Flatiron delivery has no American Indian/Alaska Native or Native Hawaiian/Pacific Islander value, so the NH AIAN row is 0 and those patients, if any, are in Other/Unknown."
)

# =============================================================================
# Excel sheets in the shell's layout
# =============================================================================
write_table_sheet <- function(wb, sheet, tab, notes) {
  addWorksheet(wb, sheet, gridLines = FALSE)
  hdr  <- createStyle(fgFill = "#000000", fontColour = "#FFFFFF",
                      textDecoration = "bold", halign = "center", border = "TopBottomLeftRight")
  sec  <- createStyle(fgFill = "#D9D9D9", textDecoration = "bold", border = "TopBottomLeftRight")
  body <- createStyle(border = "TopBottomLeftRight", halign = "center")
  lab  <- createStyle(border = "TopBottomLeftRight", indent = 1)

  top <- 1
  writeData(wb, sheet, "Table 1", startRow = top, startCol = 1)
  writeData(wb, sheet, sprintf("Number of cases in Flatiron database, %d to %d",
                               min(dx_years), max(dx_years)), startRow = top, startCol = 2)
  mergeCells(wb, sheet, cols = 2:9, rows = top)
  for (i in seq_along(groups)) {
    c0 <- 2 * i
    writeData(wb, sheet, groups[i], startRow = top + 1, startCol = c0)
    mergeCells(wb, sheet, cols = c0:(c0 + 1), rows = top + 1)
    writeData(wb, sheet, t(c("n", "%")), startRow = top + 2, startCol = c0, colNames = FALSE)
  }
  addStyle(wb, sheet, hdr, rows = top:(top + 2), cols = 1:9, gridExpand = TRUE)

  # The shell has no "Sex" header row: Male/Female follow Overall directly.
  out <- tab %>%
    filter(!(is_header & section == "Sex")) %>%
    mutate(across(-c(section, label, is_header), ~ if_else(is_header, "", .x)))
  writeData(wb, sheet, out %>% select(-section, -is_header), startRow = top + 3, colNames = FALSE)
  r <- top + 2 + seq_len(nrow(out))
  addStyle(wb, sheet, lab,  rows = r, cols = 1,   gridExpand = TRUE)
  addStyle(wb, sheet, body, rows = r, cols = 2:9, gridExpand = TRUE)
  addStyle(wb, sheet, sec,  rows = r[out$is_header], cols = 1:9, gridExpand = TRUE)

  writeData(wb, sheet, c(notes, paste0("Program run: ", format(run_started, "%d%b%Y %H:%M"))),
            startRow = max(r) + 2, startCol = 1)
  setColWidths(wb, sheet, cols = 1, widths = 52)
  setColWidths(wb, sheet, cols = 2:9, widths = 12)
}

wb <- createWorkbook()
write_table_sheet(wb, "Table 1", table1, footnotes)
addWorksheet(wb, "Attrition")
writeData(wb, "Attrition", attrition)
setColWidths(wb, "Attrition", cols = 1:3, widths = c(70, 12, 12))

# Saved in R/05_output.R, after the SEER comparison sheets are added.
