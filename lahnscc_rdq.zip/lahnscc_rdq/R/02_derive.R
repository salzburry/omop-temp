# =============================================================================
# 02_derive.R : one row per patient with every Table 1 variable
# =============================================================================
# Field names and coded values follow the Flatiron data dictionary for the
# GSK Dostarlimab LA Head & Neck custom data. Rules are listed in README.md.
# Every coded field is printed and checked against the dictionary coding
# (codes, 00_setup.R): a value outside it is a warning, never a silent fall
# into the residual category. Comparisons ignore case and spacing.
# =============================================================================

pull_ids <- function(key, ...) {
  src(key) %>% filter(patientid %in% !!cohort_ids) %>% select(patientid, ...) %>% collect()
}

nz <- function(v) tolower(gsub("[[:space:]]+", " ", trimws(as.character(v))))

check_codes <- function(x, field, expected) {
  message(field, ":")
  print(as.data.frame(table(value = x, useNA = "ifany"), stringsAsFactors = FALSE),
        row.names = FALSE)
  ex   <- nz(expected)
  wild <- sub("\\*$", "", ex[grepl("\\*$", ex)])
  ex   <- ex[!grepl("\\*$", ex)]
  v    <- unique(x[!is.na(x)])
  ok   <- nz(v) %in% ex | vapply(nz(v), function(z) any(startsWith(z, wild)), logical(1))
  bad  <- v[!ok]
  if (length(bad)) {
    warning(field, ": value(s) not in the data dictionary coding: ",
            paste0("'", bad, "'", collapse = ", "),
            " - check how they are mapped.", call. = FALSE)
  }
  invisible(bad)
}

# ---- Demographics -----------------------------------------------------------
demo <- pull_ids("demo", birthyear, birthsex, race, ethnicity)
stopifnot(!anyDuplicated(demo$patientid))   # dictionary: one record per patient
check_codes(demo$birthsex,  "Demographics.BirthSex",  codes$birthsex)
check_codes(demo$race,      "Demographics.Race",      codes$race)
check_codes(demo$ethnicity, "Demographics.Ethnicity", codes$ethnicity)
aian_nhpi_present <- any(nz(demo$race) %in% nz(c("American Indian or Alaska Native",
                                                 "Native Hawaiian or Other Pacific Islander")))

# ---- Reporting source (Practice.PracticeType) --------------------------------
practice_raw <- pull_ids("practice", practicetype)
check_codes(practice_raw$practicetype, "Practice.PracticeType", codes$practicetype)
practice <- practice_raw %>%
  mutate(pt = nz(practicetype)) %>%
  group_by(patientid) %>%
  summarise(any_acad = any(pt %in% "academic"),
            any_comm = any(pt %in% "community"),
            .groups = "drop")

# ---- Surgery (Enhanced_LAHNC_PrimarySurgery.SurgeryType) --------------------
surg_raw <- pull_ids("surgery", surgerytype)
unmapped <- check_codes(surg_raw$surgerytype, "PrimarySurgery.SurgeryType", codes$surgerytype)
if (length(unmapped)) {
  message("SurgeryType values outside the coding are mapped by keyword: ",
          paste(unmapped, collapse = "; "))
}

# Patient-level precedence: Resected > Unknown > Unresected (an unspecified
# record could hide a primary resection, so it outranks LND-only).
surg_lookup <- setNames(unname(surgery_map), nz(names(surgery_map)))
surgery <- surg_raw %>%
  mutate(s = nz(coalesce(surgerytype, "")),
         rec_cat = coalesce(
           unname(surg_lookup[s]),
           case_when(grepl("lymph node|neck dissection", s) &
                       !grepl("primary", s)           ~ "Unresected",
                     grepl("resection", s)            ~ "Resected",
                     TRUE                             ~ "Unknown"))) %>%
  group_by(patientid) %>%
  summarise(surg_group = case_when(any(rec_cat == "Resected") ~ "Resected",
                                   any(rec_cat == "Unknown")  ~ "Unknown",
                                   TRUE                       ~ "Unresected"),
            .groups = "drop")

# ---- Chemotherapy, first course (DrugEpisode) --------------------------------
drug_cols <- intersect(c("linesetting", "drugname", "drugcategory",
                         "detaileddrugcategory", "episodedate", "enhancedcohort"),
                       colnames(src("drugep")))
for (need in c("linesetting", "drugname", "detaileddrugcategory")) {
  if (!need %in% drug_cols)
    stop("DrugEpisode has no column '", need, "' - check the delivery.", call. = FALSE)
}
drugs <- pull_ids("drugep", all_of(drug_cols)) %>%
  mutate(linesetting = toupper(gsub("[[:space:]]+", " ", trimws(linesetting))))
if (!"drugcategory" %in% names(drugs)) drugs$drugcategory <- NA_character_
check_codes(drugs$linesetting, "DrugEpisode.LineSetting", codes$linesetting)
message("DrugEpisode LineSetting x DrugCategory x DetailedDrugCategory:")
print(as.data.frame(count(drugs, linesetting, drugcategory, detaileddrugcategory)),
      row.names = FALSE)

if ("enhancedcohort" %in% drug_cols) {
  coh <- sort(unique(drugs$enhancedcohort))
  message("DrugEpisode.EnhancedCohort: ", paste(coh, collapse = ", "))
  if (is.null(drug_cohorts)) {
    if (length(coh) > 1)
      stop("DrugEpisode has several EnhancedCohort values (", paste(coh, collapse = ", "),
           "). Set drug_cohorts in R/00_setup.R to the LA-HNC value(s).", call. = FALSE)
  } else {
    drugs <- drugs %>% filter(enhancedcohort %in% drug_cohorts)
  }
}

drugs <- drugs %>%
  mutate(is_chemo_cat = grepl("chemo", nz(coalesce(detaileddrugcategory, ""))) |
                        grepl("chemo", nz(coalesce(drugcategory, ""))),
         is_chemo = switch(chemo_definition,
           seer         = is_chemo_cat | grepl(paste(seer_extra_chemo, collapse = "|"),
                                               nz(drugname)),
           cytotoxic    = is_chemo_cat,
           # antineoplastic drugs only: supportive care (antiemetics, growth
           # factors, ...) recorded in a line is not systemic cancer therapy
           any_systemic = grepl("antineoplastic", nz(coalesce(drugcategory, ""))) |
                          grepl("chemo|immuno|target|hormon|biolog",
                                nz(coalesce(detaileddrugcategory, ""))),
           stop("chemo_definition must be seer, cytotoxic or any_systemic")),
         first_course = linesetting %in% first_course_settings)

off_course <- drugs %>% filter(is_chemo, !first_course)
message("Chemotherapy episodes outside first-course settings (not counted): ",
        nrow(off_course), " episode(s), ", n_distinct(off_course$patientid),
        " patient(s); by setting:")
print(as.data.frame(count(off_course, linesetting)), row.names = FALSE)

chemo_fc <- drugs %>%
  filter(first_course) %>%
  group_by(patientid) %>%
  summarise(chemo_fc = any(is_chemo), .groups = "drop")

if (chemo_definition != "any_systemic" && nrow(chemo_fc) > 0 && !any(chemo_fc$chemo_fc)) {
  stop("First-course drug episodes exist but none is classed as chemotherapy - ",
       "check DetailedDrugCategory coding (printed above).", call. = FALSE)
}

# ---- Radiation, first course (Enhanced_LAHNC_RadiationTherapy) ---------------
# End of first course: earliest of first locoregional recurrence, distant
# recurrence and AdvancedDiagnosisDate (optional tables may be absent).
first_date <- function(key, col) {
  if (!key %in% names(tbl_map)) return(tibble(patientid = character(), d = as.Date(character())))
  if (!col %in% colnames(src(key))) {
    warning("Table '", key, "' has no column '", col, "' - not used for the first-course end.",
            call. = FALSE)
    return(tibble(patientid = character(), d = as.Date(character())))
  }
  pull_ids(key, d = !!rlang::sym(col)) %>%
    mutate(d = as.Date(d)) %>%
    filter(!is.na(d)) %>%
    group_by(patientid) %>% summarise(d = min(d), .groups = "drop")
}
fc_end <- cohort %>%
  select(patientid, adv_date) %>%
  left_join(first_date("localrec", "localrecurdate") %>% rename(lr_date = d), by = "patientid") %>%
  left_join(first_date("metrec",   "distantmetdate") %>% rename(dm_date = d), by = "patientid") %>%
  mutate(fc_end = pmin(adv_date, lr_date, dm_date, na.rm = TRUE)) %>%
  select(patientid, fc_end)

rt_cols <- intersect(c("rtstartdate", "rtstartdategranularity", "rtsite"),
                     colnames(src("radiation")))
rt_raw <- pull_ids("radiation", all_of(rt_cols))
if (!"rtstartdategranularity" %in% rt_cols) rt_raw$rtstartdategranularity <- NA_character_
check_codes(rt_raw$rtsite, "RadiationTherapy.RTSite", codes$rtsite)
check_codes(rt_raw$rtstartdategranularity, "RadiationTherapy.RTStartDateGranularity",
            codes$granularity)

rt_rows <- rt_raw %>%
  mutate(rtstartdate = as.Date(rtstartdate),
         g  = toupper(coalesce(trimws(rtstartdategranularity), "DAY")),
         lo = case_when(g == "YEAR"  ~ floor_date(rtstartdate, "year"),
                        g == "MONTH" ~ floor_date(rtstartdate, "month"),
                        TRUE         ~ rtstartdate),
         hi = case_when(g == "YEAR"  ~ ceiling_date(rtstartdate, "year", change_on_boundary = TRUE) - 1,
                        g == "MONTH" ~ ceiling_date(rtstartdate, "month", change_on_boundary = TRUE) - 1,
                        TRUE         ~ rtstartdate),
         site_ok = nz(coalesce(rtsite, "Unknown/not documented")) %in% nz(rt_sites_first_course)) %>%
  inner_join(cohort %>% select(patientid, dx_date), by = "patientid") %>%
  left_join(fc_end, by = "patientid")

n_nodate <- rt_rows %>% filter(site_ok, is.na(rtstartdate))
message("Primary-site RT courses with no start date (cannot be placed; not counted): ",
        nrow(n_nodate), " course(s), ", n_distinct(n_nodate$patientid), " patient(s).")

rt_fc <- rt_rows %>%
  filter(site_ok, !is.na(rtstartdate)) %>%
  mutate(win_lo = dx_date - rt_lookback_days,
         in_win = if (rt_coarse_rule == "overlap")
                    hi >= win_lo & (is.na(fc_end) | lo < fc_end)
                  else
                    lo >= win_lo & (is.na(fc_end) | hi < fc_end)) %>%
  filter(in_win) %>%
  distinct(patientid) %>%
  mutate(rt_fc = TRUE)

# ---- Assemble ---------------------------------------------------------------
check_codes(cohort$groupstage, "Enhanced_LAHNC.GroupStage", codes$groupstage)
check_codes(cohort$hpvstatus,  "Enhanced_LAHNC.HPVStatus",  codes$hpvstatus)

# GroupStage coding: III, IV, IVA, IVB, Unknown/not documented. Stage 0 is
# tested first and the numerals are anchored, so "IS" is not read as "I" and
# free text is Unknown (and warned about by check_codes above).
roman_stage <- function(x) {
  y <- toupper(gsub("(?i)stage|\\s", "", x, perl = TRUE))
  case_when(grepl("^(0|0IS|T?IS)$", y) ~ "0",
            grepl("^IV[ABC]?$",  y)     ~ "IV",
            grepl("^III[ABC]?$", y)     ~ "III",
            grepl("^II[ABC]?$",  y)     ~ "II",
            grepl("^I[ABC]?$",   y)     ~ "I",
            TRUE                        ~ "Unknown")
}
outside_lab <- sprintf("Outside %d-%d", min(dx_years), max(dx_years))
rc <- function(x) nz(x)

ads <- cohort %>%
  left_join(demo,      by = "patientid") %>%
  left_join(practice,  by = "patientid") %>%
  left_join(surgery,   by = "patientid") %>%
  left_join(chemo_fc,  by = "patientid") %>%
  left_join(rt_fc,     by = "patientid") %>%
  mutate(
    surg_group = factor(coalesce(surg_group, no_surgery_group),
                        levels = c("Unresected", "Resected", "Unknown")),

    sex = factor(case_when(rc(birthsex) %in% c("f", "female") ~ "Female",
                           rc(birthsex) %in% c("m", "male")   ~ "Male",
                           TRUE ~ "Unknown"),
                 levels = c("Male", "Female", "Unknown")),

    # Flatiron provides birth year only -> age = diagnosis year - birth year
    age = year(dx_date) - suppressWarnings(as.numeric(birthyear)),
    age_cat = cut(age, c(-Inf, 17, 39, 64, 74, Inf),
                  labels = c("<18 years", "18-39 years", "40-64 years",
                             "65-74 years", "75+ years")),

    race_eth = factor(case_when(
      rc(race) == "hispanic or latino" | rc(ethnicity) == "hispanic or latino"
                                                   ~ "Hispanic (All Races)",
      rc(race) == "white"                          ~ "Non-Hispanic White",
      rc(race) == "black or african american"      ~ "Non-Hispanic Black",
      rc(race) == "american indian or alaska native" ~
                                     "Non-Hispanic American Indian/Alaska Native",
      rc(race) %in% c("asian", "native hawaiian or other pacific islander")
                                ~ "Non-Hispanic Asian or Pacific Islander",
      TRUE                                         ~ "Other/Unknown"),
      levels = c("Non-Hispanic White", "Non-Hispanic Black",
                 "Non-Hispanic American Indian/Alaska Native",
                 "Non-Hispanic Asian or Pacific Islander",
                 "Hispanic (All Races)", "Other/Unknown")),

    dx_year = factor(case_when(is.na(dx_date)                 ~ NA_character_,
                               year(dx_date) %in% dx_years    ~ as.character(year(dx_date)),
                               TRUE                           ~ outside_lab),
                     levels = c(dx_years,
                                if (any(!year(dx_date) %in% dx_years & !is.na(dx_date)))
                                  outside_lab)),

    stage = factor(roman_stage(groupstage),
                   levels = c("0", "I", "II", "III", "IV", "Unknown")),

    hpv = factor(case_when(rc(hpvstatus) == "hpv positive" ~ "Positive",
                           rc(hpvstatus) == "hpv negative" ~ "Negative",
                           TRUE ~ "Other/Unknown"),
                 levels = c("Positive", "Negative", "Other/Unknown")),

    chemo = factor(if_else(coalesce(chemo_fc, FALSE), "Yes", "No/Unknown"),
                   levels = c("Yes", "No/Unknown")),
    radiation = factor(if_else(coalesce(rt_fc, FALSE), "Yes", "No/Unknown"),
                       levels = c("Yes", "No/Unknown")),

    reporting = factor(case_when(any_acad & any_comm ~ "Both Academic and Community",
                                 any_acad            ~ "Academic",
                                 any_comm            ~ "Community",
                                 TRUE                ~ "Unknown"),
                       levels = c("Academic", "Community",
                                  "Both Academic and Community", "Unknown"))
  )

stopifnot(nrow(ads) == length(cohort_ids), !anyDuplicated(ads$patientid))
