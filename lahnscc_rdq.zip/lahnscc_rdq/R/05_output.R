# =============================================================================
# 05_output.R : run metadata, then write the outputs
# =============================================================================
#   <stem>.xlsx                 Table 1, Attrition, SEER comparison,
#                               Representativeness, Run metadata
#   <stem>_table1_long.csv, <stem>_ads.rds   for the independent QC
#   <stem>_sessionInfo.txt
# =============================================================================

run_meta <- tibble::tribble(
  ~item, ~value,
  "Program",               "LA-HNSCC RDQ Table 1 (run_all.R)",
  "Asset / VeevaRIO",      paste0(asset_id, " / ", veeva_id),
  "Code MD5",              code_md5(),
  "Run started",           format(run_started, "%Y-%m-%d %H:%M:%S %Z"),
  "Run by",                env_or("DOMINO_USER_NAME", Sys.info()[["user"]]),
  "Connection",            con_desc,
  "Source schema",         paste0(db_catalog, ".", dbname),
  "Refresh",               refresh,
  "Source tables",         paste(names(tbl_map), tbl_map, sep = " = ", collapse = "; "),
  "Data cut-off",          format(datacut),
  "Reporting years",       paste(range(dx_years), collapse = "-"),
  "Restrict to years",     as.character(restrict_dx_window),
  "ICD-10 exclusion",      excl_icd10_regex,
  "ICD-9 exclusion",       excl_icd9_regex,
  "No-surgery group",      no_surgery_group,
  "First-course settings", paste(first_course_settings, collapse = ", "),
  "Chemo definition",      paste0(chemo_definition,
                                  if (chemo_definition == "seer") paste0(" (+ ", paste(seer_extra_chemo, collapse = ", "), ")") else ""),
  "Drug cohorts",          if (is.null(drug_cohorts)) "(single value required)" else paste(drug_cohorts, collapse = ", "),
  "RT look-back (days)",   as.character(rt_lookback_days),
  "RT sites",              paste(rt_sites_first_course, collapse = "; "),
  "RT coarse-date rule",   rt_coarse_rule,
  "Patients in Table 1",   as.character(nrow(ads)),
  "SEER table",            if (is.null(seer_cmp)) "not supplied" else
                             paste0(seer_table_path, " (md5 ", unname(tools::md5sum(seer_table_path)), ")"),
  "SEER groups compared",  if (is.null(seer_cmp)) "-" else paste(seer_cmp$groups, collapse = ", "),
  "R version",             R.version.string
)

if ("Run metadata" %in% names(wb)) removeWorksheet(wb, "Run metadata")
addWorksheet(wb, "Run metadata")
writeData(wb, "Run metadata", run_meta)
setColWidths(wb, "Run metadata", cols = 1:2, widths = c(24, 110))

save_wb <- function(w, path) {
  ok <- saveWorkbook(w, path, overwrite = TRUE, returnValue = TRUE)
  if (!isTRUE(ok)) stop("Could not write ", path, call. = FALSE)
  path
}
xlsx_path <- save_wb(wb, file.path(out_dir, paste0(out_stem, ".xlsx")))

write.csv(long %>% select(section, label, is_header, group, n, n_num, pct),
          file.path(out_dir, paste0(out_stem, "_table1_long.csv")),
          row.names = FALSE)
saveRDS(ads, file.path(out_dir, paste0(out_stem, "_ads.rds")))
writeLines(capture.output(sessionInfo()),
           file.path(out_dir, paste0(out_stem, "_sessionInfo.txt")))
message("Written: ", xlsx_path)
