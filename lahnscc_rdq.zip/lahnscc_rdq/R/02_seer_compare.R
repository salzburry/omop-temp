# =============================================================================
# 02_seer_compare.R : Flatiron vs SEER - how representative is Flatiron?
# =============================================================================
# Input: the SEER RDQ's Table 1 in inputs/seer_table1_TEMPLATE.csv layout
# (section, label, group, n, pct, mean, sd), saved as seer_file. For each row
# give the SEER count (n) or column % (pct; on the Incidence row, the group's
# share of the whole cohort); mean and sd on the age "Mean (sd)" row. Leave a
# category blank if SEER does not report it - it is then left out on both sides.
# Adds sheets "SEER comparison" and "Representativeness" to the workbook.
# Standardized differences (SMD) are used, not p-values: |SMD| < 0.1 Similar,
# 0.1-0.2 Small difference, >= 0.2 Meaningful difference.
# =============================================================================

if (!file.exists(seer_file)) {
  message("No SEER table at ", seer_file, " - SEER comparison skipped.")
} else {

key <- function(x) tolower(gsub("[[:space:]]+", " ", trimws(x)))
txt <- readLines(seer_file, warn = FALSE)
txt[1] <- sub("^\xef\xbb\xbf", "", txt[1], useBytes = TRUE)                # Excel "CSV UTF-8" BOM
seer <- read.csv(text = txt, colClasses = "character", check.names = FALSE)
if (!all(c("section", "label", "group", "n", "pct", "mean", "sd") %in% names(seer)))
  stop("SEER table needs columns section, label, group, n, pct, mean, sd.", call. = FALSE)

# Match sections, labels and groups to Table 1 (ignoring case and spacing)
t1 <- distinct(filter(long, !is_header), section, label)
m  <- match(paste(key(seer$section), key(seer$label)), paste(key(t1$section), key(t1$label)))
if (anyNA(m)) stop("SEER rows not in Table 1: ", paste(unique(paste(seer$section, seer$label, sep = " / ")[is.na(m)]),
                   collapse = "; "), call. = FALSE)
seer$section <- t1$section[m]; seer$label <- t1$label[m]
seer$group <- groups[match(key(seer$group), key(groups))]
if (anyNA(seer$group)) stop("SEER group must be one of: ", paste(groups, collapse = ", "), call. = FALSE)
if (anyDuplicated(seer[c("section", "label", "group")])) stop("Duplicated SEER rows.", call. = FALSE)
for (v in c("n", "pct", "mean", "sd")) {
  x <- trimws(seer[[v]])
  x <- gsub("%$", "", ifelse(grepl("^[0-9]{1,3}(,[0-9]{3})+$", x), gsub(",", "", x), x))
  val <- suppressWarnings(as.numeric(x))
  bad <- (!is.na(x) & x != "" & is.na(val)) | (!is.na(val) & (!is.finite(val) | val < 0))
  if (any(bad)) stop("SEER '", v, "' must be blank or a number >= 0: ",
                     paste(unique(seer[[v]][bad]), collapse = ", "), call. = FALSE)
  seer[[v]] <- val
}

smd_prop <- function(a, b) {
  d <- sqrt((a * (1 - a) + b * (1 - b)) / 2)
  ifelse(d > 0, (a - b) / d, ifelse(abs(a - b) < 1e-12, 0, sign(a - b) * Inf))
}
smd_multi <- function(a, b) {                       # Yang & Dalton 2012, generalised inverse
  if (max(abs(a - b)) < 1e-12) return(0)
  k <- (a + b) > 0; a <- a[k]; b <- b[k]
  x <- a[-1] - b[-1]
  cv <- function(p) { s <- -outer(p, p); diag(s) <- p * (1 - p); s }
  S <- (cv(a[-1]) + cv(b[-1])) / 2
  e <- eigen(S, symmetric = TRUE); keep <- e$values > 1e-12
  Si <- e$vectors[, keep, drop = FALSE] %*% diag(1 / e$values[keep], sum(keep)) %*% t(e$vectors[, keep, drop = FALSE])
  if (!any(keep) || max(abs(x - S %*% Si %*% x)) > 1e-8) return(Inf)   # complete separation
  sqrt(max(0, drop(t(x) %*% Si %*% x)))
}
rate <- function(s) case_when(is.na(s) ~ "Not assessable", abs(s) < 0.1 ~ "Similar",
                              abs(s) < 0.2 ~ "Small difference", TRUE ~ "Meaningful difference")

# One variable for one group: Flatiron counts vs SEER n or pct, over the
# categories SEER reports.
compare <- function(fi, se, variable, group) {
  d <- left_join(fi, se, by = "label")
  r <- !is.na(d$n) | !is.na(d$pct)
  x <- if (all(!is.na(d$n[r]))) d$n else if (all(!is.na(d$pct[r]))) d$pct else
    stop("SEER ", variable, " / ", group, ": give n for every category or pct for every category.", call. = FALSE)
  ok <- sum(r) >= 2 && sum(d$fi_n[r]) > 0 && sum(x[r]) > 0
  d <- d %>% mutate(flatiron_pct = ifelse(r & ok, 100 * fi_n / sum(fi_n[r]), NA),
                    seer_pct = ifelse(r & ok, 100 * x / sum(x[r]), NA),
                    smd = smd_prop(flatiron_pct / 100, seer_pct / 100))
  s <- if (ok) smd_multi(d$flatiron_pct[r] / 100, d$seer_pct[r] / 100) else NA
  i <- which.max(abs(d$flatiron_pct - d$seer_pct))
  list(rows = tibble(Group = group, Variable = variable, Category = d$label, `Flatiron n` = d$fi_n,
                     `Flatiron %` = round(d$flatiron_pct, 1), `SEER %` = round(d$seer_pct, 1),
                     `Difference (pct points)` = round(d$flatiron_pct - d$seer_pct, 1),
                     SMD = round(d$smd, 3), Rating = ifelse(r, rate(d$smd), "No SEER value (left out)")),
       var = tibble(Group = group, Variable = variable, SMD = round(s, 3),
                    Rating = if (ok) rate(s) else "Not assessable (fewer than 2 SEER categories)",
                    `Largest difference` = if (length(i)) d$label[i] else NA,
                    `Flatiron % in categories SEER does not report` =
                      round(100 * sum(d$fi_n[!r]) / max(sum(d$fi_n), 1), 1)))
}

fi <- filter(long, !is_header, !is.na(n_num)) %>% select(section, label, group, fi_n = n_num)
inc <- long$section[1]
res <- list()
if ("Overall" %in% seer$group)                                         # surgery split (share of cohort)
  res[[1]] <- compare(fi %>% filter(section == inc, group != "Overall") %>% transmute(label = group, fi_n),
                      seer %>% filter(section == inc, group != "Overall") %>% transmute(label = group, n, pct),
                      "Surgery group (share of cohort)", "Overall")
for (g in intersect(groups, seer$group))
  for (v in setdiff(unique(fi$section), inc))
    res[[length(res) + 1]] <- compare(fi %>% filter(section == v, group == g) %>% select(label, fi_n),
                                      seer %>% filter(section == v, group == g) %>% select(label, n, pct), v, g)
age <- seer %>% filter(label == "Mean (sd)", !is.na(mean)) %>%
  inner_join(tibble(group = groups, m = sapply(grp_data[groups], function(d) mean(d$age, na.rm = TRUE)),
                    s = sapply(grp_data[groups], function(d) sd(d$age, na.rm = TRUE))), by = "group") %>%
  transmute(Group = group, Variable = "Age at diagnosis (years)", SMD = round((m - mean) / sqrt((s^2 + sd^2) / 2), 3),
            Rating = rate(SMD), `Largest difference` = sprintf("Mean %.1f vs %.1f", m, mean))

seer_rows <- bind_rows(lapply(res, `[[`, "rows"))
seer_vars <- bind_rows(bind_rows(lapply(res, `[[`, "var")), age) %>% arrange(match(Group, groups))
print(as.data.frame(seer_vars[1:4]), row.names = FALSE)

seer_rows$SMD[!is.finite(seer_rows$SMD)] <- NA                         # Excel cannot show Inf / NaN
seer_vars$SMD[!is.finite(seer_vars$SMD)] <- NA
addWorksheet(wb, "SEER comparison");    writeData(wb, "SEER comparison", seer_rows)
addWorksheet(wb, "Representativeness"); writeData(wb, "Representativeness", seer_vars)
writeData(wb, "Representativeness", c(
  "SMD: multi-category standardized difference (Yang & Dalton 2012); age: difference in means / pooled SD. A blank SMD rated Meaningful difference = complete separation.",
  "Rating: |SMD| < 0.1 Similar; 0.1 to < 0.2 Small difference; >= 0.2 Meaningful difference.",
  "Categories SEER does not report (blank n and pct) are left out on both sides; their Flatiron share is shown."),
  startRow = nrow(seer_vars) + 3)
saveWorkbook(wb, xlsx_path, overwrite = TRUE)
}
