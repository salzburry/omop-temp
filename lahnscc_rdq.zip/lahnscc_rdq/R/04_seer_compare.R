# =============================================================================
# 04_seer_compare.R : Flatiron vs SEER - how representative is Flatiron?
# =============================================================================
# Input : the SEER RDQ's Table 1, as CSV at seer_table_path (RDQ_SEER_TABLE),
#         columns  section, label, group, n, pct, mean, sd
#           section/label : as in the Flatiron Table 1 (see the template)
#           group         : Overall, Unresected, Resected, Unknown (only the
#                           groups SEER provides are compared)
#           n             : SEER count. Thousands separators are accepted.
#           pct           : SEER column % (the Incidence row: each group's share
#                           of the whole SEER cohort). "%" is accepted.
#           mean, sd      : only on the "Mean (sd)" age row
#         A SEER suppression mark ("<16", "^", "*", "~", "S") is read as
#         "suppressed"; any other non-numeric value stops the run.
#
# How SEER proportions are formed, per section x group (one rule for n and pct):
#   * a category with neither n nor pct is "not reported" by SEER (e.g. the
#     Flatiron-only rows Sex Unknown, Race Other/Unknown) and is left out on
#     BOTH sides; the Flatiron share in such categories is reported beside the
#     result so a difference in missingness stays visible. Enter 0 for a true
#     SEER zero;
#   * reported categories use n when all of them have n, pct when all have pct,
#     and a mix (n converted to % of the SEER group N from the Incidence row)
#     otherwise; both sides are then re-normalised over the reported
#     categories.
#
# Output: sheets "SEER comparison" (row level) and "Representativeness"
# (variable level) in the workbook `wb`.
# Why standardized differences, not p-values: SEER's size makes any test
# "significant". |SMD| < 0.1 is the usual threshold for a negligible
# difference; 0.1-0.2 small; >= 0.2 meaningful.
# =============================================================================

seer_table_path <- env_or("RDQ_SEER_TABLE", "inputs/seer_table1.csv")
smd_cut      <- c(0.1, 0.2)
inc_section  <- long$section[1]
surg_section <- "Surgery group (share of cohort)"

rate_smd <- function(x) {
  case_when(is.na(x)            ~ "Not assessable",
            is.infinite(x)      ~ "Meaningful difference (complete separation)",
            abs(x) < smd_cut[1] ~ "Similar",
            abs(x) < smd_cut[2] ~ "Small difference",
            TRUE                ~ "Meaningful difference")
}
fmt_smd <- function(x) ifelse(is.na(x), NA_character_,
                              ifelse(is.infinite(x), ifelse(x > 0, "Inf", "-Inf"),
                                     sprintf("%.3f", x)))

# SMD for one category (difference in proportions). Zero pooled variance with
# different proportions is complete separation (infinite), not 0.
smd_prop <- function(p1, p2) {
  d <- sqrt((p1 * (1 - p1) + p2 * (1 - p2)) / 2)
  ifelse(d > 0, (p1 - p2) / d,
         ifelse(abs(p1 - p2) < 1e-12, 0, sign(p1 - p2) * Inf))
}

# Multi-category SMD (Yang & Dalton 2012): Mahalanobis distance between the two
# proportion vectors, first category as reference, generalised inverse of the
# pooled covariance. A difference outside the range of that covariance is
# complete separation (infinite).
smd_multi <- function(p1, p2) {
  if (!length(p1) || anyNA(c(p1, p2))) return(NA_real_)
  if (max(abs(p1 - p2)) < 1e-12) return(0)
  keep <- (p1 + p2) > 0
  p1 <- p1[keep]; p2 <- p2[keep]
  if (length(p1) < 2) return(NA_real_)
  t <- p1[-1]; c <- p2[-1]; x <- t - c
  cv <- function(p) { m <- -outer(p, p); diag(m) <- p * (1 - p); m }
  S <- (cv(t) + cv(c)) / 2
  sv <- svd(S); dpos <- sv$d > 1e-12
  if (!any(dpos)) return(if (max(abs(x)) < 1e-12) 0 else Inf)
  Sinv <- sv$v[, dpos, drop = FALSE] %*% diag(1 / sv$d[dpos], sum(dpos)) %*%
          t(sv$u[, dpos, drop = FALSE])
  if (max(abs(x - S %*% Sinv %*% x)) > 1e-8) return(Inf)
  sqrt(max(0, as.numeric(t(x) %*% Sinv %*% x)))
}

# Strict number parser for the SEER file.
parse_seer <- function(x, col) {
  raw  <- trimws(as.character(x)); raw[is.na(raw) | raw %in% c("", "NA")] <- NA
  supp <- !is.na(raw) & grepl("^(<\\s*[0-9]+|\\^|\\*|~|S|\\(s\\))$", raw)
  s    <- raw
  thou <- !is.na(s) & grepl("^-?[0-9]{1,3}(,[0-9]{3})+(\\.[0-9]+)?%?$", s)
  s[thou] <- gsub(",", "", s[thou])
  if (col == "pct") s <- sub("%$", "", s)
  val <- suppressWarnings(as.numeric(s))
  val[supp] <- NA
  bad <- !is.na(raw) & !supp & is.na(val)
  if (any(bad))
    stop("SEER table: non-numeric '", col, "' value(s): ",
         paste0("'", unique(raw[bad]), "'", collapse = ", "),
         ". Enter plain numbers (a decimal point, not a comma).", call. = FALSE)
  if (col == "n"   && any(val < 0 | val != round(val), na.rm = TRUE))
    stop("SEER table: 'n' must be whole numbers >= 0.", call. = FALSE)
  if (col == "pct" && any(val < 0 | val > 100, na.rm = TRUE))
    stop("SEER table: 'pct' must lie between 0 and 100.", call. = FALSE)
  list(val = val, supp = supp)
}

# ---- Flatiron side ------------------------------------------------------------
fi_long <- long %>%
  filter(!is_header, !is.na(n_num)) %>%
  transmute(section, label, group, block, row, fi_n = n_num)

fi_age <- bind_rows(lapply(groups, function(g) {
  x <- grp_data[[g]]$age
  tibble(group = g, fi_mean = mean(x, na.rm = TRUE), fi_sd = sd(x, na.rm = TRUE))
}))

seer_cmp <- NULL
seer_groups <- character(0)

if (!file.exists(seer_table_path)) {
  tmpl_out <- file.path(out_dir, "seer_table1_TEMPLATE_generated.csv")
  tmpl <- long %>%
    filter(!is_header, label != "Median [IQR]") %>%
    arrange(match(group, groups), block, row) %>%
    transmute(section, label, group, n = NA, pct = NA, mean = NA, sd = NA)
  write.csv(tmpl, tmpl_out, row.names = FALSE, na = "")
  msg <- paste0("No SEER table at '", seer_table_path, "' - SEER comparison skipped. ",
                "A template for this delivery (including any data-dependent rows) is at ",
                tmpl_out, ".")
  if (identical(env_or("RDQ_REQUIRE_SEER", ""), "1")) stop(msg, call. = FALSE)
  warning(msg, call. = FALSE)
} else {
  if (!grepl("\\.csv$", seer_table_path, ignore.case = TRUE))
    stop("RDQ_SEER_TABLE must be a .csv file: ", seer_table_path, call. = FALSE)

  seer <- read.csv(seer_table_path, colClasses = "character", check.names = FALSE,
                   fileEncoding = "UTF-8-BOM", na.strings = character(0))
  need <- c("section", "label", "group", "n", "pct", "mean", "sd")
  miss <- setdiff(need, names(seer))
  if (length(miss))
    stop("SEER table ", seer_table_path, " is missing column(s): ", paste(miss, collapse = ", "),
         ". Save it as plain CSV with the template's header.", call. = FALSE)
  seer <- seer %>%
    mutate(across(c(section, label, group), ~ trimws(.x)),
           group = coalesce(groups[match(tolower(group), tolower(groups))], group))

  bad_grp <- setdiff(unique(seer$group), groups)
  if (length(bad_grp))
    stop("SEER group value(s) not recognised: ", paste0("'", bad_grp, "'", collapse = ", "),
         ". Use: ", paste(groups, collapse = ", "), ".", call. = FALSE)
  dup <- seer %>% count(section, label, group) %>% filter(n > 1)
  if (nrow(dup))
    stop("Duplicated SEER rows (section / label / group): ",
         paste(dup$section, dup$label, dup$group, sep = " / ", collapse = "; "),
         ". Keep one row per category.", call. = FALSE)
  bad_sec <- setdiff(unique(seer$section), unique(long$section))
  if (length(bad_sec))
    stop("SEER sections not in the Flatiron Table 1: ", paste(bad_sec, collapse = "; "),
         ". Use the section names from the template.", call. = FALSE)

  for (cc in c("n", "pct", "mean", "sd")) {
    p <- parse_seer(seer[[cc]], cc)
    seer[[cc]] <- p$val
    seer[[paste0(cc, "_supp")]] <- p$supp
  }
  seer$supp <- seer$n_supp | seer$pct_supp
  if (all(is.na(seer$n) & is.na(seer$pct) & is.na(seer$mean)))
    stop("SEER table at ", seer_table_path, " has no values - fill it from the SEER RDQ output.",
         call. = FALSE)

  # Data-dependent rows (e.g. "Unknown", "Outside 2019-2025") exist only when
  # Flatiron has such patients; SEER rows without a Flatiron row are dropped.
  bad <- anti_join(seer %>% distinct(section, label),
                   long %>% filter(!is_header) %>% distinct(section, label),
                   by = c("section", "label"))
  if (nrow(bad)) {
    warning("SEER rows with no Flatiron Table 1 row, ignored: ",
            paste(bad$section, bad$label, sep = " / ", collapse = "; "), call. = FALSE)
    seer <- semi_join(seer, long %>% distinct(section, label), by = c("section", "label"))
  }

  seer_groups <- intersect(groups, unique(seer$group))
  if (!length(seer_groups))
    stop("No SEER group can be compared (groups in the file: ",
         paste(unique(seer$group), collapse = ", "), ").", call. = FALSE)
  seer_N <- seer %>% filter(section == inc_section, label == "Overall") %>%
    select(group, N = n)

  # ---- One section x group ---------------------------------------------------
  compare_block <- function(d, N_g, section, group, is_share = FALSE) {
    rep_ <- !is.na(d$seer_n) | !is.na(d$seer_pct)
    note <- character(0)
    if (any(d$seer_supp)) note <- c(note, "SEER cell(s) suppressed - treated as not reported")
    x <- rep(NA_real_, nrow(d)); basis <- NA_character_
    if (any(rep_)) {
      if (all(!is.na(d$seer_n[rep_])))        { x <- d$seer_n;   basis <- "n" }
      else if (all(!is.na(d$seer_pct[rep_]))) { x <- d$seer_pct; basis <- "pct" }
      else if (!is.na(N_g) && N_g > 0) {
        x <- ifelse(!is.na(d$seer_n), 100 * d$seer_n / N_g, d$seer_pct); basis <- "mixed"
      } else stop("SEER ", section, " / ", group, ": counts and percentages are mixed and ",
                  "the SEER group N (Incidence row n) is missing.", call. = FALSE)
      x[!rep_] <- NA
      if (basis == "pct" && is_share && all(x[rep_] >= 99))
        stop("SEER Incidence-row pct must be each group's share of the whole cohort ",
             "(they should add up to 100), not 100 per group.", call. = FALSE)
      if (basis != "n" && all(rep_) && abs(sum(x) - 100) > 2)
        warning("SEER ", section, " / ", group, ": percentages add up to ",
                round(sum(x), 1), ", not 100; re-normalised.", call. = FALSE)
    }
    tot_rep <- sum(d$fi_n[rep_])
    fi_p   <- if (tot_rep > 0) ifelse(rep_, d$fi_n / tot_rep, NA_real_) else rep(NA_real_, nrow(d))
    seer_p <- if (any(rep_) && sum(x[rep_]) > 0) ifelse(rep_, x / sum(x[rep_]), NA_real_)
              else rep(NA_real_, nrow(d))
    not_cmp <- if (sum(d$fi_n) > 0) 100 * sum(d$fi_n[!rep_]) / sum(d$fi_n) else NA_real_
    if (any(!rep_ & d$fi_n > 0)) note <- c(note, paste0("No SEER value for: ",
                                       paste(d$label[!rep_ & d$fi_n > 0], collapse = ", ")))

    rows <- tibble(Group = group, Section = section, Category = d$label,
                   fi_n = d$fi_n, reported = rep_,
                   seer_n = d$seer_n, seer_pct_in = d$seer_pct,
                   fi_p = fi_p, seer_p = seer_p) %>%
      mutate(diff_pp = 100 * (fi_p - seer_p), smd = smd_prop(fi_p, seer_p),
             rating = rate_smd(smd))

    rows <- rows %>% mutate(
      diff_pp = ifelse(reported, diff_pp, NA_real_),
      smd     = ifelse(reported, smd, NA_real_),
      rating  = ifelse(reported, rating, "No SEER value (left out)"))

    # variable level: over the categories SEER reports
    vf <- fi_p[rep_]; vs <- seer_p[rep_]; vl <- d$label[rep_]
    i <- which.max(abs(vf - vs))[1]
    smd_v <- smd_multi(vf, vs)
    var <- tibble(Group = group, Variable = section, smd = smd_v,
                  Rating = if (!any(rep_)) "Not assessable (no SEER values)" else rate_smd(smd_v),
                  `Largest difference` = if (is.na(i)) NA_character_ else vl[i],
                  `Largest difference (pct points)` = if (is.na(i)) NA_real_
                                                      else round(100 * (vf - vs)[i], 1),
                  `Flatiron % in categories with no SEER value` = round(not_cmp, 1),
                  `SEER basis` = basis,
                  Note = paste(note, collapse = "; "))
    list(rows = rows, var = var)
  }

  blocks_cmp <- list()
  # surgery split (share of the cohort), compared as one variable under Overall
  if ("Overall" %in% seer_groups) {
    d <- fi_long %>%
      filter(section == inc_section, group != "Overall") %>%
      left_join(seer %>% filter(section == inc_section, label == "Overall") %>%
                  select(group, seer_n = n, seer_pct = pct, seer_supp = supp), by = "group") %>%
      mutate(label = group, seer_supp = coalesce(seer_supp, FALSE))
    blocks_cmp[[length(blocks_cmp) + 1]] <-
      compare_block(d, seer_N$N[seer_N$group == "Overall"][1] %||% NA_real_,
                    surg_section, "Overall", is_share = TRUE)
  }
  for (g in seer_groups) {
    for (s in setdiff(unique(long$section), c(inc_section, "Age at diagnosis (years)"))) {
      d <- fi_long %>%
        filter(section == s, group == g) %>%
        left_join(seer %>% filter(section == s, group == g) %>%
                    select(label, seer_n = n, seer_pct = pct, seer_supp = supp), by = "label") %>%
        mutate(seer_supp = coalesce(seer_supp, FALSE)) %>%
        arrange(row)
      blocks_cmp[[length(blocks_cmp) + 1]] <-
        compare_block(d, seer_N$N[seer_N$group == g][1] %||% NA_real_, s, g)
    }
  }
  row_cmp <- bind_rows(lapply(blocks_cmp, `[[`, "rows"))
  var_cat <- bind_rows(lapply(blocks_cmp, `[[`, "var"))

  # ---- Age, continuous --------------------------------------------------------
  age_cmp <- tibble(group = seer_groups) %>%
    left_join(seer %>% filter(label == "Mean (sd)") %>% select(group, seer_mean = mean, seer_sd = sd),
              by = "group") %>%
    left_join(fi_age, by = "group") %>%
    mutate(smd = (fi_mean - seer_mean) / sqrt((fi_sd^2 + seer_sd^2) / 2),
           rating = case_when(is.na(seer_mean) ~ "Not assessable (no SEER values)",
                              TRUE             ~ rate_smd(smd)))
  var_age <- age_cmp %>%
    transmute(Group = group, Variable = "Age at diagnosis (years)", smd, Rating = rating,
              `Largest difference` = ifelse(is.na(seer_mean), NA_character_,
                                            sprintf("Mean %.1f vs %.1f", fi_mean, seer_mean)),
              `Largest difference (pct points)` = NA_real_,
              `Flatiron % in categories with no SEER value` = NA_real_,
              `SEER basis` = ifelse(is.na(seer_mean), NA_character_, "mean/sd"),
              Note = "")

  sec_order <- c(surg_section, unique(long$section))
  var_cmp <- bind_rows(var_cat, var_age) %>%
    arrange(match(Group, groups), match(Variable, sec_order)) %>%
    mutate(`Standardized difference` = fmt_smd(smd))

  seer_cmp <- list(rows = row_cmp, age = age_cmp, vars = var_cmp, groups = seer_groups)

  # ---- Sheets -----------------------------------------------------------------
  rows_out <- row_cmp %>%
    transmute(Group, Section, Category,
              `Flatiron n` = fi_n,
              `Flatiron %` = round(100 * fi_p, 1),
              `SEER n` = seer_n,
              `SEER % (as entered)` = seer_pct_in,
              `SEER % (compared)` = round(100 * seer_p, 1),
              `Difference (pct points)` = round(diff_pp, 1),
              SMD = fmt_smd(smd),
              Rating = rating)
  for (sh in intersect(c("SEER comparison", "Representativeness"), names(wb))) removeWorksheet(wb, sh)
  addWorksheet(wb, "SEER comparison")
  writeData(wb, "SEER comparison", rows_out)
  writeData(wb, "SEER comparison",
            age_cmp %>% transmute(Group = group, Variable = "Age at diagnosis",
                                  `Flatiron mean (sd)` = sprintf("%.1f (%s)", fi_mean,
                                    ifelse(is.na(fi_sd), "-", sprintf("%.1f", fi_sd))),
                                  `SEER mean (sd)` = ifelse(is.na(seer_mean), NA_character_,
                                    sprintf("%.1f (%s)", seer_mean, ifelse(is.na(seer_sd), "-", sprintf("%.1f", seer_sd)))),
                                  SMD = fmt_smd(smd), Rating = rating),
            startRow = nrow(rows_out) + 3)
  setColWidths(wb, "SEER comparison", cols = 1:11,
               widths = c(12, 32, 44, 11, 11, 11, 13, 13, 14, 9, 30))

  addWorksheet(wb, "Representativeness")
  rep_out <- var_cmp %>% select(Group, Variable, `Standardized difference`, Rating,
                                `Largest difference`, `Largest difference (pct points)`,
                                `Flatiron % in categories with no SEER value`, `SEER basis`, Note)
  writeData(wb, "Representativeness", rep_out)
  writeData(wb, "Representativeness",
            c("Standardized difference: categorical variables use the multi-category SMD (Yang & Dalton 2012); age uses (mean1 - mean2) / pooled SD. Inf = complete separation.",
              "Rating: |SMD| < 0.1 Similar; 0.1 to < 0.2 Small difference; >= 0.2 Meaningful difference.",
              "Categories SEER does not report (blank n and pct) are left out on both sides and both are re-normalised; the Flatiron share in them is shown so a difference in missingness stays visible. Enter 0 for a true SEER zero.",
              if (aian_nhpi_present) "Race: AIAN and NHPI values occur in this Flatiron delivery and are mapped to the SEER rows."
              else "Race: the Flatiron delivery has no American Indian/Alaska Native category, so SEER's NH AIAN patients have no Flatiron counterpart."),
            startRow = nrow(rep_out) + 3)
  setColWidths(wb, "Representativeness", cols = 1:9, widths = c(12, 34, 22, 30, 32, 24, 24, 10, 60))

  message("SEER comparison: ", sum(grepl("^Meaningful", var_cmp$Rating)),
          " of ", nrow(var_cmp), " variable x group comparisons show a meaningful difference.")
  print(as.data.frame(rep_out[, 1:6]), row.names = FALSE)
}
