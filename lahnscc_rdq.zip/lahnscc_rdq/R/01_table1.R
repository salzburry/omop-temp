# =============================================================================
# 01_table1.R : study population, Table 1, chemotherapy date check
# =============================================================================
# Writes <stem>.xlsx (Table 1, Attrition, Chemo date check),
# <stem>_table1_long.csv and <stem>_ads.rds to out_dir.
# =============================================================================

norm <- function(x) tolower(gsub("[[:space:]]+", " ", trimws(x)))
fetch <- function(key, ...) src(key) %>% filter(patientid %in% !!ids) %>% select(patientid, ...) %>% collect()

# ---- Study population (Flatiron's LA-HNSCC criteria are applied in the delivery) ----
cohort <- src("cohort") %>%
  select(patientid, diagnosisdate, advanceddiagnosisdate, groupstage, hpvstatus) %>% collect() %>%
  mutate(dx_date = as.Date(diagnosisdate), adv_date = as.Date(advanceddiagnosisdate))
stopifnot(!anyDuplicated(cohort$patientid))
ids <- cohort$patientid
excluded <- fetch("diagnosis", diagnosiscode) %>%
  filter(grepl(excl_icd, toupper(gsub("[[:space:]]", "", diagnosiscode))))
cohort <- cohort %>% filter(!patientid %in% excluded$patientid)
attrition <- tibble(step = c("All patients in Enhanced_LAHNC", "Excluding ICD C11.x / C12.x (ICD-9 147.x / 148.1)"),
                    n_patients = c(length(ids), nrow(cohort)))
print(attrition)
ids <- cohort$patientid

# ---- Surgery group: Resected > Unknown > Unresected per patient --------------------
surg <- fetch("surgery", surgerytype) %>%
  mutate(s = norm(coalesce(surgerytype, "")),
         grp = coalesce(unname(surgery_map[s]),            # values outside the coding: by keyword
                        case_when(grepl("lymph node|neck dissection", s) & !grepl("primary", s) ~ "Unresected",
                                  grepl("resection", s) ~ "Resected", TRUE ~ "Unknown"))) %>%
  group_by(patientid) %>%
  summarise(surg_group = if (any(grp == "Resected")) "Resected" else if (any(grp == "Unknown")) "Unknown"
                         else "Unresected", .groups = "drop")

# ---- Chemotherapy, first course: first-course line + DetailedDrugCategory chemo ------
drugs <- fetch("drugep", linesetting, drugname, detaileddrugcategory, episodedate, enhancedcohort)
if (!is.null(drug_cohorts)) drugs <- filter(drugs, enhancedcohort %in% drug_cohorts)
if (is.null(drug_cohorts) && n_distinct(drugs$enhancedcohort) > 1)   # another disease's lines must not count
  stop("DrugEpisode has several EnhancedCohort values (", paste(unique(drugs$enhancedcohort), collapse = ", "),
       "). Set drug_cohorts in 00_setup.R to the LA-HNSCC value(s).", call. = FALSE)
drugs <- drugs %>%
  mutate(first = toupper(norm(linesetting)) %in% first_course_settings,
         chemo = grepl("chemo", norm(coalesce(detaileddrugcategory, ""))) |
                 (count_cetuximab & grepl("cetuximab", norm(coalesce(drugname, "")))))
if (any(drugs$first) && !any(drugs$first & drugs$chemo))
  stop("First-course drug episodes exist but none is chemotherapy - check DetailedDrugCategory.", call. = FALSE)

# ---- Radiation, first course ---------------------------------------------------------
# End of first course = earliest of first locoregional recurrence, distant
# recurrence and AdvancedDiagnosisDate. A month/year-only start date must lie
# wholly inside the window.
first_date <- function(key, col) fetch(key, d = !!rlang::sym(col)) %>% mutate(d = as.Date(d)) %>%
  filter(!is.na(d)) %>% group_by(patientid) %>% summarise(d = min(d), .groups = "drop")
fc_end <- cohort %>% select(patientid, dx_date, adv_date) %>%
  left_join(first_date("localrec", "localrecurdate") %>% rename(lr = d), by = "patientid") %>%
  left_join(first_date("metrec", "distantmetdate") %>% rename(dm = d), by = "patientid") %>%
  transmute(patientid, dx_date, fc_end = pmin(adv_date, lr, dm, na.rm = TRUE))
rt_ids <- fetch("radiation", rtstartdate, rtstartdategranularity, rtsite) %>%
  filter(norm(coalesce(rtsite, "Unknown/not documented")) %in% rt_sites) %>%
  mutate(start = as.Date(rtstartdate), g = toupper(coalesce(trimws(rtstartdategranularity), "DAY")),
         lo = case_when(g == "YEAR" ~ floor_date(start, "year"), g == "MONTH" ~ floor_date(start, "month"),
                        TRUE ~ start),
         hi = case_when(g == "YEAR" ~ ceiling_date(start, "year", change_on_boundary = TRUE) - 1,
                        g == "MONTH" ~ ceiling_date(start, "month", change_on_boundary = TRUE) - 1,
                        TRUE ~ start)) %>%
  inner_join(fc_end, by = "patientid") %>%
  filter(!is.na(start), lo >= dx_date - rt_lookback_days, is.na(fc_end) | hi < fc_end) %>%
  pull(patientid)

# ---- Analysis dataset: one row per patient --------------------------------------------
outside <- sprintf("Outside %d-%d", min(dx_years), max(dx_years))
stage_of <- function(x) {
  y <- toupper(gsub("(?i)stage|\\s", "", x, perl = TRUE))
  case_when(grepl("^(0|0IS|T?IS)$", y) ~ "0", grepl("^IV[ABC]?$", y) ~ "IV", grepl("^III[ABC]?$", y) ~ "III",
            grepl("^II[ABC]?$", y) ~ "II", grepl("^I[ABC]?$", y) ~ "I", TRUE ~ "Unknown")
}
demo <- fetch("demo", birthyear, birthsex, race, ethnicity)
if (anyDuplicated(demo$patientid)) stop("Demographics has more than one row for a patient.", call. = FALSE)
practice <- fetch("practice", practicetype) %>% group_by(patientid) %>%
  summarise(acad = any(norm(practicetype) %in% "academic"), comm = any(norm(practicetype) %in% "community"))
ads <- cohort %>%
  left_join(demo, by = "patientid") %>%
  left_join(practice, by = "patientid") %>%
  left_join(surg, by = "patientid") %>%
  mutate(
    surg_group = factor(coalesce(surg_group, no_surgery_group), c("Unresected", "Resected", "Unknown")),
    sex = factor(case_when(norm(birthsex) %in% c("f", "female") ~ "Female",
                           norm(birthsex) %in% c("m", "male") ~ "Male", TRUE ~ "Unknown"),
                 c("Male", "Female", "Unknown")),
    age = year(dx_date) - suppressWarnings(as.numeric(birthyear)),          # birth year only
    age_cat = cut(age, c(-Inf, 17, 39, 64, 74, Inf),
                  c("<18 years", "18-39 years", "40-64 years", "65-74 years", "75+ years")),
    race_eth = factor(case_when(
      norm(race) == "hispanic or latino" | norm(ethnicity) == "hispanic or latino" ~ "Hispanic (All Races)",
      norm(race) == "white" ~ "Non-Hispanic White",
      norm(race) == "black or african american" ~ "Non-Hispanic Black",
      norm(race) == "american indian or alaska native" ~ "Non-Hispanic American Indian/Alaska Native",
      norm(race) %in% c("asian", "native hawaiian or other pacific islander") ~ "Non-Hispanic Asian or Pacific Islander",
      TRUE ~ "Other/Unknown"),
      c("Non-Hispanic White", "Non-Hispanic Black", "Non-Hispanic American Indian/Alaska Native",
        "Non-Hispanic Asian or Pacific Islander", "Hispanic (All Races)", "Other/Unknown")),
    dx_year = factor(ifelse(is.na(dx_date), NA, ifelse(year(dx_date) %in% dx_years, year(dx_date), outside)),
                     c(dx_years, if (any(!is.na(dx_date) & !year(dx_date) %in% dx_years)) outside)),
    stage = factor(stage_of(groupstage), c("0", "I", "II", "III", "IV", "Unknown")),
    hpv = factor(case_when(norm(hpvstatus) == "hpv positive" ~ "Positive",
                           norm(hpvstatus) == "hpv negative" ~ "Negative", TRUE ~ "Other/Unknown"),
                 c("Positive", "Negative", "Other/Unknown")),
    chemo = factor(ifelse(patientid %in% drugs$patientid[drugs$first & drugs$chemo], "Yes", "No/Unknown"),
                   c("Yes", "No/Unknown")),
    radiation = factor(ifelse(patientid %in% rt_ids, "Yes", "No/Unknown"), c("Yes", "No/Unknown")),
    reporting = factor(case_when(acad & comm ~ "Both Academic and Community", acad ~ "Academic",
                                 comm ~ "Community", TRUE ~ "Unknown"),
                       c("Academic", "Community", "Both Academic and Community", "Unknown")))
if (nrow(ads) != nrow(cohort) || anyDuplicated(ads$patientid))
  stop("The analysis dataset must have exactly one row per cohort patient.", call. = FALSE)

# ---- Table 1: Overall | Unresected | Resected | Unknown (n, column %) -----------------
groups   <- c("Overall", levels(ads$surg_group))
grp_data <- c(list(Overall = ads), split(ads, ads$surg_group))
block <- function(var, header) {
  body <- bind_rows(lapply(groups, function(g) {
    d <- grp_data[[g]]
    if (var == "age") {                                                     # continuous
      q <- quantile(d$age, c(.25, .5, .75), na.rm = TRUE)
      return(tibble(label = c("Mean (sd)", "Median [IQR]"), group = g, n_num = NA, pct = "",
                    n = if (all(is.na(d$age))) "-" else
                      c(sprintf("%.1f (%s)", mean(d$age, na.rm = TRUE),
                                ifelse(sum(!is.na(d$age)) > 1, sprintf("%.1f", sd(d$age, na.rm = TRUE)), "-")),
                        sprintf("%.1f [%.1f, %.1f]", q[2], q[1], q[3]))))
    }
    x <- if (var == "overall") rep("Overall", nrow(d)) else as.character(d[[var]])
    x[is.na(x)] <- "Unknown"                                                # "Unknown" row only if missing
    levs <- if (var == "overall") "Overall" else c(levels(ads[[var]]), if (anyNA(ads[[var]])) "Unknown")
    n <- vapply(levs, function(l) sum(x == l), numeric(1))
    den <- if (var == "overall") nrow(ads) else nrow(d)
    tibble(label = levs, group = g, n_num = n, n = as.character(n),
           pct = if (den > 0) sprintf("%.1f", 100 * n_num / den) else "-")
  }))
  bind_rows(tibble(label = header, group = groups, n = "", n_num = NA, pct = "", is_header = TRUE),
            mutate(body, is_header = FALSE)) %>% mutate(section = header)
}
long <- bind_rows(
  block("overall", "Incidence of Head and Neck Squamous Cell Carcinoma"), block("sex", "Sex"),
  block("age", "Age at diagnosis (years)"), block("age_cat", "Age at diagnosis (categorical)"),
  block("race_eth", "Race/Ethnicity"), block("dx_year", "Year of Diagnosis"),
  block("stage", "Stage at diagnosis"), block("hpv", "HPV status"),
  block("chemo", "Receipt of chemotherapy (1L)"), block("radiation", "Receipt of radiation (1L)"),
  block("reporting", "Type of Reporting Source"))
table1 <- long %>%
  pivot_wider(id_cols = c(section, label, is_header), names_from = group, values_from = c(n, pct)) %>%
  select(section, label, is_header, all_of(as.vector(rbind(paste0("n_", groups), paste0("pct_", groups)))))

footnotes <- c(
  paste0("Source: Flatiron GSK Dostarlimab LA Head & Neck custom data (", schema, ", refresh ", refresh,
         "); data cut-off ", format(datacut, "%d%b%Y"), "."),
  "Percentages are column percentages within each surgery group; the Overall row shows each group's share of the cohort.",
  paste0("Surgery (SEER): Resected = primary tumour resection +/- lymph node dissection; Unresected = lymph node ",
         "dissection only; Unknown = unknown/not specified; no primary-surgery record = ", no_surgery_group, "."),
  "Age = year of diagnosis - birth year (Flatiron provides birth year only).",
  paste0("Chemotherapy / radiation (1L) = SEER first course. Chemotherapy: DetailedDrugCategory chemotherapy",
         if (count_cetuximab) " or cetuximab" else "", " in a ", paste(first_course_settings, collapse = ", "),
         " line. Radiation: RT to the primary or an unknown site starting no earlier than ", rt_lookback_days,
         " days before diagnosis and before the first recurrence or advanced diagnosis."),
  "Rows not in the SEER shell (so each block adds up to N): Sex Unknown, Race/Ethnicity Other/Unknown, and any age or year Unknown / Outside row.")

# ---- Chemotherapy date check (diagnostic only; Table 1 unchanged) ---------------------
# First-course chemo episodes against the radiation window, and how many chemo
# "Yes" patients a date window would change.
chk <- drugs %>% filter(first, chemo, patientid %in% ids) %>% left_join(fc_end, by = "patientid") %>%
  mutate(ep = as.Date(episodedate),
         position = case_when(is.na(ep) ~ "No episode date",
                              !is.na(fc_end) & ep >= fc_end ~ "After end of first course",
                              is.na(dx_date) ~ "No diagnosis date",
                              ep < dx_date - rt_lookback_days ~ "Before window",
                              TRUE ~ "Inside window"))
chk_pat <- chk %>% group_by(patientid) %>%
  summarise(inside = any(position == "Inside window"), undated = any(grepl("^No ", position)))
chemo_check <- bind_rows(
  count(chk, line_setting = toupper(norm(linesetting)), position, name = "n"),
  tibble(position = c("Chemo Yes patients", "Would change to No/Unknown under a date window",
                      "Cannot be placed (missing date)"),
         n = c(nrow(chk_pat), sum(!chk_pat$inside & !chk_pat$undated), sum(!chk_pat$inside & chk_pat$undated))))
print(as.data.frame(chemo_check), row.names = FALSE)

# ---- Outputs ---------------------------------------------------------------------------
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
wb <- createWorkbook()
addWorksheet(wb, "Table 1", gridLines = FALSE)
writeData(wb, "Table 1", "Table 1", startRow = 1)
writeData(wb, "Table 1", sprintf("Number of cases in Flatiron database, %d to %d", min(dx_years), max(dx_years)),
          startRow = 1, startCol = 2)
for (i in seq_along(groups)) {
  writeData(wb, "Table 1", groups[i], startRow = 2, startCol = 2 * i)
  writeData(wb, "Table 1", t(c("n", "%")), startRow = 3, startCol = 2 * i, colNames = FALSE)
}
out <- table1 %>% filter(!(is_header & section == "Sex"))       # shell: no "Sex" header row
writeData(wb, "Table 1", out %>% select(-section, -is_header), startRow = 4, colNames = FALSE)
addStyle(wb, "Table 1", createStyle(textDecoration = "bold", fgFill = "#D9D9D9"),
         rows = c(1:3, 3 + which(out$is_header)), cols = 1:9, gridExpand = TRUE)
writeData(wb, "Table 1", footnotes, startRow = nrow(out) + 5)
setColWidths(wb, "Table 1", cols = 1, widths = 52)
addWorksheet(wb, "Attrition");        writeData(wb, "Attrition", attrition)
addWorksheet(wb, "Chemo date check"); writeData(wb, "Chemo date check", chemo_check)
xlsx_path <- file.path(out_dir, paste0(out_stem, ".xlsx"))
saveWorkbook(wb, xlsx_path, overwrite = TRUE)
write.csv(select(long, section, label, is_header, group, n, n_num, pct),
          file.path(out_dir, paste0(out_stem, "_table1_long.csv")), row.names = FALSE)
saveRDS(ads, file.path(out_dir, paste0(out_stem, "_ads.rds")))
