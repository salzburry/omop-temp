# =============================================================================
# 03_first_run_checks.R : one-off checks for the open questions (prints only)
# =============================================================================
# Run once after run_all.R, in the same R session:  source("R/03_first_run_checks.R")
# Nothing is written; the outputs of run_all.R are unchanged.
# =============================================================================

# 1. What is in the Unresected column: "lymph node dissection only" (the RDQ
#    definition) or no primary-surgery record at all (counted as Unresected
#    by no_surgery_group)?
with_record <- unique(fetch("surgery", surgerytype)$patientid)
unresected_split <- ads %>% filter(surg_group == "Unresected") %>%
  mutate(source = ifelse(patientid %in% with_record, "Lymph node dissection only", "No primary-surgery record")) %>%
  group_by(source) %>%
  summarise(patients = n(), chemo_yes_pct = round(100 * mean(chemo == "Yes"), 1),
            radiation_yes_pct = round(100 * mean(radiation == "Yes"), 1)) %>%
  mutate(pct_of_unresected = round(100 * patients / sum(patients), 1), .after = patients)
message("\n1. Unresected column by source:"); print(as.data.frame(unresected_split), row.names = FALSE)

# 2. Stage edition: HPV-positive oropharynx at stage IVA/IVB exists only in
#    AJCC 7th edition (the 8th has no IVA/IVB for HPV-positive oropharynx).
opc <- ads %>% inner_join(fetch("cohort", primarysite), by = "patientid") %>%
  filter(norm(primarysite) == "oropharynx")
message("\n2. Oropharynx: HPVStatus x GroupStage")
print(table(HPV = opc$hpvstatus, GroupStage = opc$groupstage, useNA = "ifany"))

# 3. Patients removed by the C11/C12 (ICD-9 147 / 148.1) exclusion
excl_site <- src("cohort") %>% filter(patientid %in% !!unique(excluded$patientid)) %>%
  select(patientid, primarysite) %>% collect()
message("\n3. Excluded for C11/C12: ", nrow(excl_site), " patient(s); their PrimarySite and codes:")
print(as.data.frame(count(excl_site, primarysite)), row.names = FALSE)
print(as.data.frame(count(excluded, code = toupper(diagnosiscode))), row.names = FALSE)

# 4. Radiation courses against the first-course window (dates as recorded)
rt_chk <- fetch("radiation", rtstartdate, rtsite) %>% inner_join(fc_end, by = "patientid") %>%
  mutate(start = as.Date(rtstartdate),
         site_ok = norm(coalesce(rtsite, "Unknown/not documented")) %in% rt_sites,
         position = case_when(!site_ok ~ "Distant site (not counted)",
                              is.na(start) ~ "No start date",
                              start < dx_date - rt_lookback_days ~ "More than 30 days before diagnosis",
                              !is.na(fc_end) & start >= fc_end ~ "After end of first course",
                              TRUE ~ "Inside window"))
message("\n4. Radiation courses by position:"); print(as.data.frame(count(rt_chk, position)), row.names = FALSE)
rt_pat <- rt_chk %>% group_by(patientid) %>%
  summarise(site_ok = any(site_ok), inside = any(position == "Inside window"))
message("Patients with primary/unknown-site RT but none inside the window (counted No): ",
        sum(rt_pat$site_ok & !rt_pat$inside))
