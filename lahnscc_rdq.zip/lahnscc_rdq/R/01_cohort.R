# =============================================================================
# 01_cohort.R : study population and attrition
# =============================================================================
# The dataset is described as delivered. Flatiron has already applied the
# LA-HNSCC criteria (RDQ: >=2 visits on/after 2011, SCC histology,
# site/HPV/stage combinations, curative treatment, chemo-only excluded).
# The only RDQ-added exclusion is ICD C11.x / C12.x.
# Field names: Enhanced_LAHNC and Diagnosis tables, Flatiron data dictionary.
# =============================================================================

attrition <- list()
log_step <- function(step, ids) {
  attrition[[length(attrition) + 1]] <<- tibble(step = step,
                                                n_patients = n_distinct(ids))
  invisible(ids)
}

# ---- Step 0: everyone in the custom data (Enhanced_LAHNC) --------------------
cohort_raw <- src("cohort") %>%
  select(patientid, diagnosisdate, advanceddiagnosisdate, groupstage, hpvstatus) %>%
  collect() %>%
  mutate(dx_date  = as.Date(diagnosisdate),
         adv_date = as.Date(advanceddiagnosisdate))

if (anyDuplicated(cohort_raw$patientid)) {
  stop("Enhanced_LAHNC has more than one row per patient - the dictionary ",
       "says one record per patient. Check the delivery.", call. = FALSE)
}
log_step("All patients in Flatiron LA HNSCC custom data (Enhanced_LAHNC)",
         cohort_raw$patientid)

# ---- Step 1 (optional): initial diagnosis within the reporting years --------
in_window <- !is.na(cohort_raw$dx_date) & year(cohort_raw$dx_date) %in% dx_years
message(sum(!in_window), " patient(s) with initial diagnosis outside ",
        min(dx_years), "-", max(dx_years), " (or missing date).")
cohort <- if (restrict_dx_window) cohort_raw[in_window, ] else cohort_raw
if (restrict_dx_window) {
  log_step(sprintf("Initial diagnosis %d to %d", min(dx_years), max(dx_years)),
           cohort$patientid)
}

# ---- Step 2: exclude ICD C11.x / C12.x (and ICD-9 147.x / 148.1) -------------
dx_rows <- src("diagnosis") %>%
  filter(patientid %in% !!cohort$patientid) %>%
  select(patientid, diagnosiscode, diagnosiscodesystem) %>%
  collect() %>%
  mutate(code = toupper(gsub("[[:space:]]", "", diagnosiscode)),
         sys  = toupper(trimws(coalesce(diagnosiscodesystem, ""))))

# ICD-10-CM codes start with a letter, ICD-9-CM codes do not, so the patterns
# cannot cross systems: the code alone decides, whatever DiagnosisCodeSystem
# says or however it is spelled (it may also be null).
excl_rows <- dx_rows %>%
  filter(grepl(excl_icd10_regex, code) | grepl(excl_icd9_regex, code))
message("C11/C12 exclusion: ", nrow(excl_rows), " diagnosis row(s), ",
        n_distinct(excl_rows$patientid), " patient(s); by code system:")
print(count(excl_rows, sys))
excl_ids <- unique(excl_rows$patientid)

cohort <- cohort %>% filter(!patientid %in% excl_ids)
log_step("Excluding any ICD-10 C11.x / C12.x or ICD-9 147.x / 148.1 diagnosis",
         cohort$patientid)

attrition <- bind_rows(attrition) %>%
  mutate(n_excluded = lag(n_patients) - n_patients)

cohort_ids <- cohort$patientid
print(attrition)
