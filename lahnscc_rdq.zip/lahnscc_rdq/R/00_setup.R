# =============================================================================
# LA-HNSCC RDQ - Descriptive characteristics of LA-HNSCC patients in Flatiron
# 00_setup.R : libraries, parameters, connection, source tables
# =============================================================================
# Asset 61431 Dostarlimab (GSK4057190) - JADE HNSCC. VeevaRIO 338681.
# Purpose: describe the Flatiron LA HNSCC custom data AS DELIVERED, in the same
#          layout as the SEER RDQ Table 1, to judge how representative
#          Flatiron is of the US LA-HNSCC population.
# Source : Flatiron "GSK Dostarlimab Locally Advanced Head & Neck Custom Data"
#          (July 2026 delivery, data cut-off December 2025). Table and field
#          names follow the Flatiron data dictionary for that project.
#
# Sourced by run_all.R. Not runnable on its own.
# =============================================================================

suppressPackageStartupMessages({
  library(DBI)
  library(dbplyr)
  library(dplyr)
  library(tidyr)
  library(lubridate)
  library(openxlsx)
})

if (!exists("%||%", mode = "function")) `%||%` <- function(a, b) if (is.null(a)) b else a

# A setting from the environment. A variable that is set but blank counts as
# unset (Domino project variables are often defined empty).
env_or <- function(k, default) {
  v <- trimws(Sys.getenv(k))
  if (nzchar(v)) v else default
}

# =============================================================================
# Parameters
# =============================================================================
asset_id   <- "61431"
veeva_id   <- "338681"
db_catalog <- env_or("DATABRICKS_CATALOG", "hive_metastore")
dbname     <- env_or("RDQ_SOURCE_SCHEMA", "clnprw_flatiron_la_hnc_use")
refresh    <- env_or("RDQ_REFRESH", "2026m07")              # July 2026 delivery
datacut    <- as.Date("2025-12-31")

# The schema is a bare name; the catalog comes from DATABRICKS_CATALOG. A
# "catalog.schema" value is accepted only when its catalog is that one.
local({
  parts <- strsplit(dbname, ".", fixed = TRUE)[[1]]
  if (length(parts) == 2L) {
    if (!identical(parts[1], db_catalog))
      stop("SETTING ERROR: RDQ_SOURCE_SCHEMA = '", dbname, "' names catalog '", parts[1],
           "' but DATABRICKS_CATALOG is '", db_catalog, "'.", call. = FALSE)
    dbname <<- parts[2]
  }
  if (!grepl("^[A-Za-z0-9_]+$", dbname))
    stop("SETTING ERROR: RDQ_SOURCE_SCHEMA = '", dbname, "' is not a schema name.",
         call. = FALSE)
  if (!grepl("^[A-Za-z0-9_]+$", refresh))
    stop("SETTING ERROR: RDQ_REFRESH = '", refresh, "' is not a refresh suffix.",
         call. = FALSE)
})

# Diagnosis years shown in Table 1 ("2019 to 2025"). The dataset is described
# as delivered: restrict_dx_window = FALSE keeps every patient and reports any
# diagnosis outside the window in an "Outside <years>" row. Flatiron's cohort
# criteria are initial diagnosis 01JAN2019 - 30NOV2022, so 2023-2025 are
# expected to be empty.
dx_years <- 2019:2025
restrict_dx_window <- FALSE

# Exclusion added in the RDQ: ICD C11.x, C12.x.
# ICD-9 equivalents: 147.x (nasopharynx), 148.1 (pyriform sinus). ICD-10-CM
# codes start with a letter and ICD-9-CM codes do not, so each pattern can only
# match its own system: the code system field (nullable) is not needed.
excl_icd10_regex <- "^C1[12]"
excl_icd9_regex  <- "^147|^148\\.?1($|[^0-9])"

# ---- Surgery (Enhanced_LAHNC_PrimarySurgery.SurgeryType) --------------------
# Dictionary coding -> SEER-style group (RDQ "Description of request").
surgery_map <- c(
  "Primary tumor resection and lymph node dissection" = "Resected",
  "Primary tumor resection only"                      = "Resected",
  "Lymph node dissection only"                        = "Unresected",
  "Unknown/not specified"                             = "Unknown"
)
# Any other value (the dictionary's own example is "Endoscopic mucosal
# resection") is mapped by keyword and listed in a warning: "resection" ->
# Resected, "lymph node"/"neck dissection" without "primary" -> Unresected,
# otherwise Unknown.
# Patients with NO primary-surgery record: SEER codes "no surgery of primary
# site" (00), which is unresected. Set to "Unknown" if the RDQ rules otherwise.
no_surgery_group <- "Unresected"
# Salvage surgery (Enhanced_LAHNC_SalvageSurgery) is NOT first-course treatment
# and is not used for the surgery columns.

# ---- First-course treatment (SEER "first course") ---------------------------
# DrugEpisode.LineSetting values (dictionary) and the decision for each:
#   NEOADJUVANT, INDUCTION CHEMO, CONCURRENT, ADJUVANT, EARLY  -> first course
#   RADIATION THERAPY  -> first course: a systemic drug recorded in this setting
#                         is given alongside definitive RT (radiosensitising)
#   ADVANCED, LOCOREGIONAL -> excluded: treatment of advanced disease/recurrence
#   OFF SYSTEMIC THERAPY   -> excluded: no systemic therapy in this setting
#   (null)                 -> excluded: not assigned to a line; counted and
#                             reported in the log
first_course_settings <- c("NEOADJUVANT", "INDUCTION CHEMO", "CONCURRENT",
                           "ADJUVANT", "EARLY", "RADIATION THERAPY")

# Receipt of chemotherapy. Flatiron keeps the therapy class ("chemotherapy",
# "immunotherapy", "targeted therapy", ...) in DetailedDrugCategory; DrugCategory
# is the broad pharmacological class (dictionary example "antianemic").
#   "seer"         = DetailedDrugCategory chemotherapy, plus cetuximab
#                    (SEER*Rx codes cetuximab as chemotherapy; confirm)
#   "cytotoxic"    = DetailedDrugCategory chemotherapy only
#   "any_systemic" = any antineoplastic drug in a first-course line (adds
#                    immunotherapy and targeted therapy; not supportive care)
chemo_definition <- "seer"
seer_extra_chemo <- "cetuximab"
# DrugEpisode.EnhancedCohort is the disease setting of the line. NULL accepts a
# single value only (the run stops if several appear); set it to the LA-HNC
# value(s) to filter.
drug_cohorts <- NULL

# Receipt of radiation (Enhanced_LAHNC_RadiationTherapy): an RT course to the
# primary site, or with the site unknown/missing, whose start lies on/after
# diagnosis - rt_lookback_days and before the end of first course. The first
# course ends at the earliest of: first locoregional recurrence
# (Enhanced_LAHNC_LocalRecurrence.LocalRecurDate), distant recurrence
# (Enhanced_LAHNC_MetRecurrence.DistantMetDate) and AdvancedDiagnosisDate.
# A start date known only to the month or year counts when its whole possible
# range lies inside the window ("rt_coarse_rule" = "within"), or when any part
# of it does ("overlap").
rt_lookback_days <- 30
rt_sites_first_course <- c("Primary site (Includes regional lymph node involvement)",
                           "Unknown/not documented")
rt_coarse_rule <- "within"

# Outputs
out_dir   <- env_or("RDQ_OUT_DIR", "/mnt/artifacts/results/")
out_stem  <- paste0("TFL_HNSCC_FI_RDQ_v0.1_", toupper(format(Sys.Date(), "%d%b%Y")))
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
if (!dir.exists(out_dir) || file.access(out_dir, 2) != 0)
  stop("SETTING ERROR: RDQ_OUT_DIR '", out_dir, "' is not a writable directory.",
       call. = FALSE)

# ---- Dictionary code lists (checked against the delivery in 02_derive.R) ----
codes <- list(
  birthsex     = c("F", "M"),
  race         = c("Asian", "Black or African American", "Hispanic or Latino",
                   "White", "Other Race",
                   # also mapped if present
                   "American Indian or Alaska Native",
                   "Native Hawaiian or Other Pacific Islander"),
  ethnicity    = c("Not Hispanic or Latino", "Hispanic or Latino"),
  groupstage   = c("III", "IV", "IVA", "IVB", "IVC", "Unknown/not documented"),
  hpvstatus    = c("HPV positive", "HPV negative", "HPV equivocal",
                   "Unsuccessful/indeterminate test", "Results pending",
                   "Unknown*"),                 # any "Unknown..." value
  surgerytype  = names(surgery_map),
  rtsite       = c("Primary site (Includes regional lymph node involvement)",
                   "Distant lymph nodes", "Distant site", "Unknown/not documented"),
  granularity  = c("Day", "Month", "Year"),
  linesetting  = c("ADJUVANT", "ADVANCED", "CONCURRENT", "INDUCTION CHEMO",
                   "LOCOREGIONAL", "NEOADJUVANT", "RADIATION THERAPY", "EARLY",
                   "OFF SYSTEMIC THERAPY"),
  practicetype = c("ACADEMIC", "COMMUNITY")
)

# =============================================================================
# Connection
# =============================================================================
# ODBC connection: DSN in DATABRICKS_DSN (default RWDE); password from
# DATABRICKS_PWD only.
connect <- function() {
  for (pkg in c("DBI", "odbc"))
    if (!requireNamespace(pkg, quietly = TRUE))
      stop("CONNECTION ERROR: ", pkg, " is not installed.", call. = FALSE)
  pwd <- Sys.getenv("DATABRICKS_PWD")
  if (!nzchar(pwd))
    stop("CONNECTION ERROR: DATABRICKS_PWD environment variable is not set.", call. = FALSE)
  dsn <- env_or("DATABRICKS_DSN", "RWDE")
  con <- DBI::dbConnect(odbc::odbc(), dsn = dsn, pwd = pwd, timeout = 120)
  attr(con, "rdq_dsn") <- dsn
  con
}

# Fingerprint of the code that ran: a hash of the sources, sorted in radix
# order so it does not depend on the machine's locale.
code_md5 <- function(here = ".") {
  fs <- sort(c(list.files(file.path(here, "R"), "\\.R$", full.names = TRUE),
               file.path(here, "run_all.R")), method = "radix")
  fs <- fs[file.exists(fs)]
  tmp <- tempfile(); on.exit(unlink(tmp), add = TRUE)
  writeLines(unlist(lapply(fs, readLines, warn = FALSE)), tmp)
  unname(tools::md5sum(tmp))
}
run_started <- Sys.time()

# Reuse a live ODBC connection from the session, otherwise connect.
if (!(exists("con") && inherits(con, "OdbcConnection") && DBI::dbIsValid(con))) {
  con <- connect()
}
DBI::dbExecute(con, paste0("USE CATALOG ", DBI::dbQuoteIdentifier(con, db_catalog)))
con_desc <- local({
  cur <- tryCatch(DBI::dbGetQuery(con, "SELECT current_catalog() AS c")$c[1],
                  error = function(e) NA_character_)
  paste0("odbc, DSN ", attr(con, "rdq_dsn") %||% env_or("DATABRICKS_DSN", "RWDE"),
         ", catalog ", cur)
})
message("connected: ", con_desc)

# =============================================================================
# Source tables
# =============================================================================
# Flatiron dictionary table -> Databricks table. Tables are renamed on load
# (a t_ prefix, "enh" for Enhanced, abbreviations such as drg_epsode), so each
# table is FOUND by a pattern against the schema listing. Patterns run on the
# lower-cased name with the _<refresh> suffix removed. A key can be pinned to
# an exact table name with the environment variable RDQ_TBL_<KEY> (e.g.
# RDQ_TBL_DRUGEP), so a name the patterns miss needs no code change.
hnc <- "enh(anced)?_?(la_?)?hnc"
tbl_patterns <- list(
  cohort    = paste0("^(t_)?", hnc, "$"),                          # Enhanced_LAHNC
  surgery   = paste0("^(t_)?", hnc, "_?pr(i|m)[a-z]*_?su?rg"),     # Enhanced_LAHNC_PrimarySurgery
  radiation = paste0("^(t_)?", hnc, "_?(ra?d|rt($|_))"),           # Enhanced_LAHNC_RadiationTherapy
  drugep    = paste0("^(t_)?(", hnc, "_?)?dr?u?g_?ep"),            # DrugEpisode
  diagnosis = "^(t_)?diagnosis$",                                  # Diagnosis
  demo      = "^(t_)?demographics?$",                              # Demographics
  practice  = "^(t_)?practices?$",                                 # Practice
  localrec  = paste0("^(t_)?", hnc, "_?lo?c[a-z]*_?rec"),           # Enhanced_LAHNC_LocalRecurrence
  metrec    = paste0("^(t_)?", hnc, "_?me?t[a-z]*_?rec")            # Enhanced_LAHNC_MetRecurrence
)
# Tables the run can do without: a miss is a warning and the first-course end
# falls back to AdvancedDiagnosisDate alone.
tbl_optional <- c("localrec", "metrec")

list_schema_tables <- function() {
  x <- DBI::dbGetQuery(con, paste0("SHOW TABLES IN ", DBI::dbQuoteIdentifier(con, dbname)))
  col <- intersect(c("tableName", "tablename", "table_name", "name"), names(x))
  if (!length(col)) col <- grep("table", names(x), ignore.case = TRUE, value = TRUE)
  x[[col[1]]]
}

# Match a list of table names against the patterns (and any overrides).
match_tables <- function(avail, patterns = tbl_patterns, refresh_sfx = refresh,
                         overrides = list()) {
  stems <- sub(paste0("_", refresh_sfx, "$"), "", tolower(avail))
  this  <- grepl(paste0("_", refresh_sfx, "$"), tolower(avail))
  lapply(setNames(names(patterns), names(patterns)), function(k) {
    ov <- overrides[[k]]
    if (!is.null(ov) && nzchar(ov)) return(avail[tolower(avail) %in% tolower(c(ov, paste0(ov, "_", refresh_sfx)))])
    avail[this & grepl(patterns[[k]], stems)]
  })
}

resolve_tables <- function() {
  avail <- list_schema_tables()
  ovr <- lapply(setNames(names(tbl_patterns), names(tbl_patterns)),
                function(k) env_or(paste0("RDQ_TBL_", toupper(k)), ""))
  hits <- match_tables(avail, overrides = ovr)
  out <- character(0)
  for (k in names(hits)) {
    h <- hits[[k]]
    if (length(h) == 1) { out[k] <- h; next }
    if (length(h) == 0 && k %in% tbl_optional) {
      warning("Optional table '", k, "' not found (pattern ", tbl_patterns[[k]],
              "); first-course end uses AdvancedDiagnosisDate without it. ",
              "Set RDQ_TBL_", toupper(k), " to name it.", call. = FALSE)
      next
    }
    message("Tables in ", dbname, ":\n  ", paste(sort(avail), collapse = "\n  "))
    stop(sprintf("Table '%s' (pattern %s): %d matches for refresh %s%s. ",
                 k, tbl_patterns[[k]], length(h), refresh,
                 if (length(h)) paste0(" (", paste(h, collapse = ", "), ")") else ""),
         "Set RDQ_TBL_", toupper(k), " to the exact table name, or fix tbl_patterns.",
         call. = FALSE)
  }
  print(data.frame(key = names(out), table = unname(out)), row.names = FALSE)
  out
}
tbl_map <- resolve_tables()

src <- function(key) {
  tbl(con, in_schema(dbname, tbl_map[[key]])) %>% rename_with(tolower)
}
