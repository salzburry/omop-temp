# =============================================================================
# 00_setup.R : parameters, connection, source tables
# =============================================================================
# LA-HNSCC RDQ - descriptive characteristics of LA-HNSCC patients in Flatiron,
# compared with SEER. VeevaRIO 338681; asset 61431, Dostarlimab (GSK4057190).
# Source: Flatiron "GSK Dostarlimab Locally Advanced Head & Neck Custom Data",
# July 2026 delivery, data cut-off December 2025.
# =============================================================================

suppressPackageStartupMessages({
  library(DBI); library(dbplyr); library(dplyr); library(tidyr)
  library(lubridate); library(openxlsx)
})

# ---- Parameters ---------------------------------------------------------------
catalog   <- "hive_metastore"
schema    <- "clnprw_flatiron_la_hnc_use"
refresh   <- "2026m07"                 # suffix of every table in this delivery
datacut   <- as.Date("2025-12-31")
dx_years  <- 2019:2025                 # years shown in Table 1
out_dir   <- "/mnt/artifacts/results"
out_stem  <- paste0("TFL_HNSCC_FI_RDQ_v0.1_", toupper(format(Sys.Date(), "%d%b%Y")))
seer_file <- "inputs/seer_table1.csv"  # SEER Table 1 for 02_seer_compare.R

# RDQ exclusion: ICD-10 C11.x / C12.x and the ICD-9 equivalents 147.x / 148.1.
# Matched on the code itself (ICD-10 codes start with a letter, ICD-9 codes do
# not), so a missing or differently spelled DiagnosisCodeSystem does not matter.
excl_icd <- "^C1[12]|^147|^148\\.?1($|[^0-9])"

# Surgery groups (RDQ; SurgeryType coding of Enhanced_LAHNC_PrimarySurgery)
surgery_map <- c("primary tumor resection only"                      = "Resected",
                 "primary tumor resection and lymph node dissection" = "Resected",
                 "lymph node dissection only"                        = "Unresected",
                 "unknown/not specified"                             = "Unknown")
no_surgery_group <- "Unresected"       # no primary-surgery record (SEER: no surgery of primary site)

# "Receipt of chemotherapy / radiation (1L)" = SEER first course of treatment
first_course_settings <- c("NEOADJUVANT", "INDUCTION CHEMO", "CONCURRENT", "ADJUVANT",
                           "EARLY", "RADIATION THERAPY")   # DrugEpisode.LineSetting
count_cetuximab  <- TRUE               # SEER*Rx codes cetuximab as chemotherapy
drug_cohorts     <- NULL               # DrugEpisode.EnhancedCohort value(s) for LA-HNSCC lines;
                                       # NULL = the delivery must hold a single value
rt_lookback_days <- 30                 # RT may start up to 30 days before diagnosis
rt_sites <- c("primary site (includes regional lymph node involvement)",
              "unknown/not documented")                     # RTSite (missing counts too)

# ---- Connection ---------------------------------------------------------------
connect <- function() {
  pwd <- Sys.getenv("DATABRICKS_PWD")
  if (!nzchar(pwd)) stop("Set the DATABRICKS_PWD environment variable.", call. = FALSE)
  dbConnect(odbc::odbc(), dsn = "RWDE", pwd = pwd, timeout = 120)
}
con <- connect()
invisible(dbExecute(con, paste("USE CATALOG", catalog)))

# ---- Source tables ------------------------------------------------------------
# Tables are renamed on load (t_ prefix, "enh", abbreviations such as
# drg_epsode), so each one is found by a pattern on its name without the
# _<refresh> suffix. Exactly one table must match; edit a pattern if needed.
hnc <- "^(t_)?enh(anced)?_?(la_?)?hnc"
tbl_patterns <- c(
  cohort    = paste0(hnc, "$"),                          # Enhanced_LAHNC
  surgery   = paste0(hnc, "_?pr(i|m)[a-z]*_?su?rg"),     # Enhanced_LAHNC_PrimarySurgery
  radiation = paste0(hnc, "_?(ra?d|rt($|_))"),           # Enhanced_LAHNC_RadiationTherapy
  localrec  = paste0(hnc, "_?lo?c[a-z]*_?rec"),          # Enhanced_LAHNC_LocalRecurrence
  metrec    = paste0(hnc, "_?me?t[a-z]*_?rec"),          # Enhanced_LAHNC_MetRecurrence
  drugep    = "^(t_)?(enh(anced)?_?(la_?)?hnc_?)?dr?u?g_?ep",   # DrugEpisode
  diagnosis = "^(t_)?diagnosis$",
  demo      = "^(t_)?demographics?$",
  practice  = "^(t_)?practices?$")

find_tables <- function(tables) {
  tables <- tables[grepl(paste0("_", refresh, "$"), tolower(tables))]
  stems  <- sub(paste0("_", refresh, "$"), "", tolower(tables))
  sapply(names(tbl_patterns), function(k) {
    hit <- tables[grepl(tbl_patterns[[k]], stems)]
    if (length(hit) != 1)
      stop("Table '", k, "': ", length(hit), " tables match pattern ", tbl_patterns[[k]],
           " for refresh ", refresh, ". Tables in the schema:\n  ",
           paste(sort(tables), collapse = "\n  "), call. = FALSE)
    hit
  })
}
schema_tables <- dbGetQuery(con, paste("SHOW TABLES IN", schema))$tableName
tbl_map <- find_tables(schema_tables)
print(tbl_map)

src <- function(key) tbl(con, in_schema(schema, tbl_map[[key]])) %>% rename_with(tolower)
