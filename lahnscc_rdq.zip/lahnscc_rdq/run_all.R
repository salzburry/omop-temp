# =============================================================================
# LA-HNSCC RDQ (VeevaRIO 338681) - driver
# Descriptive characteristics of LA-HNSCC patients in Flatiron, and how
# representative they are of the US (SEER) LA-HNSCC population
# =============================================================================
# Run from the project root:  source("run_all.R")
# 00_setup.R finds each source table in the schema and stops if one is missing.
# 04_seer_compare.R runs when inputs/seer_table1.csv exists (otherwise it
# writes a template to fill from the SEER RDQ output).
# =============================================================================

source("R/00_setup.R")
source("R/01_cohort.R")
source("R/02_derive.R")
source("R/03_table1.R")
source("R/04_seer_compare.R")
source("R/05_output.R")
