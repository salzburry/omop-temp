# RWP Oncology Azure Boards — user examples

## Recommended model

Use the existing Scrum hierarchy:

- **Area Path** = workstream (`Data Products`, `Protocol`, `Feasibility RDQ`, `Other`)
- **Feature** = one deliverable / release / request
- **Product Backlog Item** = lifecycle stage
- **Task** = concrete action within a stage

Do not create `Protocol`, `RDQ`, or `Data Product` as custom work-item types merely to represent the category.

## Why a Protocol/RDQ work item may not appear in Backlogs

Azure Boards backlogs are filtered by:
1. **Work item type / backlog level** — a Feature appears on the Features backlog; a PBI appears on Backlog Items.
2. **Team Area Paths** — the RWP-Oncology team must include the item's Area Path (or include subareas).
3. **Iteration Path** — the item must be under the team's backlog iteration.
4. **State** — completed/removed work does not appear on normal active backlogs.
5. **Custom WIT configuration** — a custom work-item type is not added to a backlog automatically.

The easiest operating rule is: **create Features and PBIs from the team Backlogs page whenever practical**, then set the appropriate Area Path.

## Sample Features

- `Prostate Panoramic RWDP - 2026m03` → `RWP-Oncology\Data Products`
- `MIRROR COTA Study - Protocol - 2026` → `RWP-Oncology\Protocol`
- `NSCLC Biomarker Feasibility - Sep 2026` → `RWP-Oncology\Feasibility RDQ`

## Sample stage PBIs

### RWDP
Methodology Doc → Prog Spec → Prog Spec QC → Programming → Program Validation → Release Preparation

### Protocol (sample)
Programming Specification → Programming → QC / Validation → Final Deliverable / Dissemination

The middle phases are grounded in the existing Protocol tracker. Adjust the first/last gate to the actual Protocol operating process before standardizing it.

### Feasibility / RDQ (sample)
Intake / Clarification → Feasibility Assessment → Programming / Analysis → QC / Validation → Response / Dissemination

Remove stages for simple requests when they do not apply.

## Files

- `RWP_ADO_User_Examples.xlsx` — user guide + examples + backlog troubleshooting
- `01_Sample_Features_import.csv` — safe starter Feature import
- `02_Sample_PBI_hierarchy_after_Feature_IDs.csv` — hierarchy template; replace parent Feature IDs first
- `03_Sample_Task_examples.csv` — task examples users can follow

## Official Microsoft references

- https://learn.microsoft.com/en-us/azure/devops/organizations/settings/work/customize-process-work-item-type?view=azure-devops
- https://learn.microsoft.com/en-us/azure/devops/organizations/settings/work/customize-process-backlogs-boards?view=azure-devops
- https://learn.microsoft.com/en-us/azure/devops/organizations/settings/about-teams-and-settings?view=azure-devops
- https://learn.microsoft.com/en-us/azure/devops/boards/backlogs/create-your-backlog?view=azure-devops
